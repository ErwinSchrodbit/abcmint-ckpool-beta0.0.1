/*
 * quantum_resistant_test.c - 量子抗性算法适配测试
 * 验证与abcmint-master的兼容性
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include "../src/quantum_resistant.h"

// 测试用例1：验证Uint256ToBits函数
void test_Uint256ToBits() {
    printf("\n测试Uint256ToBits函数...\n");
    
    // 创建一个测试哈希
    uint256 testHash = {{
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
        0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20
    }};
    
    // 测试输出缓冲区
    uint8_t bits[256] = {0};
    
    // 调用函数
    Uint256ToBits(testHash.data, bits, 256);
    
    // 验证部分位是否正确（例如检查第1位和第8位）
    printf("第1位应该是1: %u\n", bits[0]);
    printf("第8位应该是1: %u\n", bits[7]);
    printf("第9位应该是0: %u\n", bits[8]);
    printf("第10位应该是0: %u\n", bits[9]);
}

// 测试用例2：验证Uint256ToSolutionBits函数
void test_Uint256ToSolutionBits() {
    printf("\n测试Uint256ToSolutionBits函数...\n");
    
    // 创建一个测试nonce
    uint256 testNonce = {{
        0xFF, 0x00, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    }};
    
    // 测试输出缓冲区
    uint8_t solution[32];
    
    // 调用函数
    Uint256ToSolutionBits(solution, 32, testNonce);
    
    // 验证部分结果
    printf("第一位应该是1: %u\n", solution[0]);
    printf("第八位应该是1: %u\n", solution[7]);
    printf("第九位应该是0: %u\n", solution[8]);
    printf("第十六位应该是1: %u\n", solution[15]);
}

// 测试用例3：验证系数矩阵生成函数
void test_matrix_generation() {
    printf("\n测试系数矩阵生成函数...\n");
    
    // 创建一个测试哈希
    uint256 testHash = {{
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
        0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20
    }};
    
    unsigned int nBits = 16; // 测试使用16位
    unsigned int nUnknowns = nBits + 8;
    unsigned int nTerms = 1 + (nUnknowns + 1) * nUnknowns / 2;
    
    // 分配内存
    uint8_t* genMatrix = (uint8_t*)calloc(nBits * nTerms, sizeof(uint8_t));
    uint8_t* newGenMatrix = (uint8_t*)calloc(nBits * nTerms, sizeof(uint8_t));
    uint8_t* new2GenMatrix = (uint8_t*)calloc(nBits * nTerms, sizeof(uint8_t));
    
    if (!genMatrix || !newGenMatrix || !new2GenMatrix) {
        printf("内存分配失败\n");
        return;
    }
    
    // 调用各个生成函数
    GenCoeffMatrix(testHash, nBits, genMatrix);
    NewGenCoeffMatrix(testHash, nBits, newGenMatrix);
    New2GenCoeffMatrix(testHash, nBits, new2GenMatrix);
    
    // 打印部分矩阵内容进行验证
    printf("GenCoeffMatrix[0][0]: %u\n", genMatrix[0]);
    printf("NewGenCoeffMatrix[0][0]: %u\n", newGenMatrix[0]);
    printf("New2GenCoeffMatrix[0][0]: %u\n", new2GenMatrix[0]);
    
    // 释放内存
    free(genMatrix);
    free(newGenMatrix);
    free(new2GenMatrix);
}

// 测试用例4：验证CheckSolution函数
void test_CheckSolution() {
    printf("\n测试CheckSolution函数...\n");
    
    // 创建测试哈希和nonce
    uint256 testHash = {{
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
        0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20
    }};
    
    uint256 prevBlockHash = {{
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    }};
    
    uint256 testNonce = {{
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    }};
    
    unsigned int nBits = 1; // 使用1位进行简单测试
    int blockVersion = 101; // 当前版本
    
    // 调用函数（通常会返回false，因为随机nonce很难满足方程）
    bool result = CheckSolution(testHash, nBits, prevBlockHash, blockVersion, testNonce);
    printf("CheckSolution结果: %s\n", result ? "成功" : "失败");
    
    // 注意：这里主要测试函数是否能正常执行，而不是寻找有效的解
}

// 测试用例5：验证内存管理系统
void test_memory_management() {
    printf("\n测试内存管理系统...\n");
    
    // 初始化内存管理系统
    quantum_resistant_init_memory();
    printf("内存管理系统初始化完成\n");
    
    // 创建测试数据
    uint256 hash = {{
        0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF,
        0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10,
        0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF,
        0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10
    }};
    
    uint256 prevblockhash = {{
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    }};
    
    uint256 nonce = {{
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
        0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20
    }};
    
    // 多次调用CheckSolution来测试内存池的复用功能
    printf("测试内存池复用...");
    unsigned int iterations = 50; // 进行多次迭代来测试内存池
    unsigned int nBits = 4;
    int nblockversion = 4;
    
    clock_t start_time = clock();
    for (unsigned int i = 0; i < iterations; i++) {
        CheckSolution(hash, nBits, prevblockhash, nblockversion, nonce);
    }
    clock_t end_time = clock();
    
    double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("完成！执行 %u 次迭代耗时: %.4f 秒\n", iterations, elapsed_time);
    
    // 清理内存管理系统
    quantum_resistant_cleanup_memory();
    printf("内存管理系统清理完成\n");
}

// 测试用例6：验证难度调整算法
void test_difficulty_adjustment() {
    printf("\n测试难度调整算法...\n");
    
    // 测试基础难度计算
    uint256 test_nonce = {{
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
        0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20
    }};
    
    // 测试不同难度位
    printf("测试不同nBits值的难度计算:\n");
    for (unsigned int nBits = 1; nBits <= 32; nBits *= 2) {
        double difficulty = quantum_resistant_diff_from_solution(nBits, test_nonce);
        printf("nBits=%u, 难度=%.6f\n", nBits, difficulty);
    }
    
    // 测试彩虹算法难度调整
    printf("\n测试彩虹算法难度调整:\n");
    
    // 创建测试目标哈希
    uint8_t target[32] = {0};
    target[0] = 0x04;  // 模拟指数部分
    target[1] = 0x00;  // 模拟系数部分
    target[2] = 0x00;  // 模拟系数部分
    
    // 测试不同区块版本和高度
    uint32_t block_versions[] = {2, 4, 8};
    size_t block_heights[] = {0, 25217, 1000000, 5000000};
    
    for (size_t v = 0; v < sizeof(block_versions)/sizeof(block_versions[0]); v++) {
        for (size_t h = 0; h < sizeof(block_heights)/sizeof(block_heights[0]); h++) {
            double difficulty = quantum_resistant_calculate_difficulty(
                block_versions[v], block_heights[h], target);
            printf("版本=%u, 高度=%zu, 难度=%.6f\n", 
                   block_versions[v], block_heights[h], difficulty);
        }
    }
    
    printf("难度调整算法测试完成！\n");
}

// 测试用例7：验证SearchSolution函数
void test_SearchSolution() {
    printf("\n测试SearchSolution函数...\n");
    
    // 创建测试数据
    uint256 hash = {{
        0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF,
        0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10,
        0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF,
        0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10
    }};
    
    uint256 prevblockhash = {{
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    }};
    
    uint256 randomNonce = {{
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
        0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20
    }};
    
    // 使用低难度值进行测试
    unsigned int nBits = 4;
    int nblockversion = 4;
    int threadID = 0;
    int threadCount = 1;
    
    // 调用函数（在实际环境中，可能找不到解，但函数应该能正常执行）
    printf("开始搜索解决方案...\n");
    clock_t start_time = clock();
    uint256 solution = SearchSolution(hash, nBits, randomNonce, prevblockhash, 
                                     nblockversion, threadID, threadCount);
    clock_t end_time = clock();
    
    double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    
    // 检查解决方案是否有效
    bool solution_valid = CheckSolution(hash, nBits, prevblockhash, nblockversion, solution);
    
    printf("搜索完成！耗时: %.4f 秒, 找到解: %s\n", 
           elapsed_time, solution_valid ? "是" : "否");
}

int main() {
    printf("量子抗性算法适配测试\n");
    printf("========================\n");
    
    test_Uint256ToBits();
    test_Uint256ToSolutionBits();
    test_matrix_generation();
    test_CheckSolution();
    test_memory_management();
    test_difficulty_adjustment();
    test_SearchSolution();
    
    printf("\n测试完成！\n");
    return 0;
}