/*
 * test_rainbow.c - 简单的测试程序，用于验证rainbow18_compat模块是否可以编译
 */

/* 移除未使用的config.h头文件 */

/* 确保stdio.h可用 */
#include <stdio.h>

#include "rainbow18_compat.h"

int main() {
    // 打印测试信息
    printf("测试rainbow18_compat模块编译...\n");
    
    // 测试配置函数
    rainbow18_set_config(1, 3, 500, 2);
    printf("Rainbow18配置已设置\n");
    
    // 测试常量定义
    printf("RAINBOW18_PUBLIC_KEY_SIZE: %d\n", RAINBOW18_PUBLIC_KEY_SIZE);
    printf("RAINBOW18_SIGNATURE_SIZE: %d\n", RAINBOW18_SIGNATURE_SIZE);
    
    printf("测试完成！\n");
    return 0;
}