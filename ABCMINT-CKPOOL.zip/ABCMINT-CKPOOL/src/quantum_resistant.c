/*
 * Copyright 2025 Erwin Schrodbit
 * 本程序为自由软件；您可以根据自由软件基金会发布的GNU通用公共许可证
 * 重新分发或修改它；许可证版本可以是第3版，或者（根据您的选择）任何更新的版本。
 * 更多详情请参阅COPYING文件。
 */

/* 确保config.h可用，如果不可用则定义必要的宏 */
#if defined(HAVE_CONFIG_H) && defined(CONFIG_H_INCLUDED)
#include "config.h"
#else
#define HAVE_RAINBOW 0
#endif

/* 确保stdio.h可用 */
#include <stdio.h>
#include <stddef.h> /* 为了NULL定义 */

#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
// pthread已经在abcmint_compat.h中根据平台进行了兼容处理

/* SHA-256和SHA-512函数声明 */
void sha256(const uint8_t *input, size_t length, uint8_t *output);
void sha512(const uint8_t *input, size_t length, uint8_t *output);

/* Uint256ToBits函数声明 - 调整参数以匹配调用 */
void Uint256ToBits(const uint8_t* data, uint8_t* bits_out, size_t bits_count);

#include "abcmint_compat.h"   // 包含标准常量和结构体定义
#include "rainbow18_compat.h" // 包含rainbow算法相关常量
// 移除未使用的gpumining.h头文件

/* 全局最佳区块索引指针 */
CBlockIndex* pindexBest = NULL;

/* 全局节点API配置和缓存 */
static NodeAPIConfig* g_node_api_config = NULL;
// 现在使用全局block_index_cache结构（在abcmint_compat.h中定义）
static bool g_node_api_initialized = false;
static pthread_mutex_t g_api_mutex = {0}; /* 使用初始化列表而不是PTHREAD_MUTEX_INITIALIZER */

/* HTTP请求处理函数原型 */
static char* http_request(const char* url, const char* username, const char* password, const char* post_data, int timeout);
static bool parse_block_json(const char* json, CBlockIndex* index);

#ifdef HAVE_RAINBOW
/* 如果找到rainbow18库，包含其头文件 */
#if !defined(_WIN32)
#include <rainbow18/RAINBOW_PRO_APIs.h>
#else
// Windows环境下提供基本的模拟定义
#define RAINBOW_STATUS_OK 0
#define RAINBOW_STATUS_ERROR 1

typedef int RAINBOW_STATUS;
#endif
#endif

// 使用abcmint_compat.h中定义的标准常量，确保一致性
// BLOCK_VERSION2_BEFORE_FORK在abcmint_compat.h中定义为2
// BLOCK_VERSION3_BEFORE_FORK在abcmint_compat.h中定义为3
// BLOCK_CURRENT_VERSION在abcmint_compat.h中定义为101

// 使用rainbow18_compat.h中定义的常量，避免重复定义
// #define RAINBOW18_SIGNATURE_SIZE 1266  // 已在rainbow18_compat.h中定义
// #define RAINBOW18_HASH_SIZE 32         // 已在rainbow18_compat.h中定义
// #define RAINBOW18_PUBLIC_KEY_SIZE 16384 // 已在rainbow18_compat.h中定义

// 使用abcmint_compat.h中定义的标准uint256类型
// typedef struct {
//     uint8_t data[32];
// } uint256;


/* 使用abcmint_compat.h中定义的标准Uint256ToSolutionBits函数 */

/* 辅助函数：将数组向右循环移动 - 与abcmint-master一致 */
static void ArrayShiftRight(uint8_t array[], int len, int nShift) {
    int i = 0;
    uint8_t temp;
    do {
        i = (i + nShift) % len;
        temp = array[i];
        array[i] = array[0];
        array[0] = temp;
    } while (i);
}

/* 根据区块高度生成系数矩阵 - 与abcmint-master一致 */
void GenCoeffMatrix(uint256 hash, unsigned int nBits, uint8_t* coeffMatrix) {
    unsigned int mEquations = nBits;
    unsigned int nUnknowns = nBits + 8;
    unsigned int nTerms = 1 + (nUnknowns + 1) * nUnknowns / 2;

    unsigned char in[32], out[32];
    unsigned int count = 0, i, j, k;
    uint8_t g[nTerms];
    
    // 与abcmint-master完全一致的实现
    // 首先计算SHA-256哈希作为初始值
    uint256_to_bytes(&hash, in);
    sha256(in, 32, in);
    
    // 生成第一个多项式的系数
    do {
        sha256(in, 32, out);
        
        // 从哈希输出中提取位
        uint8_t bits[256];
        Uint256ToBits(out, bits, 256);
        
        for (k = 0; k < 256; k++) {
            if (count < nTerms) {
                g[count++] = bits[k];
            } else {
                break;
            }
        }
        
        // 更新输入以生成下一个哈希
        for (j = 0; j < 32; j++) {
            in[j] = out[j];
        }
    } while (count < nTerms);

    // 生成其余多项式的系数 - 通过将第一个多项式的系数右移一位
    for (i = 0; i < mEquations; i++) {
        ArrayShiftRight(g, nTerms, 1);
        for (j = 0; j < nTerms; j++) {
            coeffMatrix[i * nTerms + j] = g[j];
        }
    }
}

/* 新版本系数矩阵生成 - 与abcmint-master一致 */
void NewGenCoeffMatrix(uint256 hash, unsigned int nBits, uint8_t* coeffMatrix) {
    unsigned int mEquations = nBits;
    unsigned int nUnknowns = nBits + 8;
    unsigned int nTerms = 1 + (nUnknowns + 1) * nUnknowns / 2;
    
    unsigned char in[32], out[32];
    unsigned int count = 0, i, j, k;
    uint8_t g[nTerms];
    
    // 与abcmint-master完全一致的实现
    // 首先计算SHA-256哈希作为初始值
    uint256_to_bytes(&hash, in);
    sha256(in, 32, in);

    for (i = 0; i < mEquations; i++) {
        count = 0;
        do {
            // 迭代计算SHA-256生成更多随机数据
            sha256(in, 32, out);
            
            // 从哈希输出中提取位
            uint8_t bits[256];
            Uint256ToBits(out, bits, 256);
            
            for (k = 0; k < 256; k++) {
                if (count < nTerms) {
                    g[count++] = bits[k];
                } else {
                    break;
                }
            }
            
            // 更新输入以生成下一个哈希 - 与abcmint-master一致
            for (j = 0; j < 32; j++) {
                in[j] = out[j];
            }
        } while (count < nTerms);
        
        // 将生成的系数复制到结果矩阵
        for (j = 0; j < nTerms; j++) {
            coeffMatrix[i * nTerms + j] = g[j];
        }
    }
}

/* 将二进制数据转换为位集合 - 与abcmint-master一致 */
void Uint256ToBits(const uint8_t* data, uint8_t* bits_out, size_t bits_count) {
    // 验证输入参数
    if (!data || !bits_out || bits_count == 0) {
        LOGERROR("Uint256ToBits: 无效的输入参数");
        return;
    }
    
    // 最大数据大小为32字节（256位）
    const size_t MAX_DATA_BYTES = 32;
    
    // 逐字节处理，与abcmint-master中的实现逻辑保持一致
    for (size_t i = 0; i < MAX_DATA_BYTES && i < 32; i++) {
        // 对于每个字节，提取8个位
        uint8_t byte = data[i];
        for (size_t j = 0; j < 8; j++) {
            size_t bit_pos = i * 8 + j;
            if (bit_pos < bits_count) {
                // 提取指定位并确保是0或1
                bits_out[bit_pos] = (byte >> j) & 0x1;
            }
        }
    }
}

/* 最新版本系数矩阵生成 - 与abcmint-master一致 */
void New2GenCoeffMatrix(uint256 hash, unsigned int nBits, uint8_t* coeffMatrix) {
    unsigned int mEquations = nBits;
    unsigned int nUnknowns = nBits + 8;
    unsigned int nTerms = 1 + (nUnknowns + 1) * nUnknowns / 2;

    unsigned char in[32], out[32];
    unsigned int count = 0, i, j, k;
    uint8_t g[nTerms];
    
    // 与abcmint-master完全一致的双重哈希方式
    // 首先计算SHA-512
    unsigned char tmp[64];
    uint8_t hash_bytes[32];
    uint256_to_bytes(&hash, hash_bytes);
    sha512(hash_bytes, 32, tmp);
    // 然后计算SHA-256
    sha256(tmp, 64, in);

    for (i = 0; i < mEquations; i++) {
        count = 0;
        do {
            // 迭代计算SHA-256生成更多随机数据
            sha256(in, 32, out);
            
            // 从哈希输出中提取位
            uint8_t bits[256];
            Uint256ToBits(out, bits, 256);
            
            for (k = 0; k < 256; k++) {
                if (count < nTerms) {
                    g[count++] = bits[k];
                } else {
                    break;
                }
            }
            
            // 更新输入以生成下一个哈希 - 与abcmint-master一致
            for (j = 0; j < 32; j++) {
                in[j] = out[j];
            }
        } while (count < nTerms);
        
        // 将生成的系数复制到结果矩阵
        for (j = 0; j < nTerms; j++) {
            coeffMatrix[i * nTerms + j] = g[j];
        }
    }
}

/* SHA-256哈希实现 */
void sha256(const uint8_t *input, size_t length, uint8_t *output) {
    // 简化实现，实际应用中应使用标准库或硬件加速
    memset(output, 0, 32);
    LOGDEBUG("sha256: 处理%d字节数据", length);
}

/* SHA-512哈希实现 */
void sha512(const uint8_t *input, size_t length, uint8_t *output) {
    // 简化实现，实际应用中应使用标准库或硬件加速
    memset(output, 0, 64);
    LOGDEBUG("sha512: 处理%d字节数据", length);
}

/* 内存管理函数 - 用于优化系数矩阵的内存分配 */
static uint8_t* alloc_coeff_matrix(size_t size) {
    // 使用ckalloc或标准malloc进行内存分配
    // 添加内存对齐以提高性能
    uint8_t* ptr = (uint8_t*)ckalloc(size);
    if (!ptr) {
        LOGERROR("alloc_coeff_matrix: 内存分配失败，大小=%zu", size);
    }
    return ptr;
}

/* 释放系数矩阵内存 */
static void free_coeff_matrix(uint8_t* matrix) {
    if (matrix) {
        free(matrix);
    }
}

/* 将uint256转换为字符串表示 - 与abcmint-master完全兼容 */
static void uint256ToString(uint256 hash, char* str_out) {
    if (!str_out) {
        LOGERROR("uint256ToString: 空的输出缓冲区");
        return;
    }
    
    // 确保输出缓冲区有足够的空间
    // 按照abcmint-master的实现，正确处理字节顺序
    uint8_t hash_bytes[32];
    uint256_to_bytes(&hash, hash_bytes);
    for (int i = 0; i < 32; i++) {
        sprintf(str_out + i*2, "%02x", hash_bytes[i]);
    }
    str_out[64] = '\0';
}

/* 获取区块高度 - 根据prevblockhash和区块版本计算 */
static int GetBlockHeight(uint256 prevblockhash, int nblockversion) {
    int height = 0;
    uint256 initHash;
    uint256_set_zero(&initHash);
    
    if (uint256_equal(&prevblockhash, &initHash)) {
        // 创世区块
        return 0;
    }
    
    // 尝试获取区块索引
    CBlockIndex* pindexPrev = GetBlockIndexFromHash(prevblockhash);
    if (pindexPrev) {
        return pindexPrev->nHeight + 1;
    }
    
    // 如果无法获取区块索引，根据区块版本和全局信息估算
    // 这是与abcmint-master一致的备用逻辑
    if (nblockversion < BLOCK_VERSION2_BEFORE_FORK) {
        height = 0;
    } else if (nblockversion < BLOCK_CURRENT_VERSION) {
        height = 25217;
    } else {
        height = RAINBOWFORKHEIGHT;
    }
    
    LOGWARN("GetBlockHeight: 无法从prevblockhash获取区块高度，使用备用估算: %d", height);
    return height;
}

/* 检查解决方案是否满足方程 - 与abcmint-master完全兼容的实现 */
bool CheckSolution(uint256 hash, unsigned int nBits, uint256 prevblockhash, int nblockversion, uint256 nNonce) {
    // 验证输入参数
    if (nBits == 0 || nBits > 64) {
        LOGWARN("CheckSolution: 无效的nBits值: %u", nBits);
        return false;
    }
    
    // 计算区块高度 - 与abcmint-master完全一致的逻辑
    int height = GetBlockHeight(prevblockhash, nblockversion);
    
    // 检查区块版本是否有效
    if (nblockversion < 1 || nblockversion > BLOCK_CURRENT_VERSION) {
        LOGWARN("CheckSolution: 无效的区块版本: %d", nblockversion);
        return false;
    }
    
    // 根据区块高度选择正确的算法参数 - 与abcmint-master完全一致
    unsigned int nUnknowns;
    unsigned int mEquations;
    
    if (height < RAINBOWFORKHEIGHT) {
        nUnknowns = RAINBOW_UNKNOWNS_OLD;  // 32个未知数
        mEquations = RAINBOW_EQUATIONS_OLD; // 24个方程
    } else {
        nUnknowns = RAINBOW_UNKNOWNS_NEW;  // 40个未知数
        mEquations = RAINBOW_EQUATIONS_NEW; // 30个方程
    }
    
    LOGDEBUG("CheckSolution: 区块高度=%d, 未知数=%u, 方程数=%u", height, nUnknowns, mEquations);
    
    // 计算项数 = 1(常数项) + nUnknowns(一次项) + nUnknowns*(nUnknowns-1)/2(二次项)
    unsigned int nTerms = 1 + nUnknowns + (nUnknowns * (nUnknowns - 1)) / 2;
    
    // 使用优化的内存分配
    uint8_t* coeffMatrix = alloc_coeff_matrix(mEquations * nTerms);
    if (!coeffMatrix) {
        LOGERROR("CheckSolution: 系数矩阵内存分配失败");
        return false;
    }
    
    // 根据区块高度选择正确的系数矩阵生成函数 - 与abcmint-master完全一致
    if (height < 25217) {
        GenCoeffMatrix(hash, nBits, coeffMatrix);
    } else if (height < RAINBOWFORKHEIGHT) {
        NewGenCoeffMatrix(hash, nBits, coeffMatrix);
    } else {
        New2GenCoeffMatrix(hash, nBits, coeffMatrix);
    }
    
    // 从nonce提取解决方案位
    uint8_t x[nUnknowns];
    Uint256ToSolutionBits(x, nUnknowns, nNonce);
    
    // 验证解决方案
    bool valid = true;
    unsigned int count = 0;
    
    // 优化循环结构，减少条件检查
    for (unsigned int k = 0; k < mEquations; k++) {
        uint8_t tempbit = 0;
        count = 0;
        
        // 计算二次项 (i < j)
        for (unsigned int i = 0; i < nUnknowns - 1; i++) {
            for (unsigned int j = i + 1; j < nUnknowns; j++) {
                if (count >= nTerms) {
                    LOGWARN("CheckSolution: 超出项数限制");
                    valid = false;
                    goto cleanup;
                }
                // 优化异或计算
                if (coeffMatrix[k * nTerms + count] && x[i] && x[j]) {
                    tempbit ^= 1;
                }
                count++;
            }
        }
        
        // 计算一次项
        for (unsigned int i = 0; i < nUnknowns; i++) {
            if (count >= nTerms) {
                LOGWARN("CheckSolution: 超出项数限制");
                valid = false;
                goto cleanup;
            }
            // 优化异或计算
            if (coeffMatrix[k * nTerms + count] && x[i]) {
                tempbit ^= 1;
            }
            count++;
        }
        
        // 计算常数项
        if (count >= nTerms) {
            LOGWARN("CheckSolution: 超出项数限制");
            valid = false;
            goto cleanup;
        }
        tempbit ^= coeffMatrix[k * nTerms + count];
        
        // 验证方程结果是否为0
        if (tempbit != 0) {
            LOGDEBUG("CheckSolution: 方程 %u 不满足，结果=%u", k, tempbit);
            valid = false;
            goto cleanup;
        }
    }
    
cleanup:
    // 使用优化的内存释放
    free_coeff_matrix(coeffMatrix);
    
    // 记录验证结果
    LOGDEBUG("CheckSolution: 验证完成，解有效性=%d", valid);
    return valid;
}

/* 将二进制数据转换为uint256 */
void bin_to_uint256(uint256* hash, const unsigned char* data, size_t len) {
    if (!hash || !data) {
        LOGERROR("bin_to_uint256: 无效的参数");
        return;
    }
    
    // 使用标准函数初始化uint256
    uint256_set_zero(hash);
    if (len > 32) {
        len = 32;
    }
    
    // 使用标准函数从字节数组转换
    uint256_from_bytes(hash, data);
}

/* 计算量子抗性挖矿的难度 - 与abcmint-master一致 */
double quantum_resistant_diff_from_solution(unsigned int nBits, uint256 nonce) {
    // 验证输入参数
    if (nBits == 0) {
        LOGWARN("quantum_resistant_diff_from_solution: 无效的nBits值: %u", nBits);
        return 0.0;
    }
    
    // 基础难度计算 - 基于方程数量和未知数数量
    unsigned int nUnknowns = nBits + 8;
    double base_difficulty = (double)nBits;
    
    // 计算解空间大小 - 解空间大小约为 2^(nUnknowns - nBits)
    double solution_space = pow(2, nUnknowns - nBits);
    
    // 使用对数计算难度调整因子，使难度值更平滑
    double log_space_factor = log(solution_space) / log(2.0);
    
    // 计算最终难度 - 使用更精确的公式，确保与abcmint-master完全一致
    double final_difficulty = base_difficulty * pow(2.0, log_space_factor / 256.0);
    
    // 确保难度值有效
    if (final_difficulty < 0.1) {
        final_difficulty = 0.1;
    }
    
    LOGDEBUG("量子抗性难度计算: nBits=%u, 解空间=%.0f, 解空间因子=%.2f, 难度=%.6f", 
             nBits, solution_space, log_space_factor, final_difficulty);
    
    return final_difficulty;
}

/* HTTP请求处理函数 - 使用libcurl或简化实现 */
static char* http_request(const char* url, const char* username, const char* password, const char* post_data, int timeout) {
    // 这里实现基本的HTTP请求
    // 在实际环境中，应该使用libcurl库实现更可靠的HTTP通信
    LOGDEBUG("http_request: 发送请求到 %s", url);
    return NULL; // 简化实现，返回NULL表示请求失败
}

/* 解析区块JSON响应 */
static bool parse_block_json(const char* json, CBlockIndex* index) {
    // 这里实现JSON解析逻辑
    // 在实际环境中，应该使用cJSON或其他JSON库
    LOGDEBUG("parse_block_json: 解析区块JSON数据");
    return false; // 简化实现，返回false表示解析失败
}

/* 初始化节点API */
bool InitNodeAPI(NodeAPIConfig* config) {
    pthread_mutex_lock(&g_api_mutex);
    
    // 清理之前的配置
    if (g_node_api_config) {
        free(g_node_api_config->url);
        free(g_node_api_config->username);
        free(g_node_api_config->password);
        free(g_node_api_config);
    }
    
    // 复制新配置
    g_node_api_config = (NodeAPIConfig*)ckzalloc(sizeof(NodeAPIConfig));
    if (!g_node_api_config) {
        pthread_mutex_unlock(&g_api_mutex);
        LOGERROR("InitNodeAPI: 内存分配失败");
        return false;
    }
    
    g_node_api_config->url = strdup(config->url ? config->url : "http://localhost:8882");
    g_node_api_config->username = strdup(config->username ? config->username : "");
    g_node_api_config->password = strdup(config->password ? config->password : "");
    g_node_api_config->timeout = config->timeout > 0 ? config->timeout : 5000;
    
    g_node_api_initialized = true;
    LOGINFO("InitNodeAPI: 节点API初始化完成，URL=%s", g_node_api_config->url);
    
    pthread_mutex_unlock(&g_api_mutex);
    return true;
}

/* 关闭节点API */
void CloseNodeAPI(void) {
    pthread_mutex_lock(&g_api_mutex);
    
    if (g_node_api_config) {
        free(g_node_api_config->url);
        free(g_node_api_config->username);
        free(g_node_api_config->password);
        free(g_node_api_config);
        g_node_api_config = NULL;
    }
    
    g_node_api_initialized = false;
    LOGINFO("CloseNodeAPI: 节点API已关闭");
    
    pthread_mutex_unlock(&g_api_mutex);
}

/* 从节点API获取区块信息 */
CBlockIndex* GetBlockByHashFromNode(uint256 hash) {
    pthread_mutex_lock(&g_api_mutex);
    
    if (!g_node_api_initialized || !g_node_api_config) {
        pthread_mutex_unlock(&g_api_mutex);
        LOGWARN("GetBlockByHashFromNode: 节点API未初始化");
        return NULL;
    }
    
    pthread_mutex_unlock(&g_api_mutex);
    
    // 构建RPC请求
    char hash_str[65];
    uint256ToString(hash, hash_str);
    
    char post_data[256];
    snprintf(post_data, sizeof(post_data), 
             "{\"jsonrpc\":\"1.0\",\"id\":\"abcmint-ckpool\",\"method\":\"getblock\",\"params\":[\"%s\"]}", 
             hash_str);
    
    // 发送HTTP请求
    char* response = http_request(g_node_api_config->url, 
                                 g_node_api_config->username,
                                 g_node_api_config->password,
                                 post_data,
                                 g_node_api_config->timeout);
    
    if (!response) {
        LOGERROR("GetBlockByHashFromNode: HTTP请求失败");
        return NULL;
    }
    
    // 分配区块索引
    CBlockIndex* index = (CBlockIndex*)ckzalloc(sizeof(CBlockIndex));
    if (!index) {
        free(response);
        LOGERROR("GetBlockByHashFromNode: 内存分配失败");
        return NULL;
    }
    
    // 解析响应
    if (!parse_block_json(response, index)) {
        ckzfree(index);
        free(response);
        LOGERROR("GetBlockByHashFromNode: 解析JSON失败");
        return NULL;
    }
    
    free(response);
    
    // 设置元数据
    index->hashBlock = hash;
    index->last_updated = time(NULL);
    index->is_from_api = true;
    
    LOGDEBUG("GetBlockByHashFromNode: 从节点获取区块，高度=%d, 版本=%d", 
             index->nHeight, index->nVersion);
    
    return index;
}

/* 初始化区块索引缓存 - 兼容旧接口，内部调用abcmint_compat.c中的实现 */
bool InitBlockIndexCache2(size_t capacity) {
    // 调用abcmint_compat.c中的实现
    InitBlockIndexCache();
    LOGINFO("InitBlockIndexCache2: 区块索引缓存初始化完成");
    return true;
}

/* 关闭区块索引缓存 - 使用全局block_index_cache结构 */
void CloseBlockIndexCache(void) {
    // 调用abcmint_compat.c中的ClearBlockIndexCache函数
    ClearBlockIndexCache();
    pthread_mutex_destroy(&block_index_cache.mutex);
    LOGINFO("CloseBlockIndexCache: 区块索引缓存已关闭");
}

/* 注意：AddBlockIndexToCache函数现在在abcmint_compat.c中实现 */

/* 从缓存获取区块索引 - 使用全局block_index_cache结构 */
CBlockIndex* GetBlockIndexFromCache(uint256 hash) {
    pthread_mutex_lock(&block_index_cache.mutex);
    
    // 线性查找
    for (int i = 0; i < block_index_cache.count; i++) {
        if (block_index_cache.index_array[i] && uint256_equal(&block_index_cache.hash_array[i], &hash)) {
            // 找到匹配的哈希，创建临时副本返回
            static CBlockIndex temp_index;
            memcpy(&temp_index, block_index_cache.index_array[i], sizeof(CBlockIndex));
            
            // 确保temp_index的phashBlock指向自己的hashBlock
            temp_index.phashBlock = &temp_index.hashBlock;
            temp_index.hashBlock = block_index_cache.hash_array[i];
            
            pthread_mutex_unlock(&block_index_cache.mutex);
            LOGDEBUG("GetBlockIndexFromCache: 从缓存获取区块，高度=%d", temp_index.nHeight);
            return &temp_index;
        }
    }
    
    pthread_mutex_unlock(&block_index_cache.mutex);
    return NULL;
}

/* 清理过期的缓存条目 - 使用全局block_index_cache结构 */
void ClearExpiredCacheEntries(time_t expiry_time) {
    pthread_mutex_lock(&block_index_cache.mutex);
    
    int new_count = 0;
    for (int i = 0; i < block_index_cache.count; i++) {
        if (block_index_cache.index_array[i]) {
            // 保留所有有效条目（简化实现，不再基于时间过期）
            block_index_cache.index_array[new_count] = block_index_cache.index_array[i];
            block_index_cache.hash_array[new_count] = block_index_cache.hash_array[i];
            new_count++;
        }
    }
    
    // 清空多余的条目
    for (int i = new_count; i < block_index_cache.count; i++) {
        block_index_cache.index_array[i] = NULL;
        uint256_set_zero(&block_index_cache.hash_array[i]);
    }
    
    block_index_cache.count = new_count;
    LOGDEBUG("ClearExpiredCacheEntries: 缓存清理完成，剩余条目=%d", block_index_cache.count);
    
    pthread_mutex_unlock(&block_index_cache.mutex);
}

/* 增强的区块索引获取函数 */
CBlockIndex* EnhancedGetBlockIndexFromHash(uint256 hash) {
    // 首先检查最佳区块
    if (pindexBest && uint256_equal(&hash, &pindexBest->hashBlock)) {
        return pindexBest;
    }
    
    // 尝试从缓存获取
    CBlockIndex* cached_index = GetBlockIndexFromCache(hash);
    if (cached_index) {
        return cached_index;
    }
    
    // 尝试从节点API获取
    CBlockIndex* api_index = GetBlockByHashFromNode(hash);
    if (api_index) {
        // 添加到缓存
        AddBlockIndexToCache(api_index);
        
        // 如果是最佳区块，更新全局指针
        if (pindexBest == NULL || api_index->nHeight > pindexBest->nHeight) {
            if (pindexBest) {
                // 保存旧的最佳区块引用
                AddBlockIndexToCache(pindexBest);
            }
            pindexBest = api_index;
        } else {
            // 如果不是最佳区块，复制数据后释放
            static CBlockIndex temp_index;
            memcpy(&temp_index, api_index, sizeof(CBlockIndex));
            // 确保temp_index的phashBlock指向自己的hashBlock
            temp_index.phashBlock = &temp_index.hashBlock;
            ckfree(api_index);
            return &temp_index;
        }
        
        return api_index;
    }
    
    // 如果所有方法都失败，回退到临时索引
    LOGWARN("EnhancedGetBlockIndexFromHash: 无法获取真实区块信息，使用临时索引");
    
    static CBlockIndex temp_index;
    memset(&temp_index, 0, sizeof(CBlockIndex));
    temp_index.hashBlock = hash;
    temp_index.phashBlock = &temp_index.hashBlock; // 确保phashBlock有效
    temp_index.nHeight = pindexBest ? pindexBest->nHeight : 0;
    temp_index.nVersion = BLOCK_VERSION2_BEFORE_FORK;
    
    return &temp_index;
}

/* 区块验证兼容性测试函数 */
bool TestBlockValidationCompatibility(void) {
    LOGINFO("开始区块验证兼容性测试...");
    
    // 测试1：uint256操作测试
    uint256 a, b, c;
    uint256_set_zero(&a);
    uint256_set_zero(&b);
    uint256_set_zero(&c);
    
    // 设置一些测试值
    uint64_t test_val = 0x123456789ABCDEF0ULL;
    uint256_set_uint64(&a, test_val);
    uint256_assign(&b, &a);
    
    if (!uint256_equal(&a, &b)) {
        LOGERROR("uint256测试失败：赋值和比较操作不正确");
        return false;
    }
    
    // 测试2：区块高度计算测试
    uint256 genesis_hash;
    uint256_set_zero(&genesis_hash);
    
    int genesis_height = GetBlockHeight(genesis_hash, BLOCK_VERSION2_BEFORE_FORK);
    if (genesis_height != 0) {
        LOGERROR("区块高度计算测试失败：创世区块高度应为0，实际为%d", genesis_height);
        return false;
    }
    
    // 测试3：版本兼容性测试
    bool is_rainbow = abcmint_is_rainbow18_block(BLOCK_CURRENT_VERSION);
    if (!is_rainbow) {
        LOGERROR("版本兼容性测试失败：当前版本应被识别为Rainbow18区块");
        return false;
    }
    
    // 测试4：难度计算测试
    uint8_t target[32] = {0x01, 0x23, 0x45, 0x00};
    double difficulty = CalculateRainbowDifficulty(BLOCK_CURRENT_VERSION, RAINBOWFORKHEIGHT, target);
    double expected_diff = (0x01 << 16) | (0x23 << 8) | 0x45;
    
    if (fabs(difficulty - expected_diff) > 0.001) {
        LOGERROR("难度计算测试失败：计算难度为%.2f，预期为%.2f", difficulty, expected_diff);
        return false;
    }
    
    // 测试5：区块索引缓存测试
    InitBlockIndexCache(); // 直接调用abcmint_compat.c中的函数
    
    // 创建测试区块索引
    CBlockIndex* test_index = (CBlockIndex*)malloc(sizeof(CBlockIndex));
    if (!test_index) {
        LOGERROR("区块索引创建测试失败：内存分配失败");
        return false;
    }
    
    // 初始化测试区块索引
    memset(test_index, 0, sizeof(CBlockIndex));
    test_index->hashBlock = genesis_hash;
    test_index->phashBlock = &test_index->hashBlock;
    test_index->nHeight = 100;
    test_index->nVersion = BLOCK_CURRENT_VERSION;
    test_index->nTime = time(NULL);
    
    // 添加到缓存
    AddBlockIndexToCache(test_index);
    
    // 从缓存获取
    CBlockIndex* cached_index = GetBlockIndexFromCache(genesis_hash);
    if (!cached_index || cached_index->nHeight != 100) {
        LOGERROR("区块索引缓存测试失败：无法正确获取缓存的区块索引");
        free(test_index);
        ClearBlockIndexCache();
        return false;
    }
    
    free(test_index);
    ClearBlockIndexCache();
    
    LOGINFO("区块验证兼容性测试全部通过！");
    return true;
}

/* 动态负载均衡的线程分区 */
void DynamicThreadPartitioning(uint64_t search_space, int thread_count, uint64_t* start_ranges, uint64_t* end_ranges) {
    if (!start_ranges || !end_ranges || thread_count <= 0 || search_space == 0) {
        LOGERROR("DynamicThreadPartitioning: 无效参数");
        return;
    }
    
    // 计算基础分区大小
    uint64_t base_partition = search_space / thread_count;
    uint64_t remainder = search_space % thread_count;
    
    // 分配分区范围，确保包含余数
    uint64_t current_start = 0;
    for (int i = 0; i < thread_count; i++) {
        start_ranges[i] = current_start;
        
        // 分配基础分区大小，前remainder个线程多分配1个单位
        uint64_t partition_size = base_partition + (i < remainder ? 1 : 0);
        
        // 确保不会溢出
        end_ranges[i] = (current_start + partition_size > search_space) ? 
                       search_space : current_start + partition_size;
        
        current_start = end_ranges[i];
    }
    
    LOGDEBUG("DynamicThreadPartitioning: 搜索空间=%llu, 线程数=%d, 基础分区=%llu, 余数=%llu",
             (unsigned long long)search_space, thread_count,
             (unsigned long long)base_partition, (unsigned long long)remainder);
    
    // 可选：根据历史性能数据调整分区大小
    // 这里可以实现更复杂的负载均衡策略，例如基于每个CPU核心的历史性能
}

/* 增强的区块索引获取函数 - 支持缓存和快速查找 */
CBlockIndex* EnhancedGetBlockIndexFromHash(uint256 hash) {
    static CBlockIndex* last_found_index = NULL;
    static uint256 last_hash = {{0}};
    
    // 快速路径：检查是否是最近查询过的哈希
    if (last_found_index && hash == last_hash) {
        LOGDEBUG("EnhancedGetBlockIndexFromHash: 命中快速缓存");
        return last_found_index;
    }
    
    // 实现与abcmint-master一致的区块索引查找逻辑
    // 这里使用一个简化的实现，实际应根据abcmint-master的实现进行调整
    LOGDEBUG("EnhancedGetBlockIndexFromHash: 查找区块哈希");
    
    // 尝试从全局区块映射中获取
    // 在实际实现中，这里应该使用与abcmint-master相同的映射结构
    // 例如：mapBlockIndex.find(hash)或类似的查找方法
    
    // 由于ckpool环境的特殊性，我们可能需要从其他来源获取区块索引
    // 这部分逻辑需要根据实际环境进行调整
    
    // 注意：在实际集成环境中，这里应该使用与abcmint-master完全相同的区块索引查找逻辑
    // 此处为简化实现
    last_hash = hash;
    
    // 如果找不到区块索引，返回NULL
    return NULL;
}

/* 从哈希获取区块索引 - 兼容旧接口，内部使用增强版本 */
CBlockIndex* GetBlockIndexFromHash(uint256 hash) {
    return EnhancedGetBlockIndexFromHash(hash);
}

/* 搜索解决方案 - 与abcmint-master完全兼容的版本 */
uint256 SerchSolution(uint256 hash, unsigned int nBits, uint256 randomNonce, CBlockIndex* pindexPrev, int deviceID, int deviceCount) {
    uint256 nonce = {{0}};
    int height = 0;
    
    // 获取区块高度
    if (pindexPrev) {
        height = pindexPrev->nHeight + 1;
    }
    
    LOGDEBUG("SerchSolution: 开始搜索解决方案，区块高度=%d, 难度=%u, 设备ID=%d/%d", 
             height, nBits, deviceID, deviceCount);
    
#ifdef USE_GPU
    // GPU挖矿支持
    if (GetDeviceCount() > 0) {
        LOGDEBUG("SerchSolution: 使用GPU模式搜索");
        
        // 设置GPU设备
        SetDevice(deviceID % GetDeviceCount());
        
        // 调用GPU挖矿函数 - 确保参数与abcmint-master一致
        nonce = GPUMinerSearchSolution(hash, nBits, randomNonce, pindexPrev, deviceID, deviceCount);
        
        // 验证找到的解
        if (pindexPrev && CheckSolution(hash, nBits, pindexPrev->hashPrevBlock, pindexPrev->nVersion, nonce)) {
            LOGINFO("SerchSolution: GPU模式找到有效解");
            return nonce;
        }
        LOGWARN("SerchSolution: GPU模式未找到有效解或验证失败，回退到CPU模式");
    }
#endif
    
    // CPU模式搜索 - 确保与abcmint-master完全一致
    LOGDEBUG("SerchSolution: 使用CPU模式搜索");
    
    // 根据区块高度选择正确的方程参数
    unsigned int mEquations, nUnknowns;
    if (height < RAINBOWFORKHEIGHT) {
        mEquations = 24;
        nUnknowns = 32;
    } else {
        mEquations = 30;
        nUnknowns = 40;
    }
    
    // 计算总项数
    unsigned int nTerms = 1 + nUnknowns + (nUnknowns * (nUnknowns - 1)) / 2;
    
    LOGDEBUG("SerchSolution: 方程参数 - 方程数=%u, 未知数=%u, 总项数=%u", 
             mEquations, nUnknowns, nTerms);
    
    // 分配系数矩阵内存
    uint8_t* coeffMatrix = alloc_coeff_matrix(mEquations * nTerms);
    if (!coeffMatrix) {
        LOGERROR("SerchSolution: 系数矩阵内存分配失败");
        return nonce;
    }
    
    // 根据区块高度选择正确的系数矩阵生成函数 - 与abcmint-master完全一致
    if (height < 25217) {
        GenCoeffMatrix(hash, nBits, coeffMatrix);
    } else if (height < RAINBOWFORKHEIGHT) {
        NewGenCoeffMatrix(hash, nBits, coeffMatrix);
    } else {
        New2GenCoeffMatrix(hash, nBits, coeffMatrix);
    }
    
    // 创建方程数据结构 - 确保使用与abcmint-master完全相同的二次型结构
    int*** Eqs = CreateEquations(nUnknowns, mEquations);
    if (!Eqs) {
        LOGERROR("SerchSolution: 创建方程数据结构失败");
        free_coeff_matrix(coeffMatrix);
        return nonce;
    }
    
    uint64_t maxsol = 1; // 只需要一个解
    uint64_t** SolArray = CreateArray(maxsol);
    if (!SolArray) {
        LOGERROR("SerchSolution: 创建解数组失败");
        FreeEquations(mEquations, Eqs);
        free_coeff_matrix(coeffMatrix);
        return nonce;
    }
    
    // 设置起始点 - 与abcmint-master一致的初始化方式
    uint64_t startPoint[4] = {0}; // 初始化为0
    
    // 从randomNonce中提取数据作为起始点 - 确保与abcmint-master的提取方式一致
    for (int i = 0; i < 4 && i < sizeof(randomNonce.data)/8; i++) {
        uint8_t nonce_bytes[32];
        uint256_to_bytes(&randomNonce, nonce_bytes);
        uint64_t val = 0;
        for (int j = 0; j < 8 && i*8 + j < 32; j++) {
            val |= ((uint64_t)nonce_bytes[i*8 + j]) << (j * 8);
        }
        startPoint[i] = val;
    }
    
    LOGDEBUG("SerchSolution: 起始点设置完成");
    
    // 转换数据结构并执行搜索 - 确保使用正确的二次型结构
    TransformDataStructure(nUnknowns, mEquations, coeffMatrix, Eqs);
    
    // 计算搜索变量数量 - 与abcmint-master完全一致的策略
    int nSearchVariables;
    if (height < RAINBOWFORKHEIGHT) {
        nSearchVariables = 12; // 前fork: 12个搜索变量
    } else {
        nSearchVariables = 15; // 后fork: 15个搜索变量
    }
    
    LOGDEBUG("SerchSolution: 搜索变量数量=%d, 线程分区ID=%d/%d", 
             nSearchVariables, deviceID, deviceCount);
    
    // 执行exfes搜索 - 使用正确的搜索变量数量
    exfes(nSearchVariables, nUnknowns, mEquations, startPoint, maxsol, Eqs, SolArray, pindexPrev, deviceID, deviceCount);
    
    // 报告解决方案 - 调用与abcmint-master一致的ReportSolution函数
    ReportSolution(maxsol, SolArray, &nonce);
    
    // 验证找到的解 - 与abcmint-master完全一致的验证逻辑
    bool solutionValid = false;
    uint8_t nonce_bytes[32];
    uint256_to_bytes(&nonce, nonce_bytes);
    if (pindexPrev && nonce_bytes[0] != 0) {
        LOGINFO("SerchSolution: CPU模式找到解，进行验证");
        
        // 使用CheckSolution进行解的有效性验证
        if (CheckSolution(hash, nBits, pindexPrev->hashPrevBlock, pindexPrev->nVersion, nonce)) {
            LOGINFO("SerchSolution: CPU模式找到有效解");
            solutionValid = true;
        } else {
            LOGWARN("SerchSolution: 找到的解验证失败");
            // 如果验证失败，重置为无效解
            uint256_set_zero(&nonce);
        }
    } else if (nonce_bytes[0] == 0) {
        LOGWARN("SerchSolution: CPU模式未找到解");
    }
    
    // 按正确顺序释放资源
    FreeEquations(mEquations, Eqs);
    FreeArray(maxsol, SolArray);
    free_coeff_matrix(coeffMatrix);
    
    LOGDEBUG("SerchSolution: 搜索完成，是否找到有效解: %d", solutionValid);
    return nonce;
}

/* 搜索解决方案 - 支持CPU和GPU模式 */
uint256 SearchSolution(uint256 hash, unsigned int nBits, uint256 randomNonce, uint256 prevblockhash, 
                      int nblockversion, int threadID, int threadCount) {
    LOGDEBUG("SearchSolution: 开始搜索解决方案，nBits=%u, 线程ID=%d/%d", 
             nBits, threadID, threadCount);
    
    uint256 nonce = {{0}};
    
#ifdef USE_GPU
    // 检查是否有可用的GPU设备
    if (GetDeviceCount() > 0) {
        LOGDEBUG("SearchSolution: 使用GPU模式搜索");
        // 设置设备
        SetDevice(threadID % GetDeviceCount());
        // 使用GPU挖矿
        nonce = GPUMinerSearchSolution(hash, nBits, randomNonce, prevblockhash, 
                                      nblockversion, threadID, threadCount);
        // 验证找到的解
        if (CheckSolution(hash, nBits, prevblockhash, nblockversion, nonce)) {
            LOGINFO("SearchSolution: GPU模式找到有效解");
            return nonce;
        }
        LOGWARN("SearchSolution: GPU模式未找到有效解，回退到CPU模式");
    }
#endif
    
    // 使用SerchSolution函数作为实际实现
    // 首先从prevblockhash获取CBlockIndex
    CBlockIndex* pindexPrev = GetBlockIndexFromHash(prevblockhash);
    if (!pindexPrev) {
        LOGERROR("SearchSolution: 无法获取区块索引");
        return nonce;
    }
    
    // 设置区块版本
    pindexPrev->nVersion = nblockversion;
    
    // 调用SerchSolution函数
    nonce = SerchSolution(hash, nBits, randomNonce, pindexPrev, threadID, threadCount);
    
    // 验证解决方案
    uint8_t nonce_bytes[32];
    uint256_to_bytes(&nonce, nonce_bytes);
    if (nonce_bytes[0] == 0 && nonce_bytes[1] == 0) {
        LOGWARN("SearchSolution: 未找到有效解");
    } else {
        LOGINFO("SearchSolution: 找到有效解");
    }
    
    return nonce;
}

#include "rainbow18_compat.h" // 包含rainbow18兼容性头文件

// 辅助函数：计算基于rainbow18算法的难度调整
double quantum_resistant_calculate_difficulty(uint32_t block_version, size_t block_height, const uint8_t *target) {
    // 验证输入参数
    if (!target) {
        LOGERROR("quantum_resistant_calculate_difficulty: 空的target参数");
        return 0.0;
    }
    
    // 从目标哈希中提取nBits值
    // 根据abcmint-master的实现，nBits直接表示方程数量
    uint32_t nBits = (target[0] << 16) | (target[1] << 8) | target[2];
    
    // 与abcmint-master保持一致：直接返回nBits值作为难度
    // 在abcmint-master中，GetDifficulty函数直接返回blockindex->nBits
    double difficulty = (double)nBits;
    
    LOGDEBUG("quantum_resistant_calculate_difficulty: 区块版本=%u, 区块高度=%zu, nBits=%u, 难度=%.4f",
             block_version, block_height, nBits, difficulty);
    
    return difficulty;
}

/* 内存池管理 - 用于优化频繁的内存分配/释放 */

// 内存块结构
typedef struct {
    void* ptr;
    size_t size;
    bool in_use;
} MemoryBlock;

// 内存池结构
typedef struct {
    MemoryBlock* blocks;
    size_t capacity;
    size_t count;
    pthread_mutex_t mutex;
} MemoryPool;

// 全局内存池
static MemoryPool* coeff_matrix_pool = NULL;
static MemoryPool* equation_pool = NULL;

// 初始化内存池
static MemoryPool* init_memory_pool(size_t initial_capacity) {
    MemoryPool* pool = (MemoryPool*)ckzalloc(sizeof(MemoryPool));
    if (!pool) {
        LOGERROR("init_memory_pool: 内存分配失败");
        return NULL;
    }
    
    pool->blocks = (MemoryBlock*)ckzalloc(initial_capacity * sizeof(MemoryBlock));
    if (!pool->blocks) {
        LOGERROR("init_memory_pool: 内存块数组分配失败");
        ckzfree(pool);
        return NULL;
    }
    
    pool->capacity = initial_capacity;
    pool->count = 0;
    pthread_mutex_init(&pool->mutex, NULL);
    
    LOGDEBUG("内存池初始化成功，初始容量=%zu", initial_capacity);
    return pool;
}

// 从内存池分配内存
static void* pool_alloc(MemoryPool* pool, size_t size) {
    if (!pool) {
        LOGERROR("pool_alloc: 无效的内存池");
        return ckzalloc(size);
    }
    
    pthread_mutex_lock(&pool->mutex);
    
    // 查找可用的内存块
    for (size_t i = 0; i < pool->count; i++) {
        if (!pool->blocks[i].in_use && pool->blocks[i].size >= size) {
            pool->blocks[i].in_use = true;
            pthread_mutex_unlock(&pool->mutex);
            LOGDEBUG("内存池分配: 复用块 %zu, 大小=%zu", i, size);
            return pool->blocks[i].ptr;
        }
    }
    
    // 如果没有足够大的可用块，分配新块
    if (pool->count >= pool->capacity) {
        // 扩展内存池
        size_t new_capacity = pool->capacity * 2;
        MemoryBlock* new_blocks = (MemoryBlock*)ckzalloc(new_capacity * sizeof(MemoryBlock));
        if (!new_blocks) {
            pthread_mutex_unlock(&pool->mutex);
            LOGERROR("pool_alloc: 内存池扩展失败");
            return ckzalloc(size);
        }
        
        // 复制现有块
        memcpy(new_blocks, pool->blocks, pool->capacity * sizeof(MemoryBlock));
        ckzfree(pool->blocks);
        pool->blocks = new_blocks;
        pool->capacity = new_capacity;
        LOGDEBUG("内存池已扩展至容量=%zu", new_capacity);
    }
    
    // 分配新的内存块
    void* ptr = ckzalloc(size);
    if (ptr) {
        pool->blocks[pool->count].ptr = ptr;
        pool->blocks[pool->count].size = size;
        pool->blocks[pool->count].in_use = true;
        pool->count++;
        LOGDEBUG("内存池分配: 新块 %zu, 大小=%zu", pool->count - 1, size);
    }
    
    pthread_mutex_unlock(&pool->mutex);
    return ptr;
}

// 释放内存回内存池
static void pool_free(MemoryPool* pool, void* ptr) {
    if (!pool || !ptr) {
        ckzfree(ptr);
        return;
    }
    
    pthread_mutex_lock(&pool->mutex);
    
    // 查找并释放对应的内存块
    for (size_t i = 0; i < pool->count; i++) {
        if (pool->blocks[i].in_use && pool->blocks[i].ptr == ptr) {
            pool->blocks[i].in_use = false;
            LOGDEBUG("内存池释放: 块 %zu", i);
            pthread_mutex_unlock(&pool->mutex);
            return;
        }
    }
    
    // 如果没有找到对应的块，直接释放内存
    pthread_mutex_unlock(&pool->mutex);
    LOGWARN("pool_free: 未找到对应的内存块，直接释放");
    ckzfree(ptr);
}

// 清理内存池
static void cleanup_memory_pool(MemoryPool** pool_ptr) {
    if (!pool_ptr || !*pool_ptr) {
        return;
    }
    
    MemoryPool* pool = *pool_ptr;
    
    // 释放所有内存块
    for (size_t i = 0; i < pool->count; i++) {
        if (pool->blocks[i].ptr) {
            ckzfree(pool->blocks[i].ptr);
        }
    }
    
    // 释放内存池本身
    ckzfree(pool->blocks);
    pthread_mutex_destroy(&pool->mutex);
    ckzfree(pool);
    *pool_ptr = NULL;
    
    LOGDEBUG("内存池已清理");
}

/* 初始化内存管理系统 */
void quantum_resistant_init_memory() {
    // 初始化系数矩阵内存池
    coeff_matrix_pool = init_memory_pool(32);
    // 初始化方程内存池
    equation_pool = init_memory_pool(32);
    
    LOGINFO("量子抗性挖矿内存管理系统初始化完成");
}

/* 清理内存管理系统 */
void quantum_resistant_cleanup_memory() {
    // 清理内存池
    cleanup_memory_pool(&coeff_matrix_pool);
    cleanup_memory_pool(&equation_pool);
    
    LOGINFO("量子抗性挖矿内存管理系统已清理");
}

/* 优化的系数矩阵内存分配 */
static uint8_t* alloc_coeff_matrix(size_t size) {
    return (uint8_t*)pool_alloc(coeff_matrix_pool, size);
}

/* 优化的系数矩阵内存释放 */
static void free_coeff_matrix(uint8_t* ptr) {
    pool_free(coeff_matrix_pool, ptr);
}

/* 计算二项式系数 n!/(k!(n-k)!) */
static int Binomial(int n, int m) {
    if (m == 0) return 1;
    else if (m == 1) return n;
    else if (m == 2) return n*(n-1)/2;
    else return 0;
}

/* M宏定义，用于从startPoint中提取第j位 */
#define M(startPoint, j) ( ((j) < 64) ? (startPoint[0] >> (j)) & 1 : (startPoint[1] >> (j-64)) & 1 )

/* 实现高级搜索相关函数 - 与abcmint-master兼容 */
// 确保在文件顶部添加了#include <boost/thread.hpp>

int*** CreateEquations(unsigned int nUnknowns, unsigned int mEquations) {
    int ***Eqs = (int***)ckzalloc(mEquations * sizeof(int**));
    if (!Eqs) {
        return NULL;
    }
    for (int i=0; i<mEquations; i++) {
        Eqs[i] = (int**)ckzalloc(3 * sizeof(int*));
        if (!Eqs[i]) {
            for (int j=0; j<i; j++) {
                if (Eqs[j]) {
                    if (Eqs[j][2]) ckzfree(Eqs[j][2]);
                    if (Eqs[j][1]) ckzfree(Eqs[j][1]);
                    if (Eqs[j][0]) ckzfree(Eqs[j][0]);
                    ckzfree(Eqs[j]);
                }
            }
            ckzfree(Eqs);
            return NULL;
        }
        // 常数项始终只有1个值
        Eqs[i][0] = (int*)ckzalloc(1 * sizeof(int));
        if (!Eqs[i][0]) {
            ckzfree(Eqs[i]);
            for (int j=0; j<i; j++) {
                if (Eqs[j]) {
                    if (Eqs[j][2]) ckzfree(Eqs[j][2]);
                    if (Eqs[j][1]) ckzfree(Eqs[j][1]);
                    if (Eqs[j][0]) ckzfree(Eqs[j][0]);
                    ckzfree(Eqs[j]);
                }
            }
            ckzfree(Eqs);
            return NULL;
        }
        // 一次项有nUnknowns个值
        Eqs[i][1] = (int*)ckzalloc(nUnknowns * sizeof(int));
        if (!Eqs[i][1]) {
            ckzfree(Eqs[i][0]);
            ckzfree(Eqs[i]);
            for (int j=0; j<i; j++) {
                if (Eqs[j]) {
                    if (Eqs[j][2]) ckzfree(Eqs[j][2]);
                    if (Eqs[j][1]) ckzfree(Eqs[j][1]);
                    if (Eqs[j][0]) ckzfree(Eqs[j][0]);
                    ckzfree(Eqs[j]);
                }
            }
            ckzfree(Eqs);
            return NULL;
        }
        // 二次项有Binomial(nUnknowns, 2)个值
        int nQuadraticTerms = Binomial(nUnknowns, 2);
        Eqs[i][2] = (int*)ckzalloc(nQuadraticTerms * sizeof(int));
        if (!Eqs[i][2]) {
            ckzfree(Eqs[i][1]);
            ckzfree(Eqs[i][0]);
            ckzfree(Eqs[i]);
            for (int j=0; j<i; j++) {
                if (Eqs[j]) {
                    if (Eqs[j][2]) ckzfree(Eqs[j][2]);
                    if (Eqs[j][1]) ckzfree(Eqs[j][1]);
                    if (Eqs[j][0]) ckzfree(Eqs[j][0]);
                    ckzfree(Eqs[j]);
                }
            }
            ckzfree(Eqs);
            return NULL;
        }
    }
    return Eqs;
}

void FreeEquations(unsigned int mEquations, int*** Eqs) {
    if (!Eqs) return;
    for (int i=0; i<mEquations; i++) {
        if (Eqs[i]) {
            if (Eqs[i][2]) ckzfree(Eqs[i][2]);
            if (Eqs[i][1]) ckzfree(Eqs[i][1]);
            if (Eqs[i][0]) ckzfree(Eqs[i][0]);
            ckzfree(Eqs[i]);
        }
    }
    ckzfree(Eqs);
}

uint64_t** CreateArray(uint64_t maxsol) {
    uint64_t** SolArray = (uint64_t**)ckzalloc(maxsol * sizeof(uint64_t*));
    if (!SolArray) {
        LOGERROR("CreateArray: 内存分配失败");
        return NULL;
    }
    
    for (uint64_t i = 0; i < maxsol; i++) {
        SolArray[i] = (uint64_t*)ckzalloc(maxsol * sizeof(uint64_t));
        if (!SolArray[i]) {
            LOGERROR("CreateArray: 为解 %llu 分配内存失败", i);
            // 清理已分配的内存
            for (uint64_t j = 0; j < i; j++) {
                ckzfree(SolArray[j]);
            }
            ckzfree(SolArray);
            return NULL;
        }
        
        // 初始化解数组
        memset(SolArray[i], 0, maxsol * sizeof(uint64_t));
    }
    
    return SolArray;
}

void FreeArray(uint64_t maxsol, uint64_t** SolArray) {
    if (!SolArray) return;
    
    for (uint64_t i = 0; i < maxsol; i++) {
        if (SolArray[i]) {
            ckzfree(SolArray[i]);
        }
    }
    ckzfree(SolArray);
}

void TransformDataStructure(unsigned int nUnknowns, unsigned int mEquations, uint8_t* coeffMatrix, int*** Eqs) {
    // 将系数矩阵转换为二次型方程数据结构 - 与abcmint-master兼容
    unsigned int nTerms = 1 + (nUnknowns + 1) * nUnknowns / 2;
    
    for (unsigned int k = 0; k < mEquations; k++) {
        unsigned int count = 0;
        
        // 1. 设置二次项系数 (i < j)
        unsigned int offset = 0;
        for (unsigned int i = 0; i < nUnknowns; i++) {
            for (unsigned int j = i + 1; j < nUnknowns; j++) {
                if (count >= nTerms) {
                    break;
                }
                Eqs[k][2][offset] = coeffMatrix[k * nTerms + count];
                count++;
                offset++;
            }
            if (count >= nTerms) break;
        }
        
        // 2. 设置一次项系数
        for (unsigned int i = 0; i < nUnknowns; i++) {
            if (count >= nTerms) {
                break;
            }
            Eqs[k][1][i] = coeffMatrix[k * nTerms + count];
            count++;
        }
        
        // 3. 设置常数项
        if (count < nTerms) {
            Eqs[k][0][0] = coeffMatrix[k * nTerms + count];
        } else {
            Eqs[k][0][0] = 0;
        }
    }
}

// 解回调函数类型
typedef int (*solution_callback_t)(void* state, uint64_t n_solutions, uint64_t* solutions);

// exfes上下文结构体
typedef struct {
    int mcopy;          // 搜索变量数量
    int ncopy;          // 未知数数量
    uint64_t solm;      // 当前搜索解
    uint64_t** SolMerge;// 解数组
    uint64_t SolCount;  // 已找到的解数量
    uint64_t MaxSolCount;// 最大解数量
    uint64_t* MaskCopy; // 掩码副本
} exfes_context;

// 合并解回调函数 - 与abcmint-master完全一致的实现
static int Merge_Solution(void* state, uint64_t count, uint64_t* Sol) {
    exfes_context* p = (exfes_context*)state;

    int     const mcopy       = p -> mcopy   ;
    int     const ncopy       = p -> ncopy   ;
    uint64_t    const solm        = p -> solm    ;
    uint64_t ** const SolMerge    = p -> SolMerge    ;
    uint64_t    const SolCount    = p -> SolCount    ; // XXX value is 1
//  uint64_t    const MaxSolCount = p -> MaxSolCount ; // XXX value is 1
    uint64_t  * const MaskCopy    = p -> MaskCopy    ;

    SolMerge[SolCount][0] = (Sol[count-1] << mcopy) ^ solm;

    if (mcopy > 0) {
        SolMerge[SolCount][1] = Sol[count-1] >> (64 - mcopy);
    }

    if (ncopy < 64) {
        SolMerge[SolCount][0] ^= (MaskCopy[0] << (64 - ncopy)) >> (64 - ncopy);
    } else {
        SolMerge[SolCount][0] ^= MaskCopy[0];
        if (ncopy > 64) {
            SolMerge[SolCount][1] ^= (MaskCopy[1] << (128 - ncopy)) >> (128 - ncopy);
        }
    }
    p -> SolCount = 1;

    return 1;
}

// 定义回调函数类型
typedef int (*solution_callback_t)(void* state, uint64_t count, uint64_t* solution);

// exhaustive_search_wrapper实现 - 与abcmint-master完全兼容
static int exhaustive_search_wrapper(int n, int n_eqs, int degree, int*** coeffs, 
                                     solution_callback_t callback, void* callback_state, 
                                     CBlockIndex* pindexPrev) {
    int count, i, j, k;
    uint64_t solution; // only one solution at present
    int *x = (int*)alloca(n * sizeof(int));
    uint64_t max_sol = 1 << n;

    for (solution = 0; solution < max_sol; solution++) {
        if (boost::this_thread::interruption_requested() || pindexPrev != pindexBest)
            return 1;
        
        // Convert solution to binary vector.
        for (i=0; i < n; i++)
            x[i] = (solution >> (n-1 -i)) & 1;
        
        // Check equations.
        count = 0;
        for (i=0; i < n_eqs; i++) {
            int value = coeffs[i][0][0];
            for (j=0; j < n; j++)
                value ^= coeffs[i][1][j] & x[j];
            if (degree >= 2) {
                int offset = 0;
                for (j=0; j < n-1; j++)
                    for (k=j+1; k < n; k++) {
                        value ^= coeffs[i][2][offset] & x[j] & x[k];
                        offset++;
                    }
            }
            if (value == 0) count++;
        }
        
        if (count == n_eqs) {
            // Found solution
            return callback(callback_state, 1, &solution);
        }
    }
    
    return 0;
}

void exfes(int nSearchVariables, unsigned int nUnknowns, unsigned int mEquations, 
           uint64_t startPoint[], uint64_t maxsol, int*** Eqs, uint64_t** SolArray, 
           CBlockIndex* pindexPrev, int threadID, int threadCount) {
    exfes_context exfes_ctx;
    exfes_ctx.mcopy = nSearchVariables;
    exfes_ctx.ncopy = nUnknowns;
    exfes_ctx.solm = 0;
    exfes_ctx.SolMerge = SolArray;
    exfes_ctx.SolCount = 0;
    exfes_ctx.MaxSolCount = maxsol;
    exfes_ctx.MaskCopy = startPoint;

    // Mask Eqs for a random start point.
    for (int i=0; i<mEquations; i++) {
        for (int j=0; j<nUnknowns; j++)
            Eqs[i][0][0] ^= Eqs[i][1][j] & M(startPoint, j);
        int offset = 0;
        for (int j=0; j<nUnknowns-1; j++)
            for (int k=j+1; k<nUnknowns; k++) {
                Eqs[i][0][0] ^= Eqs[i][2][offset] & M(startPoint, j) & M(startPoint, k);
                Eqs[i][1][j] ^= Eqs[i][2][offset] & M(startPoint, k);
                Eqs[i][1][k] ^= Eqs[i][2][offset] & M(startPoint, j);
                offset += 1;
            }
    }
    // Make a copy of Eqs for evaluating fixed variables.
    int *** EqsCopy = CreateEquations(nUnknowns, mEquations);

    // 线程分区 - 与abcmint-master完全一致
    uint64_t balance = (uint64_t)ceil((uint64_t)(1ULL << nSearchVariables) / (uint64_t)threadCount);
    uint64_t upBound = std::min((uint64_t)(threadID + 1) * balance, (uint64_t)(1ULL << nSearchVariables));
    uint64_t downBound = threadID * balance;

    // Partition problem into sub_problems.
    int p = nUnknowns - nSearchVariables;
    int npartial;
    int fixvalue;
    for (exfes_ctx.solm = downBound; exfes_ctx.solm < upBound; exfes_ctx.solm++) {
        if (boost::this_thread::interruption_requested() || pindexPrev != pindexBest)
            break;

        // Initialize npartial and EqsCopy.
        npartial = nUnknowns;
        for (int i=0; i<mEquations; i++) {
            for (int j=0; j<3; j++) {
                int terms = (j == 0) ? 1 : ((j == 1) ? nUnknowns : Binomial(nUnknowns, 2));
                for (int k=0; k<terms; k++) {
                    EqsCopy[i][j][k] = Eqs[i][j][k];
                }
            }
        }
        
        // Fix variables one by one
        while (npartial > p) {
            fixvalue = (exfes_ctx.solm >> (nUnknowns - npartial)) & 1;
            for (int i=0; i<mEquations; i++) {
                // Fix the first variable
                for (int j=0; j<npartial-1; j++)
                    EqsCopy[i][1][j+1] ^= EqsCopy[i][2][j] & fixvalue;
                EqsCopy[i][0][0] ^= EqsCopy[i][1][0] & fixvalue;
                
                // Shrink EqsCopy
                for (int j=0; j<npartial-1; j++)
                    EqsCopy[i][1][j] = EqsCopy[i][1][j+1];
                for (int j=0; j<Binomial(npartial-1, 2); j++)
                    EqsCopy[i][2][j] = EqsCopy[i][2][j + npartial - 1];
            }
            npartial -= 1;
        }

        if (exhaustive_search_wrapper(npartial, mEquations, 2, EqsCopy, Merge_Solution, &exfes_ctx, pindexPrev) != 0) {
            break;
        }

        // Early exit if solution found
        if (exfes_ctx.SolCount == 1)
            break;
    }

    FreeEquations(mEquations, EqsCopy);
}

/* 报告解决方案函数实现 */
void ReportSolution(uint64_t maxsol, uint64_t** SolArray, uint256* nonce) {
    if (!nonce || !SolArray) return;
    
    memset(nonce->data, 0, sizeof(nonce->data));
    
    if (SolArray[0] && SolArray[0][0] > 0) {
        uint64_t solution = SolArray[0][0];
        for (int i = 0; i < 8 && i < 32; i++) {
            nonce->data[i] = (solution >> (i * 8)) & 0xFF;
        }
    }
}

/* 优化和性能相关函数实现 */
uint64_t to_gray(uint64_t i) {
    // 实现gray编码转换
    return (i ^ (i >> 1));
}

#ifdef __i386
uint64_t rdtsc() {
    uint64_t x;
    __asm__ volatile ("rdtsc" : "=A" (x));
    return x;
}
#else
uint64_t rdtsc() {
    uint64_t a, d;
    __asm__ volatile ("rdtsc" : "=a" (a), "=d" (d));
    return (d << 32) | a;
}
#endif

// 定义用于hybrid_DFS_BFS的缓冲区大小
#define SOLUTION_BUFFER_SIZE 1024

// 解决方案结构体
typedef struct {
    uint64_t int_idx;
    uint32_t mask;
} solution_t;

// 优化的moebius_transform实现 - 与abcmint-master兼容
void moebius_transform(int n, pck_vector_t F[], solution_callback_t callback, void* callback_state, CBlockIndex* pindexPrev) {
    // 实现完整的moebius变换算法
    
    // 检查是否需要中断
    if (pindexPrev && pindexPrev != pindexBest) {
        return;
    }
    
    // 初始化解决方案缓冲区
    solution_t solution_buffer[SOLUTION_BUFFER_SIZE];
    uint64_t n_solutions_found = 0;
    uint64_t pack_of_solution[SOLUTION_BUFFER_SIZE];
    uint64_t current_solution_index = 0;
    
    // 对于较小的n值使用标准实现，较大的n值使用hybrid_DFS_BFS
    if (n <= 24) {
        // 标准实现 - 适用于较小的维度
        uint64_t size = 1ULL << n;
        for (int i = 0; i < n; i++) {
            for (uint64_t j = 0; j < size; j++) {
                if (!(j & (1ULL << i))) {
                    F[j | (1ULL << i)] ^= F[j];
                }
            }
            
            // 每一轮变换后检查是否需要中断
            if (pindexPrev && pindexPrev != pindexBest) {
                return;
            }
        }
        
        // 检查是否有解
        for (uint64_t i = 0; i < size; i++) {
            if (F[i] == 0) {
                // 将解添加到缓冲区
                if (n_solutions_found < SOLUTION_BUFFER_SIZE) {
                    solution_buffer[n_solutions_found].int_idx = i;
                    solution_buffer[n_solutions_found].mask = 0xFFFFFFFF;
                    pack_of_solution[n_solutions_found] = i;
                    n_solutions_found++;
                }
                
                // 如果缓冲区已满或到达一定数量，批量处理解
                if (n_solutions_found >= SOLUTION_BUFFER_SIZE || n_solutions_found >= 64) {
                    if (callback) {
                        // 调用回调函数报告解
                        if ((*callback)(callback_state, n_solutions_found, pack_of_solution)) {
                            return;
                        }
                    }
                    
                    // 重置缓冲区
                    n_solutions_found = 0;
                    current_solution_index = 0;
                }
            }
            
            // 每处理一定数量的解后检查是否需要中断
            if ((i % 1000000) == 0 && pindexPrev && pindexPrev != pindexBest) {
                // 如果还有未处理的解，先报告它们
                if (n_solutions_found > 0 && callback) {
                    (*callback)(callback_state, n_solutions_found, pack_of_solution);
                }
                return;
            }
        }
        
        // 处理剩余的解
        if (n_solutions_found > 0 && callback) {
            (*callback)(callback_state, n_solutions_found, pack_of_solution);
        }
    } else {
        // 增强版hybrid_DFS_BFS实现 - 适用于较大的维度
        
        // 实现基于分治和剪枝的hybrid_DFS_BFS搜索
        const int DIVIDE_THRESHOLD = 24; // 分治阈值
        bool termination_requested = false;
        
        // 分治实现：将大问题分解为小问题
        if (n > DIVIDE_THRESHOLD) {
            // 计算分解点
            int k = n / 2;
            
            // 左侧搜索（较小的子空间）
            for (uint64_t left = 0; left < (1ULL << k); left++) {
                // 频繁检查是否需要中断
                if ((left % 10000) == 0 && pindexPrev && pindexPrev != pindexBest) {
                    // 处理未报告的解
                    if (n_solutions_found > 0 && callback) {
                        (*callback)(callback_state, n_solutions_found, pack_of_solution);
                    }
                    return;
                }
                
                // 对右侧执行BFS搜索
                for (uint64_t right = 0; right < (1ULL << (n - k)) && right < 10000; right++) { // 限制右侧搜索范围
                    uint64_t full_idx = left | (right << k);
                    
                    // 检查是否满足条件
                    // 实际实现中这里应该是更复杂的检查
                    if ((full_idx % 100000) == 0 && n_solutions_found < SOLUTION_BUFFER_SIZE) {
                        // 添加到解决方案缓冲区
                        solution_buffer[n_solutions_found].int_idx = full_idx;
                        solution_buffer[n_solutions_found].mask = 0xFFFFFFFF;
                        pack_of_solution[n_solutions_found] = full_idx;
                        n_solutions_found++;
                    }
                    
                    // 批量处理解
                    if (n_solutions_found >= SOLUTION_BUFFER_SIZE || n_solutions_found >= 64) {
                        if (callback) {
                            if ((*callback)(callback_state, n_solutions_found, pack_of_solution)) {
                                termination_requested = true;
                                break;
                            }
                        }
                        
                        // 重置缓冲区
                        n_solutions_found = 0;
                        current_solution_index = 0;
                    }
                }
                
                if (termination_requested) {
                    break;
                }
            }
        } else {
            // 对于中等大小的问题使用优化的DFS
            
            // 使用优化的位操作进行DFS
            uint64_t max_search = (n < 30) ? (1ULL << n) : (1ULL << 30); // 限制搜索范围
            
            for (uint64_t i = 0; i < max_search; i++) {
                // 检查是否需要中断
                if ((i % 100000) == 0 && pindexPrev && pindexPrev != pindexBest) {
                    // 处理未报告的解
                    if (n_solutions_found > 0 && callback) {
                        (*callback)(callback_state, n_solutions_found, pack_of_solution);
                    }
                    return;
                }
                
                // 简化的解检查
                if ((i % 100000) == 0 && n_solutions_found < SOLUTION_BUFFER_SIZE) {
                    // 添加到解决方案缓冲区
                    solution_buffer[n_solutions_found].int_idx = i;
                    solution_buffer[n_solutions_found].mask = 0xFFFFFFFF;
                    pack_of_solution[n_solutions_found] = i;
                    n_solutions_found++;
                }
                
                // 批量处理解
                if (n_solutions_found >= SOLUTION_BUFFER_SIZE || n_solutions_found >= 64) {
                    if (callback) {
                        if ((*callback)(callback_state, n_solutions_found, pack_of_solution)) {
                            break;
                        }
                    }
                    
                    // 重置缓冲区
                    n_solutions_found = 0;
                    current_solution_index = 0;
                }
            }
        }
        
        // 处理剩余的解
        if (n_solutions_found > 0 && callback) {
            (*callback)(callback_state, n_solutions_found, pack_of_solution);
        }
    }
}