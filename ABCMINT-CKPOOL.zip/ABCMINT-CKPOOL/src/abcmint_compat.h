/*
 * abcmint_compat.h - ABCMINT-CKPOOL与ABCMINT-MASTER兼容性适配层
 * 提供统一的接口定义、常量和工具函数，确保两个项目之间的兼容性
 */

#ifndef ABCMINT_COMPAT_H
#define ABCMINT_COMPAT_H

/* 基础头文件包含 */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h> /* 为了NULL定义 */
#include <stdlib.h> /* 为了free和malloc */
#include <string.h> /* 为了memcpy */

/* 日志宏定义 */
#ifndef LOGERROR
#define LOGERROR(fmt, ...) fprintf(stderr, "[ERROR] " fmt "\n", ##__VA_ARGS__)
#endif

#ifndef LOGINFO
#define LOGINFO(fmt, ...) fprintf(stdout, "[INFO] " fmt "\n", ##__VA_ARGS__)
#endif

#ifndef LOGWARN
#define LOGWARN(fmt, ...) fprintf(stdout, "[WARN] " fmt "\n", ##__VA_ARGS__)
#endif

#ifndef LOGDEBUG
#define LOGDEBUG(fmt, ...) fprintf(stdout, "[DEBUG] " fmt "\n", ##__VA_ARGS__)
#endif

/* 内存管理宏 */
#ifndef ckalloc
#define ckalloc malloc
#endif

#ifndef ckmalloc
#define ckmalloc malloc
#endif

#ifndef ckfree
#define ckfree free
#endif

/* Windows环境下的兼容性定义 */
#ifdef _WIN32
// Windows环境下的互斥锁模拟
typedef struct {
    volatile int lock;
} pthread_mutex_t;

#define PTHREAD_MUTEX_INITIALIZER { 0 }
#define pthread_mutex_init(m, p) (0)
#define pthread_mutex_lock(m) (0)
#define pthread_mutex_unlock(m) (0)

// Windows环境下的errno定义
#ifndef errno
extern int errno;
#endif
#else
// Unix/Linux环境使用标准头文件
#include <pthread.h>
#include <errno.h>
#include <stdio.h> /* Unix环境下需要 */
#endif

/* 版本兼容性常量 */
#define ABCMINT_VERSION_MAJOR 0
#define ABCMINT_VERSION_MINOR 1
#define ABCMINT_VERSION_PATCH 0
#define ABCMINT_VERSION_STRING "0.1.0"

/* 区块版本常量 - 与abcmint-master完全一致 */
#define ABCMINT_BLOCK_VERSION 101        // ABCMINT区块基础版本号
#define BLOCK_VERSION2_BEFORE_FORK 2     // fork前的版本号，与abcmint-master一致
#define BLOCK_VERSION3_BEFORE_FORK 3     // fork前的版本号3，与abcmint-master一致
#define BLOCK_CURRENT_VERSION 101        // 当前区块版本

/* 网络相关常量 - 与abcmint-master完全一致 */
#define DEFAULT_PORT 8888                 // 主网P2P端口
#define DEFAULT_TESTNET_PORT 18888        // 测试网P2P端口
#define DEFAULT_RPC_PORT 8882             // 主网RPC端口
#define DEFAULT_TESTNET_RPC_PORT 18882    // 测试网RPC端口

// 为向后兼容保留的别名
#define ABCMINT_MAINNET_RPC_PORT DEFAULT_RPC_PORT
#define ABCMINT_TESTNET_RPC_PORT DEFAULT_TESTNET_RPC_PORT
#define ABCMINT_DEFAULT_PORT DEFAULT_PORT
#define ABCMINT_TESTNET_PORT DEFAULT_TESTNET_PORT
#define ABCMINT_RPC_PORT DEFAULT_RPC_PORT

/* RPC配置常量 */
#define ABCMINT_RPC_TIMEOUT 30000        // RPC超时时间(毫秒)
#define ABCMINT_RPC_RETRIES 3            // RPC重试次数

// 网络环境检测函数声明
bool IsTestNetEnvironment();
unsigned int GetP2PPort();
unsigned int GetRPCPort();

/* Rainbow18算法常量 - 与abcmint-master的rainbow_config.h保持一致 */
#define _V1 32
#define _O1 32
#define _O2 32
#define _HASH_LEN 32
#define _GFSIZE 16
#define _SALT_BYTE 16
#define V2 ((_V1)+(_O1))
#define _V1_BYTE (_V1/2)
#define _V2_BYTE (V2/2)
#define _O1_BYTE (_O1/2)
#define _O2_BYTE (_O2/2)
#define _PUB_N  (_V1+_O1+_O2)
#define _PUB_M  (_O1+_O2)
#define _PUB_N_BYTE  (_PUB_N/2)
#define _PUB_M_BYTE  (_PUB_M/2)

/* 根据rainbow_config.h中的计算公式 */
#define TERMS_QUAD_POLY(N) (((N)*(N+1)/2)+N+1)
#define RAINBOW18_SIGNATURE_SIZE (_PUB_N_BYTE + _SALT_BYTE)  // 彩虹签名大小
#define RAINBOW18_HASH_SIZE 32                              // SHA-256哈希大小
#define RAINBOW18_PUBLIC_KEY_SIZE (TERMS_QUAD_POLY(_PUB_N)*(_PUB_M_BYTE)+1)  // 公钥大小
#define RAINBOWFORKHEIGHT 22176                             // 彩虹签名方案的分叉高度

/* 区块高度相关常量 - 与abcmint-master完全一致 */
#define RAINBOW_BLOCK_HEIGHT_1 25217     // 使用NewGenCoeffMatrix的起始高度
#define RAINBOW_BLOCK_HEIGHT_2 RAINBOWFORKHEIGHT // 使用New2GenCoeffMatrix的起始高度

/* 未知数和方程数定义 */
#define RAINBOW_UNKNOWNS_OLD 32          // 旧版本未知数数量
#define RAINBOW_EQUATIONS_OLD 24         // 旧版本方程数量
#define RAINBOW_UNKNOWNS_NEW 40          // 新版本未知数数量
#define RAINBOW_EQUATIONS_NEW 30         // 新版本方程数量

/* 难度调整相关常量 */
#define RAINBOW_MIN_DIFFICULTY 1.0       // 最小难度
#define RAINBOW_MAX_DIFFICULTY 1000000.0 // 最大难度
#define START_DIFF 100                   // 起始难度，适配rainbow18算法

/* 地址格式常量 */
#define ABCMINT_ADDRESS_PREFIX '8'       // ABCMINT地址前缀
#define ABCMINT_ADDRESS_LENGTH 34        // ABCMINT地址长度

/* 区块相关常量 - 与abcmint-master完全一致 */
static const unsigned int MAX_BLOCK_SIZE_BEFORE_FORK = 0x800000; // 8 MiB
static const unsigned int MAX_BLOCK_SIZE = 0x800000 * 8; // 64 MiB
#define ABCMINT_MAX_BLOCK_SIZE MAX_BLOCK_SIZE  // 最大区块大小(64MB)
#define ABCMINT_VERSION_MASK 0xFFFFFF00  // 版本掩码，允许矿工修改低8位

/* 类型定义 - 与abcmint-master保持一致 */

/* 简化版uint256实现，与abcmint-master的base_uint<256>兼容 */
typedef struct {
    uint32_t pn[8]; // 8个32位整数，共256位
} uint256;

/* 辅助函数声明，用于uint256操作 */
void uint256_set_zero(uint256* a);
bool uint256_is_zero(const uint256* a);
void uint256_set_uint64(uint256* a, uint64_t b);
void uint256_assign(uint256* a, const uint256* b);
bool uint256_equal(const uint256* a, const uint256* b);
bool uint256_less(const uint256* a, const uint256* b);
void uint256_xor(uint256* a, const uint256* b);
void uint256_and(uint256* a, const uint256* b);
void uint256_or(uint256* a, const uint256* b);
void uint256_shl(uint256* a, unsigned int shift);
void uint256_shr(uint256* a, unsigned int shift);
void uint256_add(uint256* a, const uint256* b);
void uint256_sub(uint256* a, const uint256* b);
void uint256_inc(uint256* a);
double uint256_getdouble(const uint256* a);
void uint256_from_bytes(uint256* a, const uint8_t* bytes);
void uint256_to_bytes(const uint256* a, uint8_t* bytes);

/* 简化版uint160实现 */
typedef struct {
    uint32_t pn[5]; // 5个32位整数，共160位
} uint160;

typedef struct {
    uint32_t nVersion;
    uint256 hashPrevBlock;
    uint256 hashMerkleRoot;
    uint32_t nTime;
    uint32_t nBits;
    uint256 nNonce;
} CBlockHeader;

// 区块状态枚举定义
#define BLOCK_VALID_UNKNOWN       0
#define BLOCK_VALID_HEADER        1
#define BLOCK_VALID_TREE          2
#define BLOCK_VALID_TRANSACTIONS  3
#define BLOCK_VALID_CHAIN         4
#define BLOCK_VALID_SCRIPTS       5
#define BLOCK_VALID_MASK          0xf

#define BLOCK_HAVE_DATA           8
#define BLOCK_HAVE_UNDO           16
#define BLOCK_HAVE_MASK           24

#define BLOCK_FAILED_VALID        32
#define BLOCK_FAILED_CHILD        64
#define BLOCK_FAILED_MASK         96

// 与abcmint-master完全一致的CBlockIndex类定义
#ifndef CBLOCKINDEX_DEFINED
#define CBLOCKINDEX_DEFINED

typedef struct {
    // pointer to the hash of the block, if any. memory is owned by this CBlockIndex
    const uint256* phashBlock;

    // pointer to the index of the predecessor of this block
    struct CBlockIndex* pprev;

    // (memory only) pointer to the index of the *active* successor of this block
    struct CBlockIndex* pnext;

    // height of the entry in the chain. The genesis block has height 0
    int nHeight;

    // Which # file this block is stored in (blk?????.dat)
    int nFile;

    // Byte offset within blk?????.dat where this block's data is stored
    unsigned int nDataPos;

    // Byte offset within rev?????.dat where this block's undo data is stored
    unsigned int nUndoPos;

    // (memory only) Total amount of work (expected number of hashes) in the chain up to and including this block
    uint64_t nChainWork;

    // Number of transactions in this block.
    // Note: in a potential headers-first mode, this number cannot be relied upon
    unsigned int nTx;

    // (memory only) Number of transactions in the chain up to and including this block
    unsigned int nChainTx;

    // Verification status of this block. See enum BlockStatus
    unsigned int nStatus;

    // block header
    int nVersion;
    uint256 hashMerkleRoot;
    unsigned int nTime;
    unsigned int nBits;
    uint256 nNonce;
    
    // 前一个区块的哈希值（用于简化访问）
    uint256 hashPrevBlock;
} CBlockIndex;

#endif

/* RPC方法名定义 */
#define RPC_GETBLOCKTEMPLATE "getblocktemplate"

/* 兼容性测试函数 */
bool TestBlockValidationCompatibility(void);
#define RPC_SUBMITBLOCK "submitblock"
#define RPC_GETINFO "getinfo"
#define RPC_GETMININGINFO "getmininginfo"
#define RPC_GETCONNECTIONCOUNT "getconnectioncount"
#define RPC_GETDIFFICULTY "getdifficulty"

/* 适配层函数声明 */

/**
 * 获取区块索引
 * @param hash 区块哈希
 * @return 区块索引指针，失败返回NULL
 */
CBlockIndex* GetBlockIndexFromHash(uint256 hash);

/**
 * 计算区块高度
 * @param hash 区块哈希
 * @param nVersion 区块版本
 * @return 区块高度
 */
int GetBlockHeight(uint256 hash, int nVersion);

/**
 * 检查解决方案是否有效
 * @param hash 区块哈希
 * @param nBits 目标难度
 * @param prevblockhash 前一个区块哈希
 * @param nblockversion 区块版本
 * @param nNonce nonce值
 * @return 有效返回true，否则返回false
 */
bool CheckSolution(uint256 hash, unsigned int nBits, uint256 prevblockhash, int nblockversion, uint256 nNonce);

/**
 * 将Uint256转换为解决方案位
 * @param x 输出数组
 * @param n 未知数数量
 * @param nonce nonce值
 */
void Uint256ToSolutionBits(uint8_t* x, unsigned int n, uint256 nonce);

/**
 * 验证ABCMINT地址格式
 * @param addr 地址字符串
 * @return 有效返回true，否则返回false
 */
bool ValidateAbcmintAddress(const char* addr);

/**
 * 检查是否为Rainbow18区块
 * @param block_version 区块版本
 * @return 是Rainbow18区块返回true，否则返回false
 */
bool abcmint_is_rainbow18_block(uint32_t block_version);

/**
 * 根据区块高度确定rainbow算法级别
 * @param height 区块高度
 * @return 算法级别（1-3）
 */
int abcmint_get_rainbow_level(size_t height);

/* 区块索引缓存定义 */
#define MAX_BLOCK_CACHE_SIZE 1000  // 最大缓存区块数量

/* 全局区块索引缓存结构 */
struct {
    pthread_mutex_t mutex;
    CBlockIndex* index_array[MAX_BLOCK_CACHE_SIZE];
    uint256 hash_array[MAX_BLOCK_CACHE_SIZE];
    int count;
} block_index_cache;

/* 区块索引缓存相关函数 */
/**
 * 初始化区块索引缓存
 */
void InitBlockIndexCache(void);

/**
 * 清理区块索引缓存
 */
void ClearBlockIndexCache(void);

/**
 * 添加区块索引到缓存
 * @param index 区块索引指针
 */
void AddBlockIndexToCache(CBlockIndex* index);

/**
 * 计算基于Rainbow18算法的难度
 * @param block_version 区块版本
 * @param block_height 区块高度
 * @param target 目标值
 * @return 难度值
 */
double CalculateRainbowDifficulty(uint32_t block_version, size_t block_height, const uint8_t* target);

/**
 * 测试难度计算一致性
 * 验证CalculateRainbowDifficulty函数与abcmint-master的GetDifficulty函数行为一致
 * @param block_version 区块版本
 * @param block_height 区块高度
 * @param nBits 难度位
 * @return 测试结果
 */
bool TestRainbowDifficultyConsistency(uint32_t block_version, size_t block_height, uint32_t nBits);

#endif /* ABCMINT_COMPAT_H */