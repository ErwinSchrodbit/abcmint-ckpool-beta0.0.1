/*
 * 版权所有 (c) 2010-2016 Petri Lehtinen <petri@digip.org>
 * Jansson 是自由软件；您可以根据 MIT 许可证的条款重新分发和/或修改它。详情请参阅许可证内容。
 * 此文件指定了 Jansson 库的站点特定配置的一部分，即那些会影响 jansson.h 中公共 API 的设置。
 * 配置脚本会将此文件复制到 jansson_config.h，并将 @var@ 替换为适合您系统的值。如果您无法运行配置脚本，
 * 您也可以手动进行值替换。
 */

#ifndef JANSSON_CONFIG_H
#define JANSSON_CONFIG_H

/* 如果您的编译器在 C 语言中支持 inline 关键字，则 JSON_INLINE 被定义为 `inline`，否则为空。
   在 C++ 中，inline 总是受支持的。 */
#ifdef __cplusplus
#define JSON_INLINE inline
#else
#define JSON_INLINE inline
#endif

/* 如果您的编译器支持 `long long` 类型和 strtoll() 库函数，则 JSON_INTEGER_IS_LONG_LONG 被定义为 1，
   否则为 0。 */
#define JSON_INTEGER_IS_LONG_LONG 1

/* 如果 locale.h 和 localeconv() 可用，则定义为 1，否则为 0。 */
#define JSON_HAVE_LOCALECONV 0

/* 解析 JSON 输入的最大递归深度。
   这限制了例如数组内嵌套数组等结构的深度。 */
#define JSON_PARSER_MAX_DEPTH 2048

#endif
