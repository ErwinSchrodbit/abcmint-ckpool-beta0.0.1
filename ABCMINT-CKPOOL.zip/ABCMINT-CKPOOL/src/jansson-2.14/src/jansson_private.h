/*
 * 版权所有 (c) 2009-2016 Petri Lehtinen <petri@digip.org>
 * 版权所有 (c) 2015,2017,2023 Con Kolivas <kernel@kolivas.org>
 *
 * Jansson 是自由软件；您可以根据 MIT 许可证的条款重新分发和/或修改它。
 * 有关详细信息，请参阅 LICENSE 文件。
 */

#ifndef JANSSON_PRIVATE_H
#define JANSSON_PRIVATE_H

#include "hashtable.h"
#include "jansson.h"
#include "jansson_private_config.h"
#include "strbuffer.h"
#include <stddef.h>

/* 通过成员指针获取包含该成员的结构体指针 */
#define container_of(ptr_, type_, member_)                                               \
    ((type_ *)((char *)ptr_ - offsetof(type_, member_)))

/* 在某些平台上，max() 可能已经被定义 */
#ifndef max
#define max(a, b) ((a) > (b) ? (a) : (b))
#endif

/* va_copy 是 C99 特性。在 C89 实现中，它有时可用作 __va_copy。
   如果都不可用，则使用 memcpy() 来实现相同功能。 */
#ifndef va_copy
#ifdef __va_copy
#define va_copy __va_copy
#else
#define va_copy(a, b) memcpy(&(a), &(b), sizeof(va_list))
#endif
#endif

/* JSON 对象类型定义 */
typedef struct {
    json_t json;            /* 基础 JSON 类型 */
    hashtable_t hashtable;  /* 存储键值对的哈希表 */
} json_object_t;

/* JSON 数组类型定义 */
typedef struct {
    json_t json;            /* 基础 JSON 类型 */
    size_t size;            /* 数组容量 */
    size_t entries;         /* 当前元素数量 */
    json_t **table;         /* 元素指针数组 */
} json_array_t;

/* JSON 字符串类型定义 */
typedef struct {
    json_t json;            /* 基础 JSON 类型 */
    char *value;            /* 字符串值 */
    size_t length;          /* 字符串长度 */
} json_string_t;

/* JSON 实数类型定义 */
typedef struct {
    json_t json;            /* 基础 JSON 类型 */
    double value;           /* 实数值 */
} json_real_t;

/* JSON 整数类型定义 */
typedef struct {
    json_t json;            /* 基础 JSON 类型 */
    json_int_t value;       /* 整数值 */
} json_integer_t;

/* 类型转换宏 */
#define json_to_object(json_)  container_of(json_, json_object_t, json)    /* 将 json_t 转换为 json_object_t */
#define json_to_array(json_)   container_of(json_, json_array_t, json)     /* 将 json_t 转换为 json_array_t */
#define json_to_string(json_)  container_of(json_, json_string_t, json)    /* 将 json_t 转换为 json_string_t */
#define json_to_real(json_)    container_of(json_, json_real_t, json)      /* 将 json_t 转换为 json_real_t */
#define json_to_integer(json_) container_of(json_, json_integer_t, json)   /* 将 json_t 转换为 json_integer_t */

/* 通过获取现有缓冲区的所有权来创建字符串 */
json_t *jsonp_stringn_nocheck_own(const char *value, size_t len);

/* 错误消息格式化函数 */
void jsonp_error_init(json_error_t *error, const char *source);
void jsonp_error_set_source(json_error_t *error, const char *source);
void jsonp_error_set(json_error_t *error, int line, int column, size_t position,
                     enum json_error_code code, const char *msg, ...);
void jsonp_error_vset(json_error_t *error, int line, int column, size_t position,
                      enum json_error_code code, const char *msg, va_list ap);

/* 与区域设置无关的字符串<->双精度浮点数转换 */
int jsonp_strtod(strbuffer_t *strbuffer, double *out);
int jsonp_dtostr(char *buffer, size_t size, double value, int prec);

/* 自定义内存函数包装器 */
void *jsonp_malloc(size_t size) JANSSON_ATTRS((warn_unused_result));
void _jsonp_free(void **ptr);
#define jsonp_free(ptr) _jsonp_free((void *)&(ptr))

char *jsonp_strndup(const char *str, size_t length) JANSSON_ATTRS((warn_unused_result));
char *jsonp_strdup(const char *str) JANSSON_ATTRS((warn_unused_result));
char *jsonp_strsteal(strbuffer_t *strbuff);
char *jsonp_eolstrsteal(strbuffer_t *strbuff);

/* 循环引用检查 */
/* "0x"、指针大小两倍的十六进制表示和终止符所需的空间 */
#define LOOP_KEY_LEN (2 + (sizeof(json_t *) * 2) + 1)
int jsonp_loop_check(hashtable_t *parents, const json_t *json, char *key, size_t key_size,
                     size_t *key_len_out);

/* Windows 兼容性 */
#if defined(_WIN32) || defined(WIN32)
#if defined(_MSC_VER) /* MS 编译器 */
#if (_MSC_VER < 1900) &&                                                                 \
    !defined(snprintf) /* snprintf 尚未定义且未引入 */
#define snprintf _snprintf
#endif
#if (_MSC_VER < 1500) &&                                                                 \
    !defined(vsnprintf) /* vsnprintf 尚未定义且未引入 */
#define vsnprintf(b, c, f, a) _vsnprintf(b, c, f, a)
#endif
#else /* 其他 Windows 编译器，旧定义 */
#define snprintf  _snprintf
#define vsnprintf _vsnprintf
#endif
#endif

#endif
