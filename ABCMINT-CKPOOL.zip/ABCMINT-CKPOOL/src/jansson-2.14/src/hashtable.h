/*
 * Copyright (c) 2009-2016 Petri Lehtinen <petri@digip.org>
 *
 * 此库是免费软件；您可以在遵循MIT许可证的条件下重新分发和修改它。详见LICENSE文件。
 * 此文件定义了Jansson库中的哈希表数据结构及其操作接口。
 */

#ifndef HASHTABLE_H
#define HASHTABLE_H

/* 包含必要的头文件 */
#include "jansson.h"  /* Jansson核心头文件 */
#include <stdlib.h>   /* 标准库函数 */

/**
 * 哈希表链表节点结构
 * 用于双向链表操作，作为键值对在哈希表中的连接结构
 */
struct hashtable_list {
    struct hashtable_list *prev;  /* 前一个节点指针 */
    struct hashtable_list *next;  /* 后一个节点指针 */
};

/**
 * 哈希表键值对结构
 * "pair"表示键值对，但在此结构中还包含了额外的数据信息
 */
struct hashtable_pair {
    struct hashtable_list list;          /* 在主链表中的位置 */
    struct hashtable_list ordered_list;  /* 在有序链表中的位置 */
    size_t hash;                         /* 键的哈希值 */
    json_t *value;                       /* 关联的值 */
    size_t key_len;                      /* 键的长度 */
    char key[1];                         /* 柔性数组成员，存储键的实际内容 */
};

/**
 * 哈希表桶结构
 * 每个桶存储具有相同哈希索引的键值对链表
 */
struct hashtable_bucket {
    struct hashtable_list *first;  /* 桶中第一个元素 */
    struct hashtable_list *last;   /* 桶中最后一个元素 */
};

/**
 * 哈希表主结构
 * 管理所有桶和链表结构
 */
typedef struct hashtable {
    size_t size;                    /* 当前元素数量 */
    struct hashtable_bucket *buckets; /* 桶数组指针 */
    size_t order;                   /* 哈希表阶数，桶数量为2^order */
    struct hashtable_list list;     /* 所有元素的主链表 */
    struct hashtable_list ordered_list; /* 所有元素的有序链表（插入顺序） */
} hashtable_t;

/**
 * 将键指针转换为迭代器
 * 参数:
 *   key_ - 键指针
 * 返回值:
 *   指向对应键值对在有序链表中位置的迭代器
 */
#define hashtable_key_to_iter(key_)                                                      \
    (&(container_of(key_, struct hashtable_pair, key)->ordered_list))

/**
 * hashtable_init - 初始化哈希表对象
 *
 * @hashtable: （静态分配的）哈希表对象
 *
 * 初始化一个静态分配的哈希表对象。当不再使用该对象时，
 * 应调用hashtable_close进行清理。
 *
 * 返回0表示成功，-1表示失败（内存不足）。
 */
int hashtable_init(hashtable_t *hashtable) JANSSON_ATTRS((warn_unused_result));

/**
 * hashtable_close - 释放哈希表对象使用的所有资源
 *
 * @hashtable: 哈希表对象
 *
 * 销毁一个静态分配的哈希表对象。
 */
void hashtable_close(hashtable_t *hashtable);

/**
 * hashtable_set - 在哈希表中添加/修改值
 *
 * @hashtable: 哈希表对象
 * @key: 键
 * @key_len: 键的长度
 * @value: 值
 *
 * 如果给定键已存在值，则用新值替换旧值。值被"窃取"，
 * 即哈希表不会增加其引用计数，但会在不再需要该值时减少引用计数。
 *
 * 返回0表示成功，-1表示失败（内存不足）。
 */
int hashtable_set(hashtable_t *hashtable, const char *key, size_t key_len, json_t *value);

/**
 * hashtable_get - 获取与键关联的值
 *
 * @hashtable: 哈希表对象
 * @key: 键
 * @key_len: 键的长度
 *
 * 如果找到值则返回该值，否则返回NULL。
 */
void *hashtable_get(hashtable_t *hashtable, const char *key, size_t key_len);

/**
 * hashtable_del - 从哈希表中删除值
 *
 * @hashtable: 哈希表对象
 * @key: 键
 * @key_len: 键的长度
 *
 * 成功返回0，如果键未找到则返回-1。
 */
int hashtable_del(hashtable_t *hashtable, const char *key, size_t key_len);

/**
 * hashtable_clear - 清空哈希表
 *
 * @hashtable: 哈希表对象
 *
 * 移除哈希表中的所有项。
 */
void hashtable_clear(hashtable_t *hashtable);

/**
 * hashtable_iter - 遍历哈希表
 *
 * @hashtable: 哈希表对象
 *
 * 返回指向哈希表第一个元素的不透明迭代器。该迭代器应传递给hashtable_iter_*函数。
 * 哈希表项的遍历顺序不固定。
 *
 * 无需以任何方式释放迭代器。只要迭代器引用的项未被删除，该迭代器就有效。
 * 其他值可以被添加或删除。特别是，可以对迭代器调用hashtable_iter_next()，
 * 然后可以删除旧迭代器指向的键/值对。
 */
void *hashtable_iter(hashtable_t *hashtable);

/**
 * hashtable_iter_at - 返回指向特定键的迭代器
 *
 * @hashtable: 哈希表对象
 * @key: 迭代器应指向的键
 * @key_len: 键的长度
 *
 * 类似于hashtable_iter()，但返回指向特定键的迭代器。
 */
void *hashtable_iter_at(hashtable_t *hashtable, const char *key, size_t key_len);

/**
 * hashtable_iter_next - 推进迭代器
 *
 * @hashtable: 哈希表对象
 * @iter: 当前迭代器
 *
 * 返回指向哈希表中下一个元素的新迭代器，如果整个哈希表已遍历完成则返回NULL。
 */
void *hashtable_iter_next(hashtable_t *hashtable, void *iter);

/**
 * hashtable_iter_key - 获取迭代器指向的键
 *
 * @iter: 迭代器
 * 返回值:
 *   迭代器指向的键的指针
 */
void *hashtable_iter_key(void *iter);

/**
 * hashtable_iter_key_len - 获取迭代器指向的键长度
 *
 * @iter: 迭代器
 * 返回值:
 *   迭代器指向的键的长度
 */
size_t hashtable_iter_key_len(void *iter);

/**
 * hashtable_iter_value - 获取迭代器指向的值
 *
 * @iter: 迭代器
 * 返回值:
 *   迭代器指向的值的指针
 */
void *hashtable_iter_value(void *iter);

/**
 * hashtable_iter_set - 设置迭代器指向的值
 *
 * @iter: 迭代器
 * @value: 要设置的新值
 */
void hashtable_iter_set(void *iter, json_t *value);

#endif
