/*
 * 版权所有 (c) 2019 Sean Bright <sean.bright@gmail.com>
 *
 * Jansson 是免费软件；您可以根据MIT许可证的条款重新分发和/或修改它。
 * 有关详细信息，请参阅LICENSE文件。
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "jansson.h"

/* 获取Jansson库的版本字符串 */
const char *jansson_version_str(void) { return JANSSON_VERSION; }

/* 比较Jansson库版本号
 * 返回值：
 * - 正数：当前版本大于指定版本
 * - 负数：当前版本小于指定版本
 * - 0：版本相同
 */
int jansson_version_cmp(int major, int minor, int micro) {
    int diff;

    /* 先比较主版本号 */
    if ((diff = JANSSON_MAJOR_VERSION - major)) {
        return diff;
    }

    /* 再比较次版本号 */
    if ((diff = JANSSON_MINOR_VERSION - minor)) {
        return diff;
    }

    /* 最后比较修订版本号 */
    return JANSSON_MICRO_VERSION - micro;
}
