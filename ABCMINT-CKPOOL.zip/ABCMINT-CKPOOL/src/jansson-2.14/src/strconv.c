#include "jansson_private.h"
#include "strbuffer.h"
#include <assert.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

/* 需要jansson_private_config.h以获取正确的snprintf */
#ifdef HAVE_CONFIG_H
#include <jansson_private_config.h>
#endif

#if JSON_HAVE_LOCALECONV
#include <locale.h>

/*
  - 此代码假设小数点分隔符恰好是一个字符。

  - 如果在调用localeconv()和调用sprintf()或strtod()之间，另一个线程调用了setlocale()，
    结果可能会出错。setlocale()不是线程安全的，不应以这种方式使用。
    多线程程序应使用uselocale()代替。
*/

/* 将字符串缓冲区中的小数点转换为当前区域设置的小数点格式 */
static void to_locale(strbuffer_t *strbuffer) {
    const char *point;
    char *pos;

    point = localeconv()->decimal_point;
    if (*point == '.') {
        /* 无需转换 */
        return;
    }

    pos = strchr(strbuffer->value, '.');
    if (pos)
        *pos = *point;
}

/* 将当前区域设置的小数点转换回点号格式 */
static void from_locale(char *buffer) {
    const char *point;
    char *pos;

    point = localeconv()->decimal_point;
    if (*point == '.') {
        /* No conversion needed */
        return;
    }

    pos = strchr(buffer, *point);
    if (pos)
        *pos = '.';
}
#endif

/* 将字符串转换为双精度浮点数 */
int jsonp_strtod(strbuffer_t *strbuffer, double *out) {
    double value;
    char *end;

#if JSON_HAVE_LOCALECONV
    to_locale(strbuffer);
#endif

    errno = 0;
    value = strtod(strbuffer->value, &end);
    assert(end == strbuffer->value + strbuffer->length);

    if ((value == HUGE_VAL || value == -HUGE_VAL) && errno == ERANGE) {
        /* 溢出 */
        return -1;
    }

    *out = value;
    return 0;
}

/* 将双精度浮点数转换为字符串 */
int jsonp_dtostr(char *buffer, size_t size, double value, int precision) {
    int ret;
    char *start, *end;
    size_t length;

    if (precision == 0)
        precision = 17;

    ret = snprintf(buffer, size, "%.*g", precision, value);
    if (ret < 0)
        return -1;

    length = (size_t)ret;
    if (length >= size)
        return -1;

#if JSON_HAVE_LOCALECONV
    from_locale(buffer);
#endif

    /* 确保输出中包含小数点或'e'。否则，在解码时实型数会被转换为整数 */
    if (strchr(buffer, '.') == NULL && strchr(buffer, 'e') == NULL) {
        if (length + 3 >= size) {
            /* 没有空间添加".0" */
            return -1;
        }
        buffer[length] = '.';
        buffer[length + 1] = '0';
        buffer[length + 2] = '\0';
        length += 2;
    }

    /* 移除正指数前的'+'符号。同时移除指数部分的前导零（由某些printf()实现添加） */
    start = strchr(buffer, 'e');
    if (start) {
        start++;
        end = start + 1;

        if (*start == '-')
            start++;

        while (*end == '0')
            end++;

        if (end != start) {
            memmove(start, end, length - (size_t)(end - buffer));
            length -= (size_t)(end - start);
        }
    }

    return (int)length;
}
