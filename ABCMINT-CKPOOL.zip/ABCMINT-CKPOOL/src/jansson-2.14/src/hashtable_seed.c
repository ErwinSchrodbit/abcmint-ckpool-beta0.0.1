/* 生成尽可能随机的数据来作为哈希函数的种子，大小为sizeof(uint32_t)字节。
   这个文件实现了多种生成随机种子的方法，包括从/dev/urandom读取、使用Windows加密API、
   基于时间戳和进程ID等方式，确保哈希表的哈希函数具有良好的随机性。
*/

/* 包含必要的头文件 */
#ifdef HAVE_CONFIG_H
#include <jansson_private_config.h>
#endif

#include <stdio.h>  /* 标准输入输出 */
#include <time.h>   /* 时间相关函数 */

#ifdef HAVE_STDINT_H
#include <stdint.h> /* 标准整数类型 */
#endif

#ifdef HAVE_FCNTL_H
#include <fcntl.h>  /* 文件控制函数 */
#endif

#ifdef HAVE_SCHED_H
#include <sched.h>  /* 调度相关函数 */
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h> /* 类Unix系统调用 */
#endif

#ifdef HAVE_SYS_STAT_H
#include <sys/stat.h> /* 文件状态 */
#endif

#ifdef HAVE_SYS_TIME_H
#include <sys/time.h> /* 时间相关结构 */
#endif

#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h> /* 系统类型定义 */
#endif

#if defined(_WIN32)
/* 用于GetModuleHandle()、GetProcAddress()和GetCurrentProcessId() */
#include <windows.h>
#endif

#include "jansson.h"  /* Jansson库头文件 */

/**
 * 将字节数组转换为uint32_t类型
 * 参数:
 *   data - 指向字节数组的指针
 * 返回值:
 *   转换后的uint32_t值
 * 功能:
 *   将4字节数据按字节顺序组合成一个32位无符号整数
 */
static uint32_t buf_to_uint32(char *data) {
    size_t i;
    uint32_t result = 0;

    /* 逐字节组合成uint32_t值，左移并按位或操作 */
    for (i = 0; i < sizeof(uint32_t); i++)
        result = (result << 8) | (unsigned char)data[i];

    return result;
}

/* 从/dev/urandom获取随机种子（Unix/Linux系统） */
#if !defined(_WIN32) && defined(USE_URANDOM)
/**
 * 从/dev/urandom设备获取随机种子
 * 参数:
 *   seed - 存储生成的随机种子的指针
 * 返回值:
 *   成功返回0，失败返回1
 * 功能:
 *   从系统的/dev/urandom设备读取随机数据作为种子，优先使用无缓冲I/O
 */
static int seed_from_urandom(uint32_t *seed) {
    /* 如果有open()、close()和read()函数，则使用无缓冲I/O，否则回退到fopen() */

    char data[sizeof(uint32_t)];  /* 存储读取的随机数据 */
    int ok;                       /* 操作结果标志 */

#if defined(HAVE_OPEN) && defined(HAVE_CLOSE) && defined(HAVE_READ)
    /* 使用低级I/O函数 */
    int urandom;
    urandom = open("/dev/urandom", O_RDONLY);  /* 打开随机设备 */
    if (urandom == -1)  /* 打开失败 */
        return 1;

    /* 读取随机数据 */
    ok = read(urandom, data, sizeof(uint32_t)) == sizeof(uint32_t);
    close(urandom);  /* 关闭文件描述符 */
#else
    /* 使用标准I/O函数 */
    FILE *urandom;

    urandom = fopen("/dev/urandom", "rb");  /* 以二进制模式打开 */
    if (!urandom)  /* 打开失败 */
        return 1;

    /* 读取随机数据 */
    ok = fread(data, 1, sizeof(uint32_t), urandom) == sizeof(uint32_t);
    fclose(urandom);  /* 关闭文件指针 */
#endif

    if (!ok)  /* 读取失败 */
        return 1;

    *seed = buf_to_uint32(data);  /* 转换为uint32_t种子 */
    return 0;  /* 成功 */
}
#endif

/* Windows加密API方式 */
#if defined(_WIN32) && defined(USE_WINDOWS_CRYPTOAPI)
#include <wincrypt.h>

/* 定义Windows加密API函数指针类型 */
typedef BOOL(WINAPI *CRYPTACQUIRECONTEXTA)(HCRYPTPROV *phProv, LPCSTR pszContainer,
                                           LPCSTR pszProvider, DWORD dwProvType,
                                           DWORD dwFlags);
typedef BOOL(WINAPI *CRYPTGENRANDOM)(HCRYPTPROV hProv, DWORD dwLen, BYTE *pbBuffer);
typedef BOOL(WINAPI *CRYPTRELEASECONTEXT)(HCRYPTPROV hProv, DWORD dwFlags);

/**
 * 使用Windows加密API生成随机种子
 * 参数:
 *   seed - 存储生成的随机种子的指针
 * 返回值:
 *   成功返回0，失败返回1
 * 功能:
 *   通过动态加载Windows加密API生成高质量的随机数据
 */
static int seed_from_windows_cryptoapi(uint32_t *seed) {
    HINSTANCE hAdvAPI32 = NULL;  /* advapi32.dll句柄 */
    CRYPTACQUIRECONTEXTA pCryptAcquireContext = NULL;  /* 获取加密服务提供者的函数指针 */
    CRYPTGENRANDOM pCryptGenRandom = NULL;  /* 生成随机数的函数指针 */
    CRYPTRELEASECONTEXT pCryptReleaseContext = NULL;  /* 释放加密服务提供者的函数指针 */
    HCRYPTPROV hCryptProv = 0;  /* 加密服务提供者句柄 */
    BYTE data[sizeof(uint32_t)];  /* 存储随机数据的缓冲区 */
    int ok;  /* 操作结果标志 */

    /* 获取advapi32.dll模块句柄 */
    hAdvAPI32 = GetModuleHandle(TEXT("advapi32.dll"));
    if (hAdvAPI32 == NULL)
        return 1;

    /* 获取加密API函数指针 */
    pCryptAcquireContext =
        (CRYPTACQUIRECONTEXTA)GetProcAddress(hAdvAPI32, "CryptAcquireContextA");
    if (!pCryptAcquireContext)
        return 1;

    pCryptGenRandom = (CRYPTGENRANDOM)GetProcAddress(hAdvAPI32, "CryptGenRandom");
    if (!pCryptGenRandom)
        return 1;

    pCryptReleaseContext =
        (CRYPTRELEASECONTEXT)GetProcAddress(hAdvAPI32, "CryptReleaseContext");
    if (!pCryptReleaseContext)
        return 1;

    /* 获取加密服务提供者句柄 */
    if (!pCryptAcquireContext(&hCryptProv, NULL, NULL, PROV_RSA_FULL,
                              CRYPT_VERIFYCONTEXT))
        return 1;

    /* 生成随机数据 */
    ok = pCryptGenRandom(hCryptProv, sizeof(uint32_t), data);
    pCryptReleaseContext(hCryptProv, 0);  /* 释放加密服务提供者 */

    if (!ok)  /* 生成随机数据失败 */
        return 1;

    *seed = buf_to_uint32((char *)data);  /* 转换为uint32_t种子 */
    return 0;  /* 成功 */
}
#endif

/* 使用时间戳和进程ID生成种子（回退方案） */
/**
 * 基于时间戳和进程ID生成随机种子
 * 参数:
 *   seed - 存储生成的随机种子的指针
 * 返回值:
 *   总是返回0
 * 功能:
 *   当其他更高级的随机源不可用时，使用时间戳和进程ID作为随机源
 */
static int seed_from_timestamp_and_pid(uint32_t *seed) {
#ifdef HAVE_GETTIMEOFDAY
    /* 使用秒和微秒的异或结果 */
    struct timeval tv;
    gettimeofday(&tv, NULL);
    *seed = (uint32_t)tv.tv_sec ^ (uint32_t)tv.tv_usec;  /* 异或操作增加随机性 */
#else
    /* 仅使用秒数 */
    *seed = (uint32_t)time(NULL);
#endif

    /* 与进程ID异或以增加随机性 */
#if defined(_WIN32)
    *seed ^= (uint32_t)GetCurrentProcessId();  /* Windows系统获取进程ID */
#elif defined(HAVE_GETPID)
    *seed ^= (uint32_t)getpid();  /* Unix/Linux系统获取进程ID */
#endif

    return 0;  /* 总是成功 */
}

/**
 * 生成哈希表随机种子的主函数
 * 返回值:
 *   生成的32位无符号整数种子
 * 功能:
 *   按照优先级尝试多种随机源生成种子，确保种子不为零
 */
static uint32_t generate_seed() {
    uint32_t seed = 0;
    int done = 0;  /* 标记是否已成功生成种子 */

    /* 首先尝试使用/dev/urandom（Unix/Linux系统） */
#if !defined(_WIN32) && defined(USE_URANDOM)
    if (seed_from_urandom(&seed) == 0)
        done = 1;
#endif

    /* 然后尝试使用Windows加密API（Windows系统） */
#if defined(_WIN32) && defined(USE_WINDOWS_CRYPTOAPI)
    if (seed_from_windows_cryptoapi(&seed) == 0)
        done = 1;
#endif

    /* 如果上述方法都失败，回退到时间戳和进程ID */
    if (!done) {
        /* 如果没有更好的随机源可用，则回退到时间戳和进程ID */
        seed_from_timestamp_and_pid(&seed);
    }

    /* 确保种子永远不为零，零可能导致哈希冲突 */
    if (seed == 0)
        seed = 1;

    return seed;
}

/**
 * 哈希表的全局种子变量
 * 声明为volatile以确保多线程环境下的可见性
 * 初始值为0，表示尚未初始化
 */
volatile uint32_t hashtable_seed = 0;

/* 使用__atomic内置函数的线程安全实现（优先方案） */
#if defined(HAVE_ATOMIC_BUILTINS) && (defined(HAVE_SCHED_YIELD) || !defined(_WIN32))
/**
 * 标记种子是否已初始化的标志
 * volatile确保多线程可见性
 */
static volatile char seed_initialized = 0;

/**
 * 设置JSON对象哈希表的种子（线程安全版本，使用C11原子操作）
 * 参数:
 *   seed - 用户提供的种子值，为0时自动生成
 * 功能:
 *   确保哈希表种子只被初始化一次，使用原子操作保证线程安全
 */
void json_object_seed(size_t seed) {
    uint32_t new_seed = (uint32_t)seed;

    if (hashtable_seed == 0) {  /* 只有当种子未初始化时才操作 */
        /* 原子测试并设置，确保只有一个线程执行种子初始化 */
        if (__atomic_test_and_set(&seed_initialized, __ATOMIC_RELAXED) == 0) {
            /* 由当前线程执行种子初始化 */
            if (new_seed == 0)
                new_seed = generate_seed();  /* 如果用户提供的种子为0，自动生成 */

            /* 原子存储种子，确保其他线程可见 */
            __atomic_store_n(&hashtable_seed, new_seed, __ATOMIC_RELEASE);
        } else {
            /* 等待其他线程完成种子初始化 */
            do {
#ifdef HAVE_SCHED_YIELD
                sched_yield();  /* 让出CPU时间片，减少忙等待 */
#endif
            } while (__atomic_load_n(&hashtable_seed, __ATOMIC_ACQUIRE) == 0);
        }
    }
}

/* 使用__sync内置函数的线程安全实现（次优方案） */
#elif defined(HAVE_SYNC_BUILTINS) && (defined(HAVE_SCHED_YIELD) || !defined(_WIN32))
/**
 * 设置JSON对象哈希表的种子（线程安全版本，使用GCC原子操作）
 * 参数:
 *   seed - 用户提供的种子值，为0时自动生成
 * 功能:
 *   使用比较并交换操作确保线程安全
 */
void json_object_seed(size_t seed) {
    uint32_t new_seed = (uint32_t)seed;

    if (hashtable_seed == 0) {  /* 只有当种子未初始化时才操作 */
        if (new_seed == 0) {
            /* __sync内置函数不支持显式同步屏障，所以每个到达这里的线程都必须生成种子值 */
            new_seed = generate_seed();
        }

        do {
            /* 比较并交换操作，尝试原子地设置种子 */
            if (__sync_bool_compare_and_swap(&hashtable_seed, 0, new_seed)) {
                /* 当前线程是第一个成功设置种子的线程 */
                break;
            } else {
                /* 等待其他线程完成种子初始化 */
#ifdef HAVE_SCHED_YIELD
                sched_yield();  /* 让出CPU时间片 */
#endif
            }
        } while (hashtable_seed == 0);
    }
}

/* Windows平台的线程安全实现 */
#elif defined(_WIN32)
/**
 * Windows平台的种子初始化计数器
 * 使用long类型以支持InterlockedIncrement
 */
static long seed_initialized = 0;

/**
 * 设置JSON对象哈希表的种子（Windows线程安全版本）
 * 参数:
 *   seed - 用户提供的种子值，为0时自动生成
 * 功能:
 *   使用Windows互锁函数确保线程安全
 */
void json_object_seed(size_t seed) {
    uint32_t new_seed = (uint32_t)seed;

    if (hashtable_seed == 0) {  /* 只有当种子未初始化时才操作 */
        /* 原子递增并检查是否为1，确保只有一个线程执行初始化 */
        if (InterlockedIncrement(&seed_initialized) == 1) {
            /* 由当前线程执行种子初始化 */
            if (new_seed == 0)
                new_seed = generate_seed();  /* 如果用户提供的种子为0，自动生成 */

            hashtable_seed = new_seed;  /* 设置种子 */
        } else {
            /* 等待其他线程完成种子初始化 */
            do {
                SwitchToThread();  /* Windows系统让出CPU时间片 */
            } while (hashtable_seed == 0);
        }
    }
}

/* 线程不安全的回退版本 */
#else
/**
 * 设置JSON对象哈希表的种子（线程不安全版本）
 * 参数:
 *   seed - 用户提供的种子值，为0时自动生成
 * 功能:
 *   当没有线程安全机制可用时的简单实现
 *   注意：此版本在多线程环境中可能导致种子被多次初始化
 */
void json_object_seed(size_t seed) {
    uint32_t new_seed = (uint32_t)seed;

    if (hashtable_seed == 0) {  /* 只有当种子未初始化时才操作 */
        if (new_seed == 0)
            new_seed = generate_seed();  /* 如果用户提供的种子为0，自动生成 */

        hashtable_seed = new_seed;  /* 设置种子 */
    }
}
#endif
