/*
 * 版权所有 (c) 2009-2016 Petri Lehtinen <petri@digip.org>
 *
 * Jansson是自由软件；您可以根据MIT许可证的条款重新分发和/或修改它。
 * 详情请参阅LICENSE文件。
 */

#ifndef STRBUFFER_H
#define STRBUFFER_H

#include "jansson.h"
#include <stdlib.h>

/* 字符串缓冲区结构体 */
typedef struct {
    char *value;        /* 存储的字符串内容 */
    size_t length;      /* 已使用的字节数 */
    size_t size;        /* 已分配的字节数 */
} strbuffer_t;

/* 初始化字符串缓冲区 */
int strbuffer_init(strbuffer_t *strbuff) JANSSON_ATTRS((warn_unused_result));
/* 关闭并释放字符串缓冲区资源 */
void strbuffer_close(strbuffer_t *strbuff);

/* 清空字符串缓冲区内容 */
void strbuffer_clear(strbuffer_t *strbuff);

/* 获取字符串缓冲区的当前值 */
const char *strbuffer_value(const strbuffer_t *strbuff);

/* 窃取字符串缓冲区的值并关闭缓冲区 */
char *strbuffer_steal_value(strbuffer_t *strbuff);

/* 向字符串缓冲区追加一个字节 */
int strbuffer_append_byte(strbuffer_t *strbuff, char byte);
/* 向字符串缓冲区追加多个字节 */
int strbuffer_append_bytes(strbuffer_t *strbuff, const char *data, size_t size);

/* 从字符串缓冲区弹出最后一个字符 */
char strbuffer_pop(strbuffer_t *strbuff);

#endif
