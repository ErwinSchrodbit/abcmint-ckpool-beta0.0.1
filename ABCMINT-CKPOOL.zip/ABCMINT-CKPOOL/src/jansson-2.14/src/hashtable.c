/*
 * Copyright (c) 2009-2016 Petri Lehtinen <petri@digip.org>
 *
 * 此库是免费软件；您可以在遵循MIT许可证的条件下重新分发和修改它。详见LICENSE文件。
 * 此文件实现了Jansson库中的哈希表数据结构，用于高效的键值对存储和查找。
 */

/* 包含必要的头文件 */
#if HAVE_CONFIG_H
#include <jansson_private_config.h>
#endif

#include <stdlib.h>  /* 标准库函数 */
#include <string.h>  /* 字符串处理函数 */

#if HAVE_STDINT_H
#include <stdint.h>  /* 标准整数类型 */
#endif

#include "hashtable.h"          /* 哈希表头文件 */
#include "jansson_private.h"    /* 私有工具函数，如container_of() */
#include <jansson_config.h>     /* 配置定义，如JSON_INLINE */

/* 哈希表初始顺序值（哈希表大小 = 2^order） */
#ifndef INITIAL_HASHTABLE_ORDER
#define INITIAL_HASHTABLE_ORDER 3  /* 默认初始哈希表大小为8 (2^3) */
#endif

/* 类型定义别名，简化代码 */
typedef struct hashtable_list list_t;
   /* 哈希表链表节点类型 */
typedef struct hashtable_pair pair_t;
   /* 哈希表键值对类型 */
typedef struct hashtable_bucket bucket_t;
   /* 哈希表桶类型 */

/* 外部声明哈希表随机种子，用于哈希函数 */
extern volatile uint32_t hashtable_seed;

/* 哈希函数实现 */
#include "lookup3.h"  /* 包含lookup3哈希算法实现 */

/* 宏定义工具函数 */
#define list_to_pair(list_)         container_of(list_, pair_t, list)
   /* 将链表节点转换为键值对 */
#define ordered_list_to_pair(list_) container_of(list_, pair_t, ordered_list)
   /* 将有序链表节点转换为键值对 */
#define hash_str(key, len)          ((size_t)hashlittle((key), len, hashtable_seed))
   /* 计算字符串的哈希值，使用lookup3算法 */

/**
 * 初始化双向链表节点
 * 参数:
 *   list - 要初始化的链表节点
 * 功能:
 *   将链表节点的next和prev指针指向自身，形成一个空的循环链表
 */
static JSON_INLINE void list_init(list_t *list) {
    list->next = list;
    list->prev = list;
}

/**
 * 在链表中插入节点
 * 参数:
 *   list - 链表节点，新节点将插入到此节点之前
 *   node - 要插入的新节点
 * 功能:
 *   在指定链表节点的前面插入新节点
 */
static JSON_INLINE void list_insert(list_t *list, list_t *node) {
    node->next = list;
    node->prev = list->prev;
    list->prev->next = node;
    list->prev = node;
}

/**
 * 从链表中移除节点
 * 参数:
 *   list - 要移除的链表节点
 * 功能:
 *   将节点从链表中移除，更新前后节点的指针
 */
static JSON_INLINE void list_remove(list_t *list) {
    list->prev->next = list->next;
    list->next->prev = list->prev;
}

/**
 * 检查哈希表桶是否为空
 * 参数:
 *   hashtable - 哈希表指针
 *   bucket - 要检查的桶
 * 返回值:
 *   如果桶为空返回1，否则返回0
 * 功能:
 *   通过检查桶的首尾指针是否都指向哈希表的主链表来判断桶是否为空
 */
static JSON_INLINE int bucket_is_empty(hashtable_t *hashtable, bucket_t *bucket) {
    return bucket->first == &hashtable->list && bucket->first == bucket->last;
}

/**
 * 将节点插入到哈希表桶中
 * 参数:
 *   hashtable - 哈希表指针
 *   bucket - 目标桶
 *   list - 要插入的节点
 * 功能:
 *   根据桶是否为空，采取不同的插入策略
 */
static void insert_to_bucket(hashtable_t *hashtable, bucket_t *bucket, list_t *list) {
    if (bucket_is_empty(hashtable, bucket)) {
        /* 如果桶为空，将节点插入到哈希表的主链表中 */
        list_insert(&hashtable->list, list);
        bucket->first = bucket->last = list;  /* 更新桶的首尾指针 */
    } else {
        /* 如果桶不为空，将节点插入到桶的首位 */
        list_insert(bucket->first, list);
        bucket->first = list;  /* 更新桶的首指针 */
    }
}

/**
 * 在哈希表桶中查找指定键的键值对
 * 参数:
 *   hashtable - 哈希表指针
 *   bucket - 要搜索的桶
 *   key - 键字符串
 *   key_len - 键的长度
 *   hash - 键的哈希值
 * 返回值:
 *   如果找到匹配的键值对，返回其指针；否则返回NULL
 * 功能:
 *   通过哈希值快速定位桶，然后在桶内线性搜索匹配的键
 */
static pair_t *hashtable_find_pair(hashtable_t *hashtable, bucket_t *bucket, 
                                   const char *key, size_t key_len, size_t hash) {
    list_t *list;
    pair_t *pair;

    if (bucket_is_empty(hashtable, bucket))
        return NULL;  /* 桶为空，直接返回NULL */

    list = bucket->first;
    while (1) {
        pair = list_to_pair(list);
        /* 通过哈希值、键长度和键内容进行精确匹配 */
        if (pair->hash == hash && pair->key_len == key_len &&
            memcmp(pair->key, key, key_len) == 0) 
            return pair;

        if (list == bucket->last)  /* 已遍历到桶末尾 */
            break;

        list = list->next;
    }

    return NULL;  /* 未找到匹配的键 */
}

/**
 * 在哈希表中删除指定键的键值对
 * 参数:
 *   hashtable - 哈希表指针
 *   key - 要删除的键
 *   key_len - 键的长度
 *   hash - 键的哈希值
 * 返回值:
 *   成功删除返回0，键不存在返回-1
 */
static int hashtable_do_del(hashtable_t *hashtable, const char *key, size_t key_len, 
                            size_t hash) {
    pair_t *pair;
    bucket_t *bucket;
    size_t index;

    /* 计算桶索引 */
    index = hash & hashmask(hashtable->order);
    bucket = &hashtable->buckets[index];

    /* 查找键值对 */
    pair = hashtable_find_pair(hashtable, bucket, key, key_len, hash);
    if (!pair)
        return -1;  /* 键不存在 */

    /* 更新桶的首尾指针 */
    if (&pair->list == bucket->first && &pair->list == bucket->last)
        /* 如果桶中只有一个元素 */
        bucket->first = bucket->last = &hashtable->list;

    else if (&pair->list == bucket->first)
        /* 如果是桶的第一个元素 */
        bucket->first = pair->list.next;

    else if (&pair->list == bucket->last)
        /* 如果是桶的最后一个元素 */
        bucket->last = pair->list.prev;

    /* 从链表中移除 */
    list_remove(&pair->list);         /* 从主链表移除 */
    list_remove(&pair->ordered_list); /* 从有序链表移除 */
    json_decref(pair->value);         /* 减少值的引用计数 */

    /* 释放内存 */
    jsonp_free(pair);
    hashtable->size--;  /* 减少哈希表大小计数 */

    return 0;  /* 删除成功 */
}

/**
 * 清空哈希表中的所有元素
 * 参数:
 *   hashtable - 哈希表指针
 * 功能:
 *   释放所有键值对的内存，并减少值的引用计数
 */
static void hashtable_do_clear(hashtable_t *hashtable) {
    list_t *list, *next;
    pair_t *pair;

    /* 遍历主链表中的所有键值对 */
    for (list = hashtable->list.next; list != &hashtable->list; list = next) {
        next = list->next;  /* 保存下一个节点，防止删除当前节点后丢失链表 */
        pair = list_to_pair(list);
        json_decref(pair->value);  /* 减少值的引用计数 */
        jsonp_free(pair);  /* 释放键值对内存 */
    }
}

/**
 * 重新哈希哈希表，扩大容量
 * 参数:
 *   hashtable - 哈希表指针
 * 返回值:
 *   成功返回0，内存分配失败返回-1
 * 功能:
 *   当哈希表负载过高时，创建更大的桶数组并重新分配所有键值对
 */
static int hashtable_do_rehash(hashtable_t *hashtable) {
    list_t *list, *next;
    pair_t *pair;
    size_t i, index, new_size, new_order;
    struct hashtable_bucket *new_buckets;

    /* 计算新的大小，扩大一倍 */
    new_order = hashtable->order + 1;  /* 阶数+1，容量翻倍 */
    new_size = hashsize(new_order);    /* 新的桶数量 */

    /* 分配新的桶数组 */
    new_buckets = jsonp_malloc(new_size * sizeof(bucket_t));
    if (!new_buckets)
        return -1;  /* 内存分配失败 */

    /* 释放旧桶并更新哈希表属性 */
    jsonp_free(hashtable->buckets);
    hashtable->buckets = new_buckets;
    hashtable->order = new_order;

    /* 初始化所有新桶 */
    for (i = 0; i < hashsize(hashtable->order); i++) {
        hashtable->buckets[i].first = hashtable->buckets[i].last = &hashtable->list;
    }

    /* 保存第一个元素并重置主链表 */
    list = hashtable->list.next;
    list_init(&hashtable->list);

    /* 重新插入所有键值对到新桶中 */
    for (; list != &hashtable->list; list = next) {
        next = list->next;  /* 保存下一个节点 */
        pair = list_to_pair(list);
        index = pair->hash % new_size;  /* 计算新的桶索引 */
        insert_to_bucket(hashtable, &hashtable->buckets[index], &pair->list);
    }

    return 0;  /* 重新哈希成功 */
}

/**
 * 初始化哈希表
 * 参数:
 *   hashtable - 要初始化的哈希表结构
 * 返回值:
 *   成功返回0，内存分配失败返回-1
 * 功能:
 *   设置哈希表的初始属性，分配桶数组并初始化链表结构
 */
int hashtable_init(hashtable_t *hashtable) {
    size_t i;

    /* 设置初始属性 */
    hashtable->size = 0;  /* 初始元素数量为0 */
    hashtable->order = INITIAL_HASHTABLE_ORDER;  /* 使用默认初始阶数 */
    
    /* 分配桶数组 */
    hashtable->buckets = jsonp_malloc(hashsize(hashtable->order) * sizeof(bucket_t));
    if (!hashtable->buckets)
        return -1;  /* 内存分配失败 */

    /* 初始化主链表和有序链表 */
    list_init(&hashtable->list);
    list_init(&hashtable->ordered_list);

    /* 初始化所有桶 */
    for (i = 0; i < hashsize(hashtable->order); i++) {
        hashtable->buckets[i].first = hashtable->buckets[i].last = &hashtable->list;
    }

    return 0;  /* 初始化成功 */
}

/**
 * 关闭哈希表并释放资源
 * 参数:
 *   hashtable - 要关闭的哈希表
 * 功能:
 *   释放所有键值对和桶数组的内存
 */
void hashtable_close(hashtable_t *hashtable) {
    hashtable_do_clear(hashtable);  /* 清空所有元素 */
    jsonp_free(hashtable->buckets); /* 释放桶数组内存 */
}

/**
 * 初始化键值对结构
 * 参数:
 *   value - 关联的值
 *   key - 键字符串
 *   key_len - 键的长度
 *   hash - 键的哈希值
 * 返回值:
 *   成功返回新分配的键值对指针，失败返回NULL
 * 功能:
 *   分配内存并初始化键值对，处理键的存储和边界检查
 */
static pair_t *init_pair(json_t *value, const char *key, size_t key_len, size_t hash) {
    pair_t *pair;

    /* offsetof(...) 返回pair_t结构中不包含最后一个柔性数组成员的大小
     * 这样可以正确分配所需的内存量
     */

    /* 检查键长度是否会导致内存溢出 */
    if (key_len >= (size_t)-1 - offsetof(pair_t, key)) {
        /* 避免因键过长导致的溢出 */
        return NULL;
    }

    /* 分配内存：结构大小 + 键长度 + 结束符 */
    pair = jsonp_malloc(offsetof(pair_t, key) + key_len + 1);

    if (!pair)
        return NULL;  /* 内存分配失败 */

    /* 初始化键值对成员 */
    pair->hash = hash;                 /* 设置哈希值 */
    memcpy(pair->key, key, key_len);   /* 复制键内容 */
    pair->key[key_len] = '\0';         /* 添加字符串结束符 */
    pair->key_len = key_len;           /* 设置键长度 */
    pair->value = value;               /* 设置值 */

    /* 初始化链表节点 */
    list_init(&pair->list);
    list_init(&pair->ordered_list);

    return pair;
}

/**
 * 在哈希表中设置键值对
 * 参数:
 *   hashtable - 哈希表指针
 *   key - 键字符串
 *   key_len - 键的长度
 *   value - 要关联的值
 * 返回值:
 *   成功返回0，失败返回-1
 * 功能:
 *   如果键已存在，更新值；否则插入新的键值对
 */
int hashtable_set(hashtable_t *hashtable, const char *key, size_t key_len, 
                  json_t *value) {
    pair_t *pair;
    bucket_t *bucket;
    size_t hash, index;

    /* 当负载因子超过1时进行重新哈希 */
    if (hashtable->size >= hashsize(hashtable->order))
        if (hashtable_do_rehash(hashtable))
            return -1;

    /* 计算哈希值和桶索引 */
    hash = hash_str(key, key_len);
    index = hash & hashmask(hashtable->order);
    bucket = &hashtable->buckets[index];
    
    /* 查找键是否已存在 */
    pair = hashtable_find_pair(hashtable, bucket, key, key_len, hash);

    if (pair) {
        /* 键已存在，更新值 */
        json_decref(pair->value);  /* 减少旧值的引用计数 */
        pair->value = value;       /* 设置新值 */
    } else {
        /* 键不存在，创建新的键值对 */
        pair = init_pair(value, key, key_len, hash);

        if (!pair)
            return -1;  /* 内存分配失败 */

        /* 插入到桶和有序链表中 */
        insert_to_bucket(hashtable, bucket, &pair->list);
        list_insert(&hashtable->ordered_list, &pair->ordered_list);

        hashtable->size++;  /* 增加哈希表大小计数 */
    }
    return 0;  /* 设置成功 */
}

/**
 * 从哈希表中获取指定键的值
 * 参数:
 *   hashtable - 哈希表指针
 *   key - 键字符串
 *   key_len - 键的长度
 * 返回值:
 *   如果找到键，返回对应的值指针；否则返回NULL
 * 功能:
 *   通过哈希值快速查找键对应的键值对，并返回其值
 */
void *hashtable_get(hashtable_t *hashtable, const char *key, size_t key_len) {
    pair_t *pair;
    size_t hash;
    bucket_t *bucket;

    /* 计算哈希值和桶索引 */
    hash = hash_str(key, key_len);
    bucket = &hashtable->buckets[hash & hashmask(hashtable->order)];

    /* 查找键值对 */
    pair = hashtable_find_pair(hashtable, bucket, key, key_len, hash);
    if (!pair)
        return NULL;  /* 键不存在 */

    return pair->value;  /* 返回值指针 */
}

/**
 * 从哈希表中删除指定键的键值对
 * 参数:
 *   hashtable - 哈希表指针
 *   key - 要删除的键
 *   key_len - 键的长度
 * 返回值:
 *   成功删除返回0，键不存在返回-1
 * 功能:
 *   计算键的哈希值并调用内部删除函数
 */
int hashtable_del(hashtable_t *hashtable, const char *key, size_t key_len) {
    size_t hash = hash_str(key, key_len);
    return hashtable_do_del(hashtable, key, key_len, hash);
}

/**
 * 清空哈希表中的所有元素，但保留桶结构
 * 参数:
 *   hashtable - 哈希表指针
 * 功能:
 *   释放所有键值对，但保持哈希表结构可用
 */
void hashtable_clear(hashtable_t *hashtable) {
    size_t i;

    /* 清空所有键值对 */
    hashtable_do_clear(hashtable);

    /* 重置所有桶的首尾指针 */
    for (i = 0; i < hashsize(hashtable->order); i++) {
        hashtable->buckets[i].first = hashtable->buckets[i].last = &hashtable->list;
    }

    /* 重置链表结构 */
    list_init(&hashtable->list);
    list_init(&hashtable->ordered_list);
    hashtable->size = 0;  /* 重置元素计数 */
}

/**
 * 获取哈希表的第一个迭代器
 * 参数:
 *   hashtable - 哈希表指针
 * 返回值:
 *   指向第一个元素的迭代器，或NULL（如果哈希表为空）
 * 功能:
 *   初始化哈希表迭代，返回第一个元素的位置
 */
void *hashtable_iter(hashtable_t *hashtable) {
    return hashtable_iter_next(hashtable, &hashtable->ordered_list);
}

/**
 * 获取指定键对应的迭代器位置
 * 参数:
 *   hashtable - 哈希表指针
 *   key - 键字符串
 *   key_len - 键的长度
 * 返回值:
 *   如果键存在，返回对应的迭代器；否则返回NULL
 * 功能:
 *   定位到特定键的位置，用于后续迭代操作
 */
void *hashtable_iter_at(hashtable_t *hashtable, const char *key, size_t key_len) {
    pair_t *pair;
    size_t hash;
    bucket_t *bucket;

    /* 计算哈希值和桶索引 */
    hash = hash_str(key, key_len);
    bucket = &hashtable->buckets[hash & hashmask(hashtable->order)];

    /* 查找键值对 */
    pair = hashtable_find_pair(hashtable, bucket, key, key_len, hash);
    if (!pair)
        return NULL;  /* 键不存在 */

    return &pair->ordered_list;  /* 返回有序链表中的位置 */
}

/**
 * 获取下一个迭代器位置
 * 参数:
 *   hashtable - 哈希表指针
 *   iter - 当前迭代器位置
 * 返回值:
 *   指向下一个元素的迭代器，或NULL（如果已到达末尾）
 * 功能:
 *   移动迭代器到下一个元素
 */
void *hashtable_iter_next(hashtable_t *hashtable, void *iter) {
    list_t *list = (list_t *)iter;
    if (list->next == &hashtable->ordered_list)
        return NULL;  /* 已到达链表末尾 */
    return list->next;  /* 返回下一个节点 */
}

/**
 * 获取当前迭代器位置的键
 * 参数:
 *   iter - 迭代器位置
 * 返回值:
 *   当前元素的键指针
 * 功能:
 *   从迭代器中提取键
 */
void *hashtable_iter_key(void *iter) {
    pair_t *pair = ordered_list_to_pair((list_t *)iter);
    return pair->key;  /* 返回键指针 */
}

/**
 * 获取当前迭代器位置的键长度
 * 参数:
 *   iter - 迭代器位置
 * 返回值:
 *   当前元素的键长度
 * 功能:
 *   从迭代器中提取键的长度
 */
size_t hashtable_iter_key_len(void *iter) {
    pair_t *pair = ordered_list_to_pair((list_t *)iter);
    return pair->key_len;  /* 返回键长度 */
}

/**
 * 获取当前迭代器位置的值
 * 参数:
 *   iter - 迭代器位置
 * 返回值:
 *   当前元素的值指针
 * 功能:
 *   从迭代器中提取值
 */
void *hashtable_iter_value(void *iter) {
    pair_t *pair = ordered_list_to_pair((list_t *)iter);
    return pair->value;  /* 返回值指针 */
}

/**
 * 设置当前迭代器位置的值
 * 参数:
 *   iter - 迭代器位置
 *   value - 新的值
 * 功能:
 *   更新当前迭代位置的元素值
 */
void hashtable_iter_set(void *iter, json_t *value) {
    pair_t *pair = ordered_list_to_pair((list_t *)iter);

    json_decref(pair->value);  /* 减少旧值的引用计数 */
    pair->value = value;       /* 设置新值 */
}
