/*
 * Copyright (c) 2009-2016 Petri Lehtinen <petri@digip.org>
 * Copyright (c) 2011-2012 Basile Starynkevitch <basile@starynkevitch.net>
 * Copyright (c) 2015,2017,2023 Con Kolivas <kernel@kolivas.org>
 *
 * Jansson是自由软件；您可以根据MIT许可证的条款重新分发和/或修改它。
 * 详情请参阅LICENSE文件。
 */

#include <stdlib.h>
#include <string.h>

#include "jansson.h"
#include "jansson_private.h"

/* C89允许这些作为宏定义 */
#undef malloc
#undef free

/* 内存函数指针 */
static json_malloc_t do_malloc = malloc;
static json_free_t do_free = free;

/* 内存分配函数，封装了自定义的malloc函数 */
void *jsonp_malloc(size_t size) {
    if (!size)
        return NULL;

    return (*do_malloc)(size);
}

/* 安全的内存释放函数，会将指针置为NULL */
void _jsonp_free(void **ptr) {
    if (!*ptr)
        return;

    (*do_free)(*ptr);
    *ptr = NULL;
}

/* 字符串复制函数，内部调用带长度限制的版本 */
char *jsonp_strdup(const char *str) { return jsonp_strndup(str, strlen(str)); }

/* 带长度限制的字符串复制函数 */
char *jsonp_strndup(const char *str, size_t len) {
    char *new_str;

    new_str = jsonp_malloc(len + 1);
    if (!new_str)
        return NULL;

    memcpy(new_str, str, len);
    new_str[len] = '\0';
    return new_str;
}

/* 从字符串缓冲区中获取字符串并释放缓冲区的所有权 */
char *jsonp_strsteal(strbuffer_t *strbuff)
{
	size_t len = strbuff->length + 1;
	char *ret = realloc(strbuff->value, len);

	return ret;
}

/* 从字符串缓冲区中获取字符串，并在末尾添加换行符 */
char *jsonp_eolstrsteal(strbuffer_t *strbuff)
{
	size_t len = strbuff->length + 2;
	char *ret = realloc(strbuff->value, len);

	ret[strbuff->length] = '\n';
	ret[strbuff->length + 1] = '\0';
	return ret;
}

/* 设置自定义的内存分配和释放函数 */
void json_set_alloc_funcs(json_malloc_t malloc_fn, json_free_t free_fn) {
    do_malloc = malloc_fn;
    do_free = free_fn;
}

/* 获取当前使用的内存分配和释放函数 */
void json_get_alloc_funcs(json_malloc_t *malloc_fn, json_free_t *free_fn) {
    if (malloc_fn)
        *malloc_fn = do_malloc;
    if (free_fn)
        *free_fn = do_free;
}
