/*
 * Copyright (c) 2009-2016 Petri Lehtinen <petri@digip.org>
 * Copyright (c) 2015,2017,2023 Con Kolivas <kernel@kolivas.org>
 *
 * Jansson是自由软件；您可以根据MIT许可证的条款重新分发和/或修改它。详情请参阅LICENSE文件。
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "strbuffer.h"
#include "jansson_private.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* 字符串缓冲区最小大小 */
#define STRBUFFER_MIN_SIZE 4096
/* 扩容因子 */
#define STRBUFFER_FACTOR   2
/* 字符串缓冲区最大大小 */
#define STRBUFFER_SIZE_MAX ((size_t)-1)

/* 初始化字符串缓冲区 */
int strbuffer_init(strbuffer_t *strbuff) {
    strbuff->size = STRBUFFER_MIN_SIZE;
    strbuff->length = 0;

    strbuff->value = jsonp_malloc(strbuff->size);
    if (!strbuff->value)
        return -1;

    /* 初始化为空字符串 */
    strbuff->value[0] = '\0';
    return 0;
}

/* 关闭并清理字符串缓冲区 */
void strbuffer_close(strbuffer_t *strbuff) {
    if (strbuff->value)
        jsonp_free(strbuff->value);

    strbuff->size = 0;
    strbuff->length = 0;
    strbuff->value = NULL;
}

/* 清空字符串缓冲区内容 */
void strbuffer_clear(strbuffer_t *strbuff) {
    strbuff->length = 0;
    strbuff->value[0] = '\0';
}

/* 获取字符串缓冲区的当前值 */
const char *strbuffer_value(const strbuffer_t *strbuff) { return strbuff->value; }

/* 窃取字符串缓冲区的值（转移所有权） */
char *strbuffer_steal_value(strbuffer_t *strbuff) {
    char *result = strbuff->value;
    strbuff->value = NULL;
    return result;
}

/* 向字符串缓冲区追加一个字节 */
int strbuffer_append_byte(strbuffer_t *strbuff, char byte) {
    return strbuffer_append_bytes(strbuff, &byte, 1);
}

/* 向字符串缓冲区追加多个字节 */
int strbuffer_append_bytes(strbuffer_t *strbuff, const char *data, size_t size) {
    /* 为EOL和NULL字节预留空间 */
    if(size + 2 > strbuff->size - strbuff->length) {
	int backoff = 1;
        size_t new_size;
        char *new_value;

        /* 避免整数溢出 */
        if (strbuff->size > STRBUFFER_SIZE_MAX / STRBUFFER_FACTOR ||
            size > STRBUFFER_SIZE_MAX - 1 ||
            strbuff->length > STRBUFFER_SIZE_MAX - 1 - size)
            return -1;

        new_size = max(strbuff->size * STRBUFFER_FACTOR, strbuff->length + size + 1);

	/* 指数退避重试分配内存 */
	while (1) {
		new_value = realloc(strbuff->value, new_size);
		if (new_value)
			break;
		usleep(backoff * 1000);
		backoff <<= 1;
	}

        strbuff->value = new_value;
        strbuff->size = new_size;
    }

    memcpy(strbuff->value + strbuff->length, data, size);
    strbuff->length += size;
    strbuff->value[strbuff->length] = '\0';

    return 0;
}

/* 从字符串缓冲区尾部弹出一个字符 */
char strbuffer_pop(strbuffer_t *strbuff) {
    if (strbuff->length > 0) {
        char c = strbuff->value[--strbuff->length];
        strbuff->value[strbuff->length] = '\0';
        return c;
    } else
        return '\0';
}
