/*
 * Copyright (c) 2009-2016 Petri Lehtinen <petri@digip.org>
 * Copyright (c) 2015,2017,2023 Con Kolivas <kernel@kolivas.org>
 *
 * Jansson是一个自由软件；您可以按照MIT许可证的条款重新分发和/或修改它。
 * 详情请参阅LICENSE文件。
 *
 * 此文件包含Jansson库中的错误处理相关功能，用于初始化、设置和管理JSON解析和操作过程中的错误信息。
 */

#include "jansson_private.h"
#include <string.h>

/**
 * 初始化JSON错误结构体
 * 参数:
 *   error - 要初始化的错误结构体指针
 *   source - 错误源（如文件名），可以为NULL
 * 功能:
 *   将错误结构体的所有字段初始化为默认值，清空错误文本，设置行号、列号为-1，位置为0
 *   如果提供了source，则设置错误源信息
 */
void jsonp_error_init(json_error_t *error, const char *source) {
    if (error) {
        error->text[0] = '\0';  /* 清空错误文本 */
        error->line = -1;       /* 初始化为无效行号 */
        error->column = -1;     /* 初始化为无效列号 */
        error->position = 0;    /* 设置位置为0 */
        if (source)
            jsonp_error_set_source(error, source);  /* 设置错误源 */
        else
            error->source[0] = '\0';  /* 清空错误源 */
    }
}

/**
 * 设置错误源信息
 * 参数:
 *   error - 错误结构体指针
 *   source - 错误源信息（通常是文件名）
 * 功能:
 *   将错误源信息复制到错误结构体中，如果源信息过长则截断并添加省略号
 */
void jsonp_error_set_source(json_error_t *error, const char *source) {
    size_t length;

    if (!error || !source)
        return;

    length = strlen(source);
    if (length < JSON_ERROR_SOURCE_LENGTH)
        strncpy(error->source, source, length + 1);  /* 源信息长度合适，直接复制 */
    else {
        /* 源信息过长，截断并添加省略号 */
        size_t extra = length - JSON_ERROR_SOURCE_LENGTH + 4;
        memcpy(error->source, "...", 3);  /* 复制省略号 */
        strncpy(error->source + 3, source + extra, length - extra + 1);  /* 复制截断后的源信息 */
    }
}

/**
 * 设置JSON错误信息（可变参数版本）
 * 参数:
 *   error - 错误结构体指针
 *   line - 错误发生的行号
 *   column - 错误发生的列号
 *   position - 错误发生的位置
 *   code - 错误代码
 *   msg - 错误信息格式字符串
 *   ... - 格式化参数
 * 功能:
 *   格式化错误信息并设置到错误结构体中
 */
void jsonp_error_set(json_error_t *error, int line, int column, size_t position,
                     enum json_error_code code, const char *msg, ...) {
    va_list ap;

    va_start(ap, msg);  /* 初始化可变参数列表 */
    jsonp_error_vset(error, line, column, position, code, msg, ap);  /* 调用v版本函数设置错误信息 */
    va_end(ap);  /* 清理可变参数列表 */
}

/**
 * 设置JSON错误信息（va_list版本）
 * 参数:
 *   error - 错误结构体指针
 *   line - 错误发生的行号
 *   column - 错误发生的列号
 *   position - 错误发生的位置
 *   code - 错误代码
 *   msg - 错误信息格式字符串
 *   ap - va_list类型的参数列表
 * 功能:
 *   将错误的详细信息设置到错误结构体中，如果错误已设置则不再覆盖
 */
void jsonp_error_vset(json_error_t *error, int line, int column, size_t position,
                      enum json_error_code code, const char *msg, va_list ap) {
    if (!error)
        return;  /* 如果错误结构体为空，直接返回 */

    if (error->text[0] != '\0') {
        /* 错误已经设置过，不再覆盖 */
        return;
    }

    /* 设置错误位置信息 */
    error->line = line;          /* 设置行号 */
    error->column = column;      /* 设置列号 */
    error->position = (int)position;  /* 设置字符位置 */

    /* 格式化错误文本 */
    vsnprintf(error->text, JSON_ERROR_TEXT_LENGTH - 1, msg, ap);
    error->text[JSON_ERROR_TEXT_LENGTH - 2] = '\0';  /* 确保null终止 */
    error->text[JSON_ERROR_TEXT_LENGTH - 1] = code;  /* 存储错误代码在最后一个字节 */
}
