// clang-format off
/*
-------------------------------------------------------------------------------
lookup3.c, 作者：Bob Jenkins，2006年5月，公共领域。

这些函数用于生成32位哈希值，用于哈希表查找。
hashword()、hashlittle()、hashlittle2()、hashbig()、mix() 和 final() 是外部有用的函数。
如果定义了SELF_TEST，还包含了测试哈希的例程。您可以免费将其用于任何目的。它属于公共领域，没有任何担保。

您可能需要使用hashlittle()。hashlittle()和hashbig()可以哈希字节数组。
在小端序机器上，hashlittle()比hashbig()更快。Intel和AMD都是小端序机器。
更准确地说，您可能需要hashlittle2()，它与hashlittle()相同，只是一次返回两个32位哈希值。
您可以实现hashbig2()，但我在这里没有这样做。

如果您想计算恰好7个整数的哈希，可以这样做：
  a = i1;  b = i2;  c = i3;
  mix(a,b,c);
  a += i4; b += i5; c += i6;
  mix(a,b,c);
  a += i7;
  final(a,b,c);
然后使用c作为哈希值。如果您有一个可变长度的4字节整数数组需要哈希，使用hashword()。
如果您有一个字节数组（如字符串），使用hashlittle()。如果您有多个字节数组或混合类型，请参见hashlittle()上方的注释。

为什么这个函数这么大？我一次读取12个字节到3个4字节整数中，然后混合这些整数。
这很快（您可以用3个整数上的12*3条指令进行更彻底的混合，而不是用1个字节上的3条指令），
但高效地将这些字节填充到整数中是比较复杂的。
-------------------------------------------------------------------------------
*/

#include <stdlib.h>

#ifdef HAVE_CONFIG_H
#include <jansson_private_config.h>
#endif

#ifdef HAVE_STDINT_H
#include <stdint.h>     /* defines uint32_t etc */
#endif

#ifdef HAVE_SYS_PARAM_H
#include <sys/param.h>  /* attempt to define endianness */
#endif

#ifdef HAVE_ENDIAN_H
# include <endian.h>    /* attempt to define endianness */
#endif

/*
 * 我对您的机器是大端序还是小端序的最佳猜测。这可能需要调整。
 */
#if (defined(__BYTE_ORDER) && defined(__LITTLE_ENDIAN) && \
     __BYTE_ORDER == __LITTLE_ENDIAN) || \
    (defined(i386) || defined(__i386__) || defined(__i486__) || \
     defined(__i586__) || defined(__i686__) || defined(vax) || defined(MIPSEL))
# define HASH_LITTLE_ENDIAN 1
# define HASH_BIG_ENDIAN 0
#elif (defined(__BYTE_ORDER) && defined(__BIG_ENDIAN) && \
       __BYTE_ORDER == __BIG_ENDIAN) || \
      (defined(sparc) || defined(POWERPC) || defined(mc68000) || defined(sel))
# define HASH_LITTLE_ENDIAN 0
# define HASH_BIG_ENDIAN 1
#else
# define HASH_LITTLE_ENDIAN 0
# define HASH_BIG_ENDIAN 0
#endif

#define hashsize(n) ((size_t)1<<(n))
#define hashmask(n) (hashsize(n)-1)
#define rot(x,k) (((x)<<(k)) | ((x)>>(32-(k))))

/*
-------------------------------------------------------------------------------
mix -- 可逆地混合3个32位值。

这是可逆的，所以mix()之前(a,b,c)中的任何信息在mix()之后仍然存在于(a,b,c)中。

如果四对(a,b,c)输入通过mix()运行，或者反向通过mix()运行，
输出中至少有32位在某些情况下对一对相同而对另一对不同。
这已经测试过：
* 相差1位、2位的对，在(a,b,c)的高位任意组合，或(a,b,c)的低位任意组合。
* "differ"定义为+、-、^或~^。对于+和-，我将输出增量转换为格雷码(a^(a>>1))，
  这样一串1（通常由减法产生）看起来像单个1位差异。
* 基值是伪随机的，全为零但设置了一位，或全为零加上一个从0开始的计数器。

对于我的"a-=c; a^=rot(c,k); c+=b;"排列，满足这个条件的一些k值是：
    4  6  8 16 19  4
    9 15  3 18 27 15
   14  9  3  7 17  3
不过，对于定义为+的"differ"，使用1位基值和2位增量，
"9 15 3 18 27 15"没有完全获得32位差异。我使用http://burtleburtle.net/bob/hash/avalanche.html来选择操作、常量和变量的排列。

这不能实现雪崩效应。(a,b,c)的某些输入位无法影响(a,b,c)的某些输出位，特别是a的位。
混合最彻底的值是c，但它甚至没有真正在c中实现雪崩效应。

这允许一些并行性。读后写操作善于将受影响的位数加倍，
所以混合的目标与并行性的目标方向相反。我已经尽力了。
在我能接触到的每台机器上，旋转操作的成本似乎与移位操作一样高，
并且旋转操作对最高位和最低位更友好，所以我使用了旋转操作。
-------------------------------------------------------------------------------
*/
#define mix(a,b,c) \
{ \
  a -= c;  a ^= rot(c, 4);  c += b; \
  b -= a;  b ^= rot(a, 6);  a += c; \
  c -= b;  c ^= rot(b, 8);  b += a; \
  a -= c;  a ^= rot(c,16);  c += b; \
  b -= a;  b ^= rot(a,19);  a += c; \
  c -= b;  c ^= rot(b, 4);  b += a; \
}

/*
-------------------------------------------------------------------------------
final -- 将3个32位值(a,b,c)最终混合到c中

仅相差几个位的(a,b,c)值对通常会产生看起来完全不同的c值。这已经测试过：
* 相差1位、2位的对，在(a,b,c)的高位任意组合，或(a,b,c)的低位任意组合。
* "differ"定义为+、-、^或~^。对于+和-，我将输出增量转换为格雷码(a^(a>>1))，
  这样一串1（通常由减法产生）看起来像单个1位差异。
* 基值是伪随机的，全为零但设置了一位，或全为零加上一个从0开始的计数器。

这些常量通过了测试：
 14 11 25 16 4 14 24
 12 14 25 16 4 14 24
这些也接近：
  4  8 15 26 3 22 24
 10  8 15 26 3 22 24
 11  8 15 26 3 22 24
-------------------------------------------------------------------------------
*/
#define final(a,b,c) \
{ \
  c ^= b; c -= rot(b,14); \
  a ^= c; a -= rot(c,11); \
  b ^= a; b -= rot(a,25); \
  c ^= b; c -= rot(b,16); \
  a ^= c; a -= rot(c,4);  \
  b ^= a; b -= rot(a,14); \
  c ^= b; c -= rot(b,24); \
}

/*
-------------------------------------------------------------------------------
hashlittle() -- 将可变长度的键哈希成32位值
  k       : 键（不对齐的可变长度字节数组）
  length  : 键的长度，以字节计数
  initval : 可以是任何4字节值
返回一个32位值。键的每一位都会影响返回值的每一位。
相差一位或两位的两个键将具有完全不同的哈希值。

最好的哈希表大小是2的幂。不需要对质数取模（取模非常慢！）。
如果您需要少于32位，使用位掩码。例如，如果您只需要10位，请这样做：
  h = (h & hashmask(10));
在这种情况下，哈希表应该有hashsize(10)个元素。

如果您正在哈希n个字符串(uint8_t **)k，可以这样做：
  for (i=0, h=0; i<n; ++i) h = hashlittle( k[i], len[i], h);

作者：Bob Jenkins，2006年。bob_jenkins@burtleburtle.net。
您可以以任何方式使用此代码，私有、教育或商业用途均可。它是免费的。

用于哈希表查找，或任何可以接受2^32中出现一次冲突的场景。
不要用于加密目的。
-------------------------------------------------------------------------------
*/

static uint32_t hashlittle(const void *key, size_t length, uint32_t initval)
{
  uint32_t a,b,c;                                          /* internal state */
  union { const void *ptr; size_t i; } u;     /* needed for Mac Powerbook G4 */

  /* 设置内部状态 */
  a = b = c = 0xdeadbeef + ((uint32_t)length) + initval;

  u.ptr = key;
  if (HASH_LITTLE_ENDIAN && ((u.i & 0x3) == 0)) {
    const uint32_t *k = (const uint32_t *)key;         /* read 32-bit chunks */

/* 检测Valgrind或AddressSanitizer */
#ifdef VALGRIND
# define NO_MASKING_TRICK 1
#else
# if defined(__has_feature)  /* Clang */
#  if __has_feature(address_sanitizer)  /* is ASAN enabled? */
#   define NO_MASKING_TRICK 1
#  endif
# else
#  if defined(__SANITIZE_ADDRESS__)  /* GCC 4.8.x, is ASAN enabled? */
#   define NO_MASKING_TRICK 1
#  endif
# endif
#endif

#ifdef NO_MASKING_TRICK
    const uint8_t  *k8;
#endif

    /*------ 除最后一块外：对齐读取并影响(a,b,c)的32位 */
    while (length > 12)
    {
      a += k[0];
      b += k[1];
      c += k[2];
      mix(a,b,c);
      length -= 12;
      k += 3;
    }

    /*----------------------------- 处理最后一个（可能是部分的）块 */
    /* 
     * "k[2]&0xffffff"实际上会读取超出字符串末尾的内容，
     * 但随后会掩码掉它不允许读取的部分。因为字符串是对齐的，
     * 被掩码的尾部与字符串的其余部分在同一个字中。
     * 我见过的每台具有内存保护的机器都在字边界上进行保护，所以这样做是可以的。
     * 但VALGRIND仍会捕获到并抱怨。这种掩码技巧确实使短字符串（如英语单词）的哈希明显更快。
     */
#ifndef NO_MASKING_TRICK

    switch(length)
    {
    case 12: c+=k[2]; b+=k[1]; a+=k[0]; break;
    case 11: c+=k[2]&0xffffff; b+=k[1]; a+=k[0]; break;
    case 10: c+=k[2]&0xffff; b+=k[1]; a+=k[0]; break;
    case 9 : c+=k[2]&0xff; b+=k[1]; a+=k[0]; break;
    case 8 : b+=k[1]; a+=k[0]; break;
    case 7 : b+=k[1]&0xffffff; a+=k[0]; break;
    case 6 : b+=k[1]&0xffff; a+=k[0]; break;
    case 5 : b+=k[1]&0xff; a+=k[0]; break;
    case 4 : a+=k[0]; break;
    case 3 : a+=k[0]&0xffffff; break;
    case 2 : a+=k[0]&0xffff; break;
    case 1 : a+=k[0]&0xff; break;
    case 0 : return c;                     /* 零长度不需要混合 */
    }

#else /* 让valgrind满意 */

    k8 = (const uint8_t *)k;
    switch(length)
    {
    case 12: c+=k[2]; b+=k[1]; a+=k[0]; break;
    case 11: c+=((uint32_t)k8[10])<<16;  /* fall through */
    case 10: c+=((uint32_t)k8[9])<<8;    /* fall through */
    case 9 : c+=k8[8];                   /* fall through */
    case 8 : b+=k[1]; a+=k[0]; break;
    case 7 : b+=((uint32_t)k8[6])<<16;   /* fall through */
    case 6 : b+=((uint32_t)k8[5])<<8;    /* fall through */
    case 5 : b+=k8[4];                   /* fall through */
    case 4 : a+=k[0]; break;
    case 3 : a+=((uint32_t)k8[2])<<16;   /* fall through */
    case 2 : a+=((uint32_t)k8[1])<<8;    /* fall through */
    case 1 : a+=k8[0]; break;
    case 0 : return c;
    }

#endif /* !valgrind */

  } else if (HASH_LITTLE_ENDIAN && ((u.i & 0x1) == 0)) {  /* 16位对齐 */
    const uint16_t *k = (const uint16_t *)key;         /* read 16-bit chunks */
    const uint8_t  *k8;

    /*--------------- 除最后一块外：对齐读取和不同的混合 */
    while (length > 12)
    {
      a += k[0] + (((uint32_t)k[1])<<16);
      b += k[2] + (((uint32_t)k[3])<<16);
      c += k[4] + (((uint32_t)k[5])<<16);
      mix(a,b,c);
      length -= 12;
      k += 6;
    }

    /*----------------------------- 处理最后一个（可能是部分的）块 */
    k8 = (const uint8_t *)k;
    switch(length)
    {
    case 12: c+=k[4]+(((uint32_t)k[5])<<16);
             b+=k[2]+(((uint32_t)k[3])<<16);
             a+=k[0]+(((uint32_t)k[1])<<16);
             break;
    case 11: c+=((uint32_t)k8[10])<<16;     /* fall through */
    case 10: c+=k[4];
             b+=k[2]+(((uint32_t)k[3])<<16);
             a+=k[0]+(((uint32_t)k[1])<<16);
             break;
    case 9 : c+=k8[8];                      /* fall through */
    case 8 : b+=k[2]+(((uint32_t)k[3])<<16);
             a+=k[0]+(((uint32_t)k[1])<<16);
             break;
    case 7 : b+=((uint32_t)k8[6])<<16;      /* fall through */
    case 6 : b+=k[2];
             a+=k[0]+(((uint32_t)k[1])<<16);
             break;
    case 5 : b+=k8[4];                      /* fall through */
    case 4 : a+=k[0]+(((uint32_t)k[1])<<16);
             break;
    case 3 : a+=((uint32_t)k8[2])<<16;      /* fall through */
    case 2 : a+=k[0];
             break;
    case 1 : a+=k8[0];
             break;
    case 0 : return c;                     /* 零长度不需要混合 */
    }

  } else {                        /* 需要一次读取一个字节的键 */
    const uint8_t *k = (const uint8_t *)key;

    /*--------------- 除最后一块外：影响(a,b,c)的某些32位 */
    while (length > 12)
    {
      a += k[0];
      a += ((uint32_t)k[1])<<8;
      a += ((uint32_t)k[2])<<16;
      a += ((uint32_t)k[3])<<24;
      b += k[4];
      b += ((uint32_t)k[5])<<8;
      b += ((uint32_t)k[6])<<16;
      b += ((uint32_t)k[7])<<24;
      c += k[8];
      c += ((uint32_t)k[9])<<8;
      c += ((uint32_t)k[10])<<16;
      c += ((uint32_t)k[11])<<24;
      mix(a,b,c);
      length -= 12;
      k += 12;
    }

    /*-------------------------------- 最后一块：影响(c)的所有32位 */
    switch(length)                   /* 所有case语句都会贯穿执行 */
    {
    case 12: c+=((uint32_t)k[11])<<24; /* fall through */
    case 11: c+=((uint32_t)k[10])<<16; /* fall through */
    case 10: c+=((uint32_t)k[9])<<8; /* fall through */
    case 9 : c+=k[8]; /* fall through */
    case 8 : b+=((uint32_t)k[7])<<24; /* fall through */
    case 7 : b+=((uint32_t)k[6])<<16; /* fall through */
    case 6 : b+=((uint32_t)k[5])<<8; /* fall through */
    case 5 : b+=k[4]; /* fall through */
    case 4 : a+=((uint32_t)k[3])<<24; /* fall through */
    case 3 : a+=((uint32_t)k[2])<<16; /* fall through */
    case 2 : a+=((uint32_t)k[1])<<8; /* fall through */
    case 1 : a+=k[0];
             break;
    case 0 : return c;
    }
  }

  final(a,b,c);
  return c;
}
