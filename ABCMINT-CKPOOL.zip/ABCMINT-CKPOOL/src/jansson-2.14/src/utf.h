/*
 * 版权所有 (c) 2009-2016 Petri Lehtinen <petri@digip.org>
 * 版权所有 (c) 2015,2017,2023 Con Kolivas <kernel@kolivas.org>
 *
 * Jansson 是免费软件；您可以根据MIT许可证的条款重新分发和/或修改它。
 * 有关详细信息，请参阅LICENSE文件。
 */

#ifndef UTF_H
#define UTF_H

#ifdef HAVE_CONFIG_H
#include <jansson_private_config.h>
#endif

#include <stddef.h>
#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif

/* 将Unicode码点编码为UTF-8序列 */
int utf8_encode(int32_t codepoint, char *buffer, size_t *size);

/* 检查UTF-8序列的首字节，返回完整序列所需的字节数 */
size_t utf8_check_first(char byte);

/* 检查完整的UTF-8序列，验证其有效性并提取Unicode码点 */
size_t utf8_check_full(const char *buffer, size_t size, int32_t *codepoint);

/* 遍历UTF-8字符串，提取指定位置的Unicode码点 */
const char *utf8_iterate(const char *buffer, size_t size, int32_t *codepoint, int noutf8);

/* 检查整个字符串是否是有效的UTF-8编码 */
int utf8_check_string(const char *string, size_t length);

#endif
