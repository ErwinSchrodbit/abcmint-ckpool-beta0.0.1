.. _apiref:

*************
API 参考
*************

.. highlight:: c

预备知识
=============

所有声明都在 :file:`jansson.h` 中，因此在每个源文件中只需包含

::

   #include <jansson.h>

即可。

所有常量都以 ``JSON_`` 为前缀（描述库版本的常量除外，它们以 ``JANSSON_`` 为前缀）。其他标识符以 ``json_`` 为前缀。类型名称以 ``_t`` 为后缀并使用 ``typedef`` 定义，因此无需使用 ``struct`` 关键字。


库版本
===============

Jansson 版本格式为 *A.B.C*，其中 *A* 是主版本号，*B* 是次版本号，*C* 是微版本号。如果微版本号为零，则在版本字符串中省略，即版本字符串仅为 *A.B*。
当新版本只修复错误而不添加新功能时，微版本号递增。当以向后兼容的方式添加新功能时，次版本号递增，微版本号设为零。当有向后不兼容的更改时，主版本号递增，其他版本号设为零。
以下预处理器常量指定了库的当前版本：

``JANSSON_MAJOR_VERSION``, ``JANSSON_MINOR_VERSION``, ``JANSSON_MICRO_VERSION``
  分别指定主版本、次版本和微版本的整数。

``JANSSON_VERSION``
  当前版本的字符串表示形式，例如 ``"1.2.1"`` 或 ``"1.3"``。

``JANSSON_VERSION_HEX``
  版本的 3 字节十六进制表示形式，例如版本 1.2.1 为 ``0x010201``，版本 1.3 为 ``0x010300``。
  这在数值比较中很有用，例如：::

      #if JANSSON_VERSION_HEX >= 0x010300
      /* 特定于版本 1.3 及以上的代码 */
      #endif

此外，还有一些函数可以在运行时确定 Jansson 的版本：

.. function:: const char *jansson_version_str()

   返回 Jansson 库的版本，格式与 ``JANSSON_VERSION`` 预处理器常量相同。

   .. versionadded:: 2.13

.. function:: int jansson_version_cmp(int major, int minor, int micro)

   如果 Jansson 的运行时版本分别小于、等于或大于提供的 *major*、*minor* 和 *micro*，则返回一个小于、等于或大于零的整数。

   .. versionadded:: 2.13

``JANSSON_THREAD_SAFE_REFCOUNT``
  如果定义了此值，则 Jansson 中的所有只读操作和引用计数都是线程安全的。对于 ``2.11`` 之前的版本或编译器不提供内置原子函数时，不定义此值。


值表示
====================

JSON 规范 (:rfc:`4627`) 定义了以下数据类型：
*对象*、*数组*、*字符串*、*数字*、*布尔值* 和 *null*。JSON
types are used dynamically; arrays and objects can hold any other data
type, including themselves. For this reason, Jansson's type system is
also dynamic in nature. There's one C type to represent all JSON
values, and this structure knows the type of the JSON value it holds.

.. type:: json_t

  此数据结构在整个库中用于表示所有 JSON 值。它始终包含它所保存的 JSON 值的类型和该值的引用计数。其余部分取决于值的类型。
  value.

Objects of :type:`json_t` are always used through a pointer. There
are APIs for querying the type, manipulating the reference count, and
for constructing and manipulating values of different types.

Unless noted otherwise, all API functions return an error value if an
error occurs. Depending on the function's signature, the error value
is either *NULL* or -1. Invalid arguments or invalid input are
apparent sources for errors. Memory allocation and I/O operations may
also cause errors.


Type
----

.. c:enum:: json_type

   The type of a JSON value. The following members are defined:

   +--------------------+
   | ``JSON_OBJECT``    |
   +--------------------+
   | ``JSON_ARRAY``     |
   +--------------------+
   | ``JSON_STRING``    |
   +--------------------+
   | ``JSON_INTEGER``   |
   +--------------------+
   | ``JSON_REAL``      |
   +--------------------+
   | ``JSON_TRUE``      |
   +--------------------+
   | ``JSON_FALSE``     |
   +--------------------+
   | ``JSON_NULL``      |
   +--------------------+

   这些对应于 JSON 对象、数组、字符串、数字、布尔值和 null。数字由 ``JSON_INTEGER`` 类型或 ``JSON_REAL`` 类型的值表示。布尔值 true 由 ``JSON_TRUE`` 类型的值表示,false 由 ``JSON_FALSE`` 类型的值表示。

.. function:: int json_typeof(const json_t *json)

   返回 JSON 值的类型（一个转换为 ``int`` 的 :type:`json_type`）。*json* 不能为 *NULL*。此函数实际上是以宏的形式实现以提高速度。

.. function:: int json_is_object(const json_t *json)
              int json_is_array(const json_t *json)
              int json_is_string(const json_t *json)
              int json_is_integer(const json_t *json)
              int json_is_real(const json_t *json)
              int json_is_true(const json_t *json)
              int json_is_false(const json_t *json)
              int json_is_null(const json_t *json)

   这些函数（实际上是宏）对于给定类型的值返回 true(非零)，对于其他类型的值和 *NULL* 返回 false(零)。

.. function:: int json_is_number(const json_t *json)

   对于 ``JSON_INTEGER`` 和 ``JSON_REAL`` 类型的值返回 true,对于其他类型和 *NULL* 返回 false。

.. function:: int json_is_boolean(const json_t *json)

   对于 ``JSON_TRUE`` 和 ``JSON_FALSE`` 类型返回 true,对于其他类型的值和 *NULL* 返回 false。

.. function:: int json_boolean_value(const json_t *json)

   是 :func:`json_is_true()` 的别名，即对于 ``JSON_TRUE`` 返回 1,否则返回 0。

   .. versionadded:: 2.7


.. _apiref-reference-count:

引用计数
---------------

引用计数用于跟踪值是否仍在使用。当创建值时，其引用计数设置为 1。如果保留了对值的引用(例如,将值存储在某处以供以后使用)，则其引用计数增加，当不再需要该值时，引用计数减少。当引用计数降至零时，没有剩余引用，可以销毁该值。

.. function:: json_t *json_incref(json_t *json)

   如果 *json* 不为 *NULL*，则增加其引用计数。返回 *json*。

.. function:: void json_decref(json_t *json)

   减少 *json* 的引用计数。一旦对 :func:`json_decref()` 的调用使引用计数降至零，该值就会被销毁，不能再使用。

创建新 JSON 值的函数将引用计数设置为 1。这些函数被称为返回**新引用**。其他返回(现有)JSON 值的函数通常不会增加引用计数。这些函数被称为返回**借用引用**。因此，如果用户要持有作为借用引用返回的值的引用，则必须调用 :func:`json_incref`。一旦不再需要该值，应调用 :func:`json_decref` 来释放引用。

通常，所有接受 JSON 值作为参数的函数都会管理引用，即根据需要增加和减少引用计数。但是，有些函数会**窃取**引用，即它们的结果与用户在调用函数后立即对参数调用 :func:`json_decref()` 的结果相同。这些函数通常以 ``_new`` 为后缀或以 ``_new_`` 在名称的某处。

例如，以下代码创建一个新的 JSON 数组并向其中添加一个整数：::

  json_t *array, *integer;

  array = json_array();
  integer = json_integer(42);

  json_array_append(array, integer);
  json_decref(integer);

注意调用者如何通过调用 :func:`json_decref()` 来释放对整数值的引用。通过使用引用窃取函数 :func:`json_array_append_new()` 而不是 :func:`json_array_append()`，代码变得更简单：::

  json_t *array = json_array();
  json_array_append_new(array, json_integer(42));

在这种情况下，用户不必显式释放对整数值的引用，因为 :func:`json_array_append_new()` 在将值添加到数组时会窃取引用。

在以下各节中，将清楚地说明函数是返回新引用还是借用引用，或者是否会窃取对其参数的引用。


循环引用
-------------------

当对象或数组直接或间接插入自身内部时，会创建循环引用。直接情况很简单：::

  json_t *obj = json_object();
  json_object_set(obj, "foo", obj);

Jansson 将拒绝这样做，并且 :func:`json_object_set()`（以及对象和数组的所有其他此类函数）将返回错误状态。间接情况是危险的：::

  json_t *arr1 = json_array(), *arr2 = json_array();
  json_array_append(arr1, arr2);
  json_array_append(arr2, arr1);

在此示例中，数组 ``arr2`` 包含在数组 ``arr1`` 中,反之亦然。Jansson 无法在不影响性能的情况下检查此类间接循环引用，因此用户有责任避免它们。

如果创建了循环引用，则 :func:`json_decref()` 无法释放值消耗的内存。引用计数永远不会降至零，因为这些值相互保持引用。此外，尝试使用任何编码函数对这些值进行编码将会失败。编码器会检测到循环引用并返回错误状态。

作用域自动解引用
-------------------

.. versionadded:: 2.9

可以使用 ``json_auto_t`` 类型在作用域结束时自动解引用值。例如：::

  void function(void) {
    json_auto_t *value = NULL;
    value = json_string("foo");
    /* json_decref(value) 会自动调用。 */
  }

此功能仅在 GCC 和 Clang 上可用。因此，如果您的项目需要移植到其他编译器，则应避免使用此功能。

此外，与往常一样，在将值传递给窃取引用的函数时应小心。

True、False 和 Null
====================

这三个值是作为单例实现的，因此返回的指针在这些函数的多次调用之间不会改变。

.. function:: json_t *json_true(void)

   .. refcounting:: new

   返回 JSON true 值。

.. function:: json_t *json_false(void)

   .. refcounting:: new

   返回 JSON false 值。

.. function:: json_t *json_boolean(val)

   .. refcounting:: new

   如果 ``val`` 为零，则返回 JSON false，否则返回 JSON true。这是一个宏，等效于 ``val ? json_true() :
   json_false()``.

   .. versionadded:: 2.4


.. function:: json_t *json_null(void)

   .. refcounting:: new

   Returns the JSON null value.


String
======

Jansson uses UTF-8 as the character encoding. All JSON strings must be
valid UTF-8 (or ASCII, as it's a subset of UTF-8). All Unicode
codepoints U+0000 through U+10FFFF are allowed, but you must use
length-aware functions if you wish to embed null bytes in strings.

.. function:: json_t *json_string(const char *value)

   .. refcounting:: new

   Returns a new JSON string, or *NULL* on error. *value* must be a
   valid null terminated UTF-8 encoded Unicode string.

.. function:: json_t *json_stringn(const char *value, size_t len)

   .. refcounting:: new

   Like :func:`json_string`, but with explicit length, so *value* may
   contain null characters or not be null terminated.

   .. versionadded:: 2.7

.. function:: json_t *json_string_nocheck(const char *value)

   .. refcounting:: new

   Like :func:`json_string`, but doesn't check that *value* is valid
   UTF-8. Use this function only if you are certain that this really
   is the case (e.g. you have already checked it by other means).

.. function:: json_t *json_stringn_nocheck(const char *value, size_t len)

   .. refcounting:: new

   Like :func:`json_string_nocheck`, but with explicit length, so
   *value* may contain null characters or not be null terminated.

   .. versionadded:: 2.7

.. function:: const char *json_string_value(const json_t *string)

   返回 *string* 的关联值作为以空字符结尾的 UTF-8 编码字符串，如果 *string* 不是 JSON 字符串，则返回 *NULL*。

   返回的值是只读的，用户不得修改或释放。只要 *string* 存在（即其引用计数未降至零），它就是有效的。

.. function:: size_t json_string_length(const json_t *string)

   返回 *string* 在其 UTF-8 表示中的长度，如果 *string* 不是 JSON 字符串，则返回零。

   .. versionadded:: 2.7

.. function:: int json_string_set(json_t *string, const char *value)

   将 *string* 的关联值设置为 *value*。*value* 必须是有效的 UTF-8 编码的 Unicode 字符串。成功返回 0，失败返回 -1。

.. function:: int json_string_setn(json_t *string, const char *value, size_t len)

   类似于 :func:`json_string_set`，但具有显式长度，因此 *value* 可能包含空字符或不以空字符终止。

   .. versionadded:: 2.7

.. function:: int json_string_set_nocheck(json_t *string, const char *value)

   类似于 :func:`json_string_set`，但不检查 *value* 是否是有效的 UTF-8。只有当您确定情况确实如此时（例如，您已经通过其他方式检查过），才使用此函数。

.. function:: int json_string_setn_nocheck(json_t *string, const char *value, size_t len)

   类似于 :func:`json_string_set_nocheck`，但具有显式长度，因此 *value* 可能包含空字符或不以空字符终止。

   .. versionadded:: 2.7

.. function:: json_t *json_sprintf(const char *format, ...)
              json_t *json_vsprintf(const char *format, va_list ap)

   .. refcounting:: new

   从格式字符串和可变参数构造 JSON 字符串，就像
   :func:`printf()`.

   .. versionadded:: 2.11


数字
======

JSON 规范只包含一种数值类型 "number"。C 编程语言对于整数和浮点数有不同的类型，因此出于实用原因，Jansson 对这两种类型也有不同的类型。它们分别称为 "integer" 和 "real"。有关更多信息，请参阅 :ref:`rfc-conformance`。

.. type:: json_int_t

   这是用于存储 JSON 整数值的 C 类型。它表示系统上可用的最宽整数类型。实际上，如果编译器支持，它只是 ``long long`` 的别名，否则是 ``long`` 的别名。

   通常，您可以安全地使用普通的 ``int`` 代替 ``json_int_t``，隐式的 C 整数转换会处理其余部分。只有当您知道需要完整的 64 位范围时，才应显式使用 ``json_int_t``。

``JSON_INTEGER_IS_LONG_LONG``
   这是一个预处理器变量，如果 :type:`json_int_t` 是 ``long long``，则其值为 1，如果是 ``long``，则其值为 0。可以按如下方式使用：::

       #if JSON_INTEGER_IS_LONG_LONG
       /* 特定于 long long 的代码 */
       #else
       /* 特定于 long 的代码 */
       #endif

``JSON_INTEGER_FORMAT``
   这是一个宏，它展开为与 :type:`json_int_t` 对应的 :func:`printf()` 转换说明符，没有前导 ``%`` 符号，即 ``"lld"`` 或 ``"ld"``。需要此宏是因为 :type:`json_int_t` 的实际类型可以是 ``long`` 或 ``long long``，而 :func:`printf()` 对两者需要不同的长度修饰符。

   示例：::

       json_int_t x = 123123123;
       printf("x is %" JSON_INTEGER_FORMAT "\n", x);


.. function:: json_t *json_integer(json_int_t value)

   .. refcounting:: new

   返回一个新的 JSON 整数，如果出错则返回 *NULL*。

.. function:: json_int_t json_integer_value(const json_t *integer)

   返回 *integer* 的关联值，如果 *json* 不是 JSON 整数，则返回 0。

.. function:: int json_integer_set(const json_t *integer, json_int_t value)

   将 *integer* 的关联值设置为 *value*。成功返回 0，如果 *integer* 不是 JSON 整数则返回 -1。

.. function:: json_t *json_real(double value)

   .. refcounting:: new

   返回一个新的 JSON 实数，如果出错则返回 *NULL*。

.. function:: double json_real_value(const json_t *real)

   返回 *real* 的关联值，如果 *real* 不是 JSON 实数，则返回 0.0。

.. function:: int json_real_set(const json_t *real, double value)

   将 *real* 的关联值设置为 *value*。成功返回 0，如果 *real* 不是 JSON 实数则返回 -1。

.. function:: double json_number_value(const json_t *json)

   返回 JSON 整数或 JSON 实数 *json* 的关联值，无论实际类型如何都转换为 double。如果 *json* 既不是 JSON 实数也不是 JSON 整数，则返回 0.0。


数组
=====

JSON 数组是其他 JSON 值的有序集合。

.. function:: json_t *json_array(void)

   .. refcounting:: new

   返回一个新的 JSON 数组，如果出错则返回 *NULL*。初始时，数组为空。

.. function:: size_t json_array_size(const json_t *array)

   返回 *array* 中的元素数量，如果 *array* 为 NULL 或不是 JSON 数组，则返回 0。

.. function:: json_t *json_array_get(const json_t *array, size_t index)

   .. refcounting:: borrow

   返回 *array* 中位置 *index* 处的元素。*index* 的有效范围是从 0 到 :func:`json_array_size()` 的返回值减 1。如果 *array* 不是 JSON 数组，如果 *array* 为 *NULL*，或者 *index* 超出范围，则返回 *NULL*。

.. function:: int json_array_set(json_t *array, size_t index, json_t *value)

   用 *value* 替换 *array* 中位置 *index* 处的元素。*index* 的有效范围是从 0 到 :func:`json_array_size()` 的返回值减 1。成功返回 0，失败返回 -1。

.. function:: int json_array_set_new(json_t *array, size_t index, json_t *value)

   与 :func:`json_array_set()` 类似，但会窃取对 *value* 的引用。
   This is useful when *value* is newly created and not used after
   the call.

.. function:: int json_array_append(json_t *array, json_t *value)

   Appends *value* to the end of *array*, growing the size of *array*
   by 1. Returns 0 on success and -1 on error.

.. function:: int json_array_append_new(json_t *array, json_t *value)

   Like :func:`json_array_append()` but steals the reference to
   *value*。当 *value* 是新创建且在调用后不再使用时，这很有用。

.. function:: int json_array_insert(json_t *array, size_t index, json_t *value)

   在位置 *index* 处将 *value* 插入到 *array* 中，将 *index* 及其之后的元素向数组末尾方向移动一个位置。成功返回 0，失败返回 -1。

.. function:: int json_array_insert_new(json_t *array, size_t index, json_t *value)

   与 :func:`json_array_insert()` 类似，但会窃取对 *value* 的引用。当 *value* 是新创建且在调用后不再使用时，这很有用。

.. function:: int json_array_remove(json_t *array, size_t index)

   移除 *array* 中位置 *index* 处的元素，将 *index* 之后的元素向数组开头方向移动一个位置。成功返回 0，失败返回 -1。被移除的值的引用计数会减一。

.. function:: int json_array_clear(json_t *array)

   从 *array* 中移除所有元素。成功返回 0，失败返回 -1。所有被移除的值的引用计数都会减一。

.. function:: int json_array_extend(json_t *array, json_t *other_array)

   将 *other_array* 中的所有元素附加到 *array* 的末尾。成功返回 0，失败返回 -1。

.. function:: void json_array_foreach(array, index, value)

   遍历 ``array`` 中的每个元素，每次运行后续代码块时，将适当的值设置给变量 ``index`` 和 ``value``，分别为 :type:`size_t` 类型和 :type:`json_t` 指针类型。示例：
   ::

       /* array is a JSON array */
       size_t index;
       json_t *value;

       json_array_foreach(array, index, value) {
           /* block of code that uses index and value */
       }

   The items are returned in increasing index order.

   This macro expands to an ordinary ``for`` statement upon
   preprocessing, so its performance is equivalent to that of
   hand-written code using the array access functions.
   这个宏的主要优点是它抽象了复杂性，使代码更加简洁易读。

   .. versionadded:: 2.5


对象
======

JSON 对象是键值对的字典，其中键是 Unicode 字符串，值可以是任何 JSON 值。

尽管字符串值中允许使用空字节，但对象键中不允许使用。

.. function:: json_t *json_object(void)

   .. refcounting:: new

   返回一个新的 JSON 对象，如果出错则返回 *NULL*。初始时，对象为空。

.. function:: size_t json_object_size(const json_t *object)

   返回 *object* 中的元素数量，如果 *object* 不是 JSON 对象，则返回 0。

.. function:: json_t *json_object_get(const json_t *object, const char *key)

   .. refcounting:: borrow

   从 *object* 中获取与 *key* 对应的值。如果找不到 *key* 或发生错误，则返回 *NULL*。

.. function:: json_t *json_object_getn(const json_t *object, const char *key, size_t key_len)

   .. refcounting:: borrow

   与 :func:`json_object_get` 类似，但提供了固定长度 *key_len* 的 *key*。
   有关详细信息，请参见 :ref:`fixed_length_keys`。

   .. versionadded:: 2.14

.. function:: int json_object_set(json_t *object, const char *key, json_t *value)

   Set the value of *key* to *value* in *object*. *key* must be a
   有效的以 null 结尾的 UTF-8 编码的 Unicode 字符串。如果 *key* 已经有一个值，则用新值替换。成功返回 0，失败返回 -1。

.. function:: int json_object_setn(json_t *object, const char *key, size_t key_len, json_t *value)

   与 :func:`json_object_set` 类似，但提供了固定长度 *key_len* 的 *key*。
   有关详细信息，请参见 :ref:`fixed_length_keys`。

   .. versionadded:: 2.14

.. function:: int json_object_set_nocheck(json_t *object, const char *key, json_t *value)

   与 :func:`json_object_set` 类似，但不检查 *key* 是否为有效的 UTF-8。仅当您确定情况确实如此时（例如，您已经通过其他方式检查过），才使用此函数。

.. function:: int json_object_setn_nocheck(json_t *object, const char *key, size_t key_len, json_t *value)

   与 :func:`json_object_set_nocheck` 类似，但提供了固定长度 *key_len* 的 *key*。
   有关详细信息，请参见 :ref:`fixed_length_keys`。

   .. versionadded:: 2.14

.. function:: int json_object_set_new(json_t *object, const char *key, json_t *value)

   与 :func:`json_object_set()` 类似，但会窃取对 *value* 的引用。当 *value* 是新创建且在调用后不再使用时，这很有用。

.. function:: int json_object_setn_new(json_t *object, const char *key, size_t key_len, json_t *value)

   与 :func:`json_object_set_new` 类似，但提供了固定长度 *key_len* 的 *key*。
   有关详细信息，请参见 :ref:`fixed_length_keys`。

   .. versionadded:: 2.14

.. function:: int json_object_set_new_nocheck(json_t *object, const char *key, json_t *value)

   与 :func:`json_object_set_new` 类似，但不检查 *key* 是否为
   valid UTF-8. Use this function only if you are certain that this
   really is the case (e.g. you have already checked it by other
   means).

.. function:: int json_object_setn_new_nocheck(json_t *object, const char *key, size_t key_len, json_t *value)

   Like :func:`json_object_set_new_nocheck`, but give the fixed-length *key* with length *key_len*.
   See :ref:`fixed_length_keys` for details.

   .. versionadded:: 2.14

.. function:: int json_object_del(json_t *object, const char *key)

   如果存在，则从 *object* 中删除 *key*。成功返回 0，如果找不到 *key* 则返回 -1。被删除的值的引用计数会减一。

.. function:: int json_object_deln(json_t *object, const char *key, size_t key_len)

   与 :func:`json_object_del` 类似，但提供了固定长度 *key_len* 的 *key*。
   有关详细信息，请参见 :ref:`fixed_length_keys`。

   .. versionadded:: 2.14

.. function:: int json_object_clear(json_t *object)

   从 *object* 中移除所有元素。成功返回 0，如果 *object* 不是 JSON 对象则返回 -1。所有被删除的值的引用计数都会减一。

.. function:: int json_object_update(json_t *object, json_t *other)

   用 *other* 中的键值对更新 *object*，覆盖现有的键。成功返回 0，失败返回 -1。

.. function:: int json_object_update_existing(json_t *object, json_t *other)

   与 :func:`json_object_update()` 类似，但仅更新现有键的值。不会创建新键。成功返回 0，失败返回 -1。

   .. versionadded:: 2.3

.. function:: int json_object_update_missing(json_t *object, json_t *other)

   与 :func:`json_object_update()` 类似，但仅创建新键。任何现有键的值都不会改变。成功返回 0，失败返回 -1。

   .. versionadded:: 2.3

.. function:: int json_object_update_new(json_t *object, json_t *other)

   Like :func:`json_object_update()`, but steals the reference to
   *other*. This is useful when *other* is newly created and not used
   after the call.

.. function:: int json_object_update_existing_new(json_t *object, json_t *other)

   与 :func:`json_object_update_new()` 类似，但仅更新现有键的值。不会创建新键。成功返回 0，失败返回 -1。

.. function:: int json_object_update_missing_new(json_t *object, json_t *other)

   与 :func:`json_object_update_new()` 类似，但仅创建新键。任何现有键的值都不会改变。成功返回 0，失败返回 -1。

.. function:: int json_object_update_recursive(json_t *object, json_t *other)

   与 :func:`json_object_update()` 类似，但 *other* 中的对象值如果也是对象，则会与 *object* 中的对应值递归合并，而不是覆盖它们。成功返回 0，失败返回 -1。

.. function:: void json_object_foreach(object, key, value)

   遍历 ``object`` 中的每个键值对，每次运行后续代码块时，将适当的值设置给变量 ``key`` 和 ``value``，分别为 ``const char *`` 类型和 :type:`json_t` 指针类型。示例：
   ::

       /* obj 是一个 JSON 对象 */
       const char *key;
       json_t *value;

       json_object_foreach(obj, key, value) {
           /* 使用 key 和 value 的代码块 */
       }

   项目按照它们插入到对象中的顺序返回。

   **注意：** 在迭代过程中调用 ``json_object_del(object, key)`` 或 ``json_object_deln(object, key, key_len)`` 是不安全的。如果需要，请改用 :func:`json_object_foreach_safe`。

   此宏在预处理时会展开为普通的 ``for`` 语句
   preprocessing, so its performance is equivalent to that of
   hand-written iteration code using the object iteration protocol
   (see below). The main advantage of this macro is that it abstracts
   away the complexity behind iteration, and makes for more concise and
   readable code.

   .. versionadded:: 2.3


.. function:: void json_object_foreach_safe(object, tmp, key, value)

   与 :func:`json_object_foreach()` 类似，但在迭代过程中调用 ``json_object_del(object, key)`` 或 ``json_object_deln(object, key, key_len)`` 是安全的。您需要传递一个额外的 ``void *`` 参数 ``tmp`` 作为临时存储。

   .. versionadded:: 2.8

.. function:: void json_object_keylen_foreach(object, key, key_len, value)

   与 :c:func:`json_object_foreach` 类似，但在 *key_len* 中存储了 *key* 的长度。
   示例：
   ::

       /* obj 是一个 JSON 对象 */
       const char *key;
       json_t *value;
       size_t len;

       json_object_keylen_foreach(obj, key, len, value) {
            printf("got key %s with length %zu\n", key, len);
       }

   **注意：** 在迭代过程中调用 ``json_object_deln(object, key, key_len)`` 是不安全的。如果需要，请改用 :func:`json_object_keylen_foreach_safe`。

   .. versionadded:: 2.14


.. function:: void json_object_keylen_foreach_safe(object, tmp, key, key_len, value)

   与 :func:`json_object_keylen_foreach()` 类似，但在迭代过程中调用 ``json_object_deln(object, key, key_len)`` 是安全的。您需要传递一个额外的 ``void *`` 参数 ``tmp`` 作为临时存储。

   .. versionadded:: 2.14

以下函数可用于遍历对象中的所有键值对。项目按照它们插入到对象中的顺序返回。

.. function:: void *json_object_iter(json_t *object)

   Returns an opaque iterator which can be used to iterate over all
   key-value pairs in *object*, or *NULL* if *object* is empty.

.. function:: void *json_object_iter_at(json_t *object, const char *key)

   与 :func:`json_object_iter()` 类似，但返回指向 *object* 中键等于 *key* 的键值对的迭代器，如果在 *object* 中找不到 *key*，则返回 NULL。只有当 *key* 恰好是底层哈希表中的第一个键时，向前迭代到 *object* 末尾才会产生对象的所有键值对。

.. function:: void *json_object_iter_next(json_t *object, void *iter)

   返回指向 *object* 中 *iter* 之后下一个键值对的迭代器，如果整个对象已迭代完毕，则返回 *NULL*。

.. function:: const char *json_object_iter_key(void *iter)

   从 *iter* 中提取关联的键。

.. function:: size_t json_object_iter_key_len(void *iter)

   从 *iter* 中提取关联的键长度。

   .. versionadded:: 2.14

.. function:: json_t *json_object_iter_value(void *iter)

   .. refcounting:: borrow

   从 *iter* 中提取关联的值。

.. function:: int json_object_iter_set(json_t *object, void *iter, json_t *value)

   将 *object* 中由 *iter* 指向的键值对的值设置为 *value*。

.. function:: int json_object_iter_set_new(json_t *object, void *iter, json_t *value)

   与 :func:`json_object_iter_set()` 类似，但会窃取对 *value* 的引用。当 *value* 是新创建且在调用后不再使用时，这很有用。

.. function:: void *json_object_key_to_iter(const char *key)

   Like :func:`json_object_iter_at()`, but much faster. Only works for
   values returned by :func:`json_object_iter_key()`. Using other keys
   will lead to segfaults. This function is used internally to
   实现 :func:`json_object_foreach`。示例::

     /* obj 是一个 JSON 对象 */
     const char *key;
     json_t *value;
  
     void *iter = json_object_iter(obj);
     while(iter)
     {
         key = json_object_iter_key(iter);
         value = json_object_iter_value(iter);
         /* 使用 key 和 value ... */
         iter = json_object_iter_next(obj, iter);
     }

   .. versionadded:: 2.3

.. function:: void json_object_seed(size_t seed)

    为 Jansson 的哈希表实现中使用的哈希函数设置种子。
    该种子用于随机化哈希函数，使得攻击者无法控制其输出。

    如果 *seed* 为 0，则 Jansson 会通过从操作系统的熵源读取随机数据来生成种子。
    如果没有可用的熵源，则会回退到使用当前时间戳（如果可能，精确到微秒）和进程 ID 的组合。

    如果要调用此函数，则必须在任何对 :func:`json_object()` 的调用（无论是显式还是隐式）之前调用它。
    如果用户未调用此函数，则首次调用 :func:`json_object()`（无论是显式还是隐式）时会为哈希函数设置种子。
    有关线程安全性的注意事项，请参见 :ref:`thread-safety`。

    如果需要可重复的结果，例如在单元测试中，可以通过在程序启动时使用常量值调用 :func:`json_object_seed` 来"取消随机化"哈希函数，
    例如 ``json_object_seed(1)``。

    .. versionadded:: 2.6


错误报告
========

Jansson 使用单个结构体类型向用户传递错误信息。
请参见 :ref:`apiref-decoding`、:ref:`apiref-pack` 和 :ref:`apiref-unpack` 章节，了解使用此结构体传递错误信息的函数。

.. type:: json_error_t

   .. member:: char text[]

      错误消息（UTF-8编码），如果没有可用消息则为空字符串。

      该数组的最后一个字节包含数字错误代码。请使用
      :func:`json_error_code()` 来提取此代码。

   .. member:: char source[]

      错误的来源。这可以是（部分）文件名或尖括号中的特殊标识符（例如 ``<string>``）。

   .. member:: int line

      发生错误的行号。

   .. member:: int column

      发生错误的列号。请注意，这是*字符列*，而不是字节列，即多字节UTF-8字符算作一列。

   .. member:: int position

      从输入开始的字节位置。这对调试Unicode编码问题很有用。

:type:`json_error_t` 的常规用法是在栈上分配它，并将指针传递给函数。示例::

   int main() {
       json_t *json;
       json_error_t error;

       json = json_load_file("/path/to/file.json", 0, &error);
       if(!json) {
           /* error 变量包含错误信息 */
       }
       ...
   }

另请注意，如果调用成功（上述示例中的 ``json != NULL``），
`error` 的内容通常未指定。解码函数在成功时也会写入 `position` 成员。
有关更多信息，请参见 :ref:`apiref-decoding`。

所有函数还接受 *NULL* 作为 :type:`json_error_t` 指针，
在这种情况下，不会向调用者返回任何错误信息。

.. c:enum:: json_error_code

   包含数字错误代码的枚举。当前定义了以下错误：

   ``json_error_unknown``

       未知错误。这应该仅返回给非错误的
       :type:`json_error_t` 结构体。

   ``json_error_out_of_memory``

       库无法分配堆内存。

   ``json_error_stack_overflow``

       嵌套过深。

   ``json_error_cannot_open_file``

       无法打开输入文件。

   ``json_error_invalid_argument``

       函数参数无效。

   ``json_error_invalid_utf8``

       输入字符串不是有效的 UTF-8。

   ``json_error_premature_end_of_input``

       输入在 JSON 值的中间结束。

   ``json_error_end_of_input_expected``

       在 JSON 值结束后还有一些文本。请参阅
       ``JSON_DISABLE_EOF_CHECK`` 标志。

   ``json_error_invalid_syntax``

       JSON 语法错误。

   ``json_error_invalid_format``

       打包或解包的格式字符串无效。

   ``json_error_wrong_type``

       在打包或解包时，值的实际类型与格式字符串中指定的类型不同。

   ``json_error_null_character``

       在 JSON 字符串中检测到空字符。请参阅
       ``JSON_ALLOW_NUL`` 标志。

   ``json_error_null_value``

       在打包或解包时，某些键或值为 ``NULL``。

   ``json_error_null_byte_in_key``

       对象键包含空字节。Jansson 无法表示此类键；
       请参见 :ref:`rfc-conformance`。

   ``json_error_duplicate_key``

       对象中的重复键。请参阅 ``JSON_REJECT_DUPLICATES`` 标志。

   ``json_error_numeric_overflow``

       将 JSON 数字转换为 C 数字类型时，检测到数值溢出。

   ``json_error_item_not_found``

       对象中的键未找到。

   ``json_error_index_out_of_range``

   .. versionadded:: 2.11

.. function:: enum json_error_code json_error_code(const json_error_t *error)

   返回嵌入在 ``error->text`` 中的错误代码。

   .. versionadded:: 2.11


编码
====

本节介绍可用于将值编码为 JSON 的函数。默认情况下，只有对象和数组可以直接编码，
因为它们是 JSON 文本的唯一有效*根*值。要编码任何 JSON 值，请使用 ``JSON_ENCODE_ANY`` 标志（见下文）。

默认情况下，输出没有换行符，数组和对象元素之间使用空格以获得可读的输出。
这种行为可以通过使用下面描述的 ``JSON_INDENT`` 和 ``JSON_COMPACT`` 标志来改变。
编码的 JSON 数据末尾永远不会附加换行符。

每个函数都接受一个 *flags* 参数，用于控制数据编码的某些方面。其默认值为 0。
以下宏可以通过 OR 操作组合在一起以获得 *flags*。

``JSON_INDENT(n)``
   美化输出结果，在数组和对象项之间使用换行符，并使用 *n* 个空格进行缩进。
   *n* 的有效范围是 0 到 31（包括 0 和 31），其他值会导致未定义的输出。
   如果不使用 ``JSON_INDENT`` 或 *n* 为 0，则不会在数组和对象项之间插入换行符。

   ``JSON_MAX_INDENT`` 常量定义了可以使用的最大缩进，其值为 31。

   .. versionchanged:: 2.7
      添加了 ``JSON_MAX_INDENT``。

``JSON_COMPACT``
   此标志启用紧凑表示形式，即将数组和对象项之间的分隔符设置为 ``","``，
   对象键和值之间的分隔符设置为 ``":"``。没有此标志时，相应的分隔符为 ``", "``
   和 ``": "``，以获得更可读的输出。

``JSON_ENSURE_ASCII``
   如果使用此标志，保证输出仅由 ASCII 字符组成。这是通过对所有 ASCII 范围外的 Unicode
   字符进行转义来实现的。

``JSON_SORT_KEYS``
   如果使用此标志，输出中的所有对象都将按键排序。
   这在比较两个 JSON 文本或进行视觉比较时很有用。

``JSON_PRESERVE_ORDER``
   **自 2.8 版本起已弃用：** 对象键的顺序始终被保留。

   在 2.8 版本之前：如果使用此标志，输出中的对象键将按照它们首次插入对象的顺序排序。
   例如，解码 JSON 文本然后使用此标志编码会保留对象键的顺序。

``JSON_ENCODE_ANY``
   指定此标志可以单独编码任何 JSON 值。没有此标志，只能将对象和数组作为
   *json* 值传递给编码函数。

   **注意：** 在某些情况下，编码任何值可能很有用，但通常不建议这样做，因为它违反了与
   :rfc:`4627` 的严格兼容性。如果使用此标志，不要期望与其他 JSON 系统具有互操作性。

   .. versionadded:: 2.1

``JSON_ESCAPE_SLASH``
   在字符串中将 ``/`` 字符转义为 ``\/``。

   .. versionadded:: 2.4

``JSON_REAL_PRECISION(n)``
   输出所有实数，精度最多为 *n* 位。
   *n* 的有效范围是 0 到 31（包括 0 和 31），其他值会导致未定义行为。

   默认情况下，精度为 17，以正确且无损地编码所有 IEEE 754 双精度浮点数。

   .. versionadded:: 2.7

``JSON_EMBED``
   如果使用此标志，顶级数组（'['、']'）或对象（'{'、'}'）的开始和结束字符
   在编码过程中将被省略。此标志在将多个数组或对象连接成流时很有用。

   .. versionadded:: 2.10

这些函数输出 UTF-8：

.. function:: char *json_dumps(const json_t *json, size_t flags)

   Returns the JSON representation of *json* as a string, or *NULL* on
   error. *flags* is described above. The return value must be freed
   by the caller using :func:`free()`. Note that if you have called
   :func:`json_set_alloc_funcs()` to override :func:`free()`, you should
   call your custom free function instead to free the return value.

.. function:: size_t json_dumpb(const json_t *json, char *buffer, size_t size, size_t flags)

   将 *json* 的 JSON 表示写入到大小为 *size* 字节的 *buffer* 中。
   返回将要写入的字节数，出错时返回 0。*flags* 如上所述。*buffer* 不是以空字符结尾的。

   此函数永远不会写入超过 *size* 字节。如果返回值大于 *size*，则 *buffer* 的内容
   是未定义的。这种行为使您可以指定 NULL *buffer* 来确定编码的长度。例如::

       size_t size = json_dumpb(json, NULL, 0, 0);
       if (size == 0)
           return -1;

       char *buf = alloca(size);

       size = json_dumpb(json, buf, size, 0);

   .. versionadded:: 2.10

.. function:: int json_dumpf(const json_t *json, FILE *output, size_t flags)

   将 *json* 的 JSON 表示写入到流 *output* 中。
   *flags* 如上所述。成功时返回 0，出错时返回 -1。
   如果发生错误，可能已经向 *output* 写入了一些内容。在这种情况下，输出是未定义的，很可能不是有效的 JSON。

.. function:: int json_dumpfd(const json_t *json, int output, size_t flags)

   将 *json* 的 JSON 表示写入到流 *output* 中。
   *flags* 如上所述。成功时返回 0，出错时返回 -1。
   如果发生错误，可能已经向 *output* 写入了一些内容。在这种情况下，输出是未定义的，很可能不是有效的 JSON。

   重要的是要注意，此函数只能在流文件描述符（如 SOCK_STREAM）上成功。
   在非流文件描述符上使用此函数将导致未定义行为。
   对于非流文件描述符，请改用 :func:`json_dumpb()`。

   This function requires POSIX and fails on all non-POSIX systems.

   .. versionadded:: 2.10

.. function:: int json_dump_file(const json_t *json, const char *path, size_t flags)

   Write the JSON representation of *json* to the file *path*. If
   *path* already exists, it is overwritten. *flags* is described
   above. Returns 0 on success and -1 on error.

.. type:: json_dump_callback_t

   由 :func:`json_dump_callback()` 调用的函数的类型定义::

       typedef int (*json_dump_callback_t)(const char *buffer, size_t size, void *data);

   *buffer* 指向包含输出块的缓冲区，*size* 是缓冲区的长度，
   *data* 是传递的对应 :func:`json_dump_callback()` 参数。

   *buffer* 保证是有效的 UTF-8 字符串（即保留多字节代码单元序列）。
   *buffer* 永远不会包含嵌入的空字节。

   出错时，函数应返回 -1 以停止编码过程。成功时，应返回 0。

   .. versionadded:: 2.2

.. function:: int json_dump_callback(const json_t *json, json_dump_callback_t callback, void *data, size_t flags)

   重复调用 *callback*，每次传递 *json* 的 JSON 表示的一个块。
   *flags* 如上所述。成功时返回 0，出错时返回 -1。

   .. versionadded:: 2.2


.. _apiref-decoding:

解码
====

本节介绍可用于将 JSON 文本解码为 Jansson 表示的 JSON 数据的函数。
JSON 规范要求 JSON 文本必须是序列化的数组或对象，以下函数也强制执行此要求。
换句话说，正在处理的 JSON 文本中的顶层值
decoded must be either array or object. To decode any JSON value, use
可以使用 ``JSON_DECODE_ANY`` 标志（见下文）。

有关 Jansson 对 JSON 规范的一致性讨论，请参阅 :ref:`rfc-conformance`。
它解释了许多影响解码器行为的设计决策。

每个函数都接受一个 *flags* 参数，可用于控制解码器的行为。
其默认值为 0。以下宏可以按位或运算组合以获得 *flags*。

``JSON_REJECT_DUPLICATES``
   如果输入文本中的任何 JSON 对象包含重复键，则发出解码错误。
   如果没有此标志，则每个键的最后一次出现的值会保留在结果中。
   键的等效性是逐字节检查的，不使用特殊的 Unicode 比较算法。

   .. versionadded:: 2.1

``JSON_DECODE_ANY``
   默认情况下，解码器期望输入是数组或对象。启用此标志后，
   解码器接受任何有效的 JSON 值。

   **注意：** 解码任何值在某些场景下可能有用，但通常不推荐使用，
   因为它违反了与 :rfc:`4627` 的严格兼容性。如果使用此标志，
   不要期望与其他 JSON 系统的互操作性。

   .. versionadded:: 2.3

``JSON_DISABLE_EOF_CHECK``
   默认情况下，解码器期望整个输入构成有效的 JSON 文本，
   如果在其他有效的 JSON 输入后有额外数据，则发出错误。
   启用此标志后，解码器在解码有效的 JSON 数组或对象后停止，
   从而允许在 JSON 文本后有额外数据。

   正常情况下，当遇到 JSON 输入中的最后一个 ``]`` 或 ``}`` 时，
   读取将停止。如果同时使用 ``JSON_DISABLE_EOF_CHECK`` 和
   ``JSON_DECODE_ANY`` 标志，解码器可能会多读取一个 UTF-8 代码单元
   （最多 4 字节的输入）。例如，解码
   ``4true`` 会正确解码整数 4，但也会读取 ``t``。因此，
   如果读取多个连续的非数组或对象的值，它们应该由至少一个空白字符分隔。

   .. versionadded:: 2.1

``JSON_DECODE_INT_AS_REAL``
   JSON 只定义了一种数字类型。Jansson 区分整数和实数。
   有关更多信息，请参阅 :ref:`real-vs-integer`。启用此标志后，
   解码器将所有数字解释为实数值。没有精确双精度表示的整数
   将导致精度丢失，但不会报错。导致双精度溢出的整数将导致错误。

   .. versionadded:: 2.5

``JSON_ALLOW_NUL``
   允许字符串值中包含 ``\u0000`` 转义。这是一种安全措施；
   如果您知道输入可能包含空字节，请使用此标志。如果不使用此标志，
   您不必担心字符串中的空字节，除非您通过使用例如
   :func:`json_stringn()` 或 :func:`json_pack()` 的 ``s#`` 格式说明符
   显式创建它们。

   即使使用此标志，对象键也不能包含嵌入的空字节。

   .. versionadded:: 2.6

每个函数还接受一个可选的 :type:`json_error_t` 参数，如果解码失败，
该参数将填充错误信息。它也会在成功时更新；读取的输入字节数
会写入其 ``position`` 字段。当使用 ``JSON_DISABLE_EOF_CHECK``
读取多个连续的 JSON 文本时，这特别有用。

.. versionadded:: 2.3
   读取的输入字节数会写入 :type:`json_error_t` 结构的 ``position`` 字段。

如果不需要错误或位置信息，可以传递 *NULL*。

.. function:: json_t *json_loads(const char *input, size_t flags, json_error_t *error)

   .. refcounting:: new

   解码 JSON 字符串 *input* 并返回它包含的数组或对象，如果出错则返回 *NULL*，
   此时 *error* 会填充错误信息。*flags* 如上所述。

.. function:: json_t *json_loadb(const char *buffer, size_t buflen, size_t flags, json_error_t *error)

   .. refcounting:: new

   解码长度为 *buflen* 的 JSON 字符串 *buffer* 并返回它包含的数组或对象，
   如果出错则返回 *NULL*，此时 *error* 会填充错误信息。这与 :func:`json_loads()` 类似，
   不同之处在于字符串不需要以空字符结尾。*flags* 如上所述。

   .. versionadded:: 2.1

.. function:: json_t *json_loadf(FILE *input, size_t flags, json_error_t *error)

   .. refcounting:: new

   解码流 *input* 中的 JSON 文本并返回它包含的数组或对象，
   如果出错则返回 *NULL*，此时 *error* 会填充错误信息。*flags* 如上所述。

   此函数将从输入文件当前的任何位置开始读取，而不会先尝试定位。
   如果发生错误，文件位置将处于不确定状态。成功时，文件位置将在 EOF，
   除非使用了 ``JSON_DISABLE_EOF_CHECK`` 标志。在这种情况下，
   文件位置将在 JSON 输入中最后一个 ``]`` 或 ``}`` 之后的第一个字符处。
   这允许在同一个 ``FILE`` 对象上多次调用 :func:`json_loadf()`，
   如果输入由连续的 JSON 文本组成，可能由空白字符分隔。

.. function:: json_t *json_loadfd(int input, size_t flags, json_error_t *error)

   .. refcounting:: new

   Decodes the JSON text in stream *input* and returns the array or
   对象，如果出错则返回 *NULL*，此时 *error* 会填充错误信息。*flags* 如上所述。

   此函数将从输入文件描述符当前的任何位置开始读取，而不会先尝试定位。
   如果发生错误，文件位置将处于不确定状态。成功时，文件位置将在 EOF，
   除非使用了 ``JSON_DISABLE_EOF_CHECK`` 标志。在这种情况下，
   文件描述符的位置将在 JSON 输入中最后一个 ``]`` 或 ``}`` 之后的第一个字符处。
   这允许在同一个文件描述符上多次调用 :func:`json_loadfd()`，
   如果输入由连续的 JSON 文本组成，可能由空白字符分隔。

   重要的是要注意，此函数只能在流式文件描述符（如 SOCK_STREAM）上成功。
   在非流式文件描述符上使用此函数将导致未定义行为。
   对于非流式文件描述符，请改用 :func:`json_loadb()`。
   另外，请注意，此函数不能在非阻塞文件描述符（如非阻塞套接字）上使用。
   在非阻塞文件描述符上使用此函数有很高的数据丢失风险，因为它不支持恢复。

   此函数需要 POSIX 并且在所有非 POSIX 系统上失败。

   .. versionadded:: 2.10

.. function:: json_t *json_load_file(const char *path, size_t flags, json_error_t *error)

   .. refcounting:: new

   解码文件 *path* 中的 JSON 文本并返回它包含的数组或对象，
   如果出错则返回 *NULL*，此时 *error* 会填充错误信息。*flags* 如上所述。

.. type:: json_load_callback_t

   A typedef for a function that's called by
   :func:`json_load_callback()` to read a chunk of input data::

       typedef size_t (*json_load_callback_t)(void *buffer, size_t buflen, void *data);

   *buffer* points to a buffer of *buflen* bytes, and *data* is the
   corresponding :func:`json_load_callback()` argument passed through.

   成功时，函数应向 *buffer* 写入最多 *buflen* 字节，并返回写入的字节数；
   返回值为 0 表示未产生数据且已到达文件末尾。出错时，函数应返回
   ``(size_t)-1`` 以中止解码过程。

   在 UTF-8 中，某些代码点被编码为多字节序列。回调函数不需要担心这一点，
   因为 Jansson 在更高层次处理它。例如，您可以安全地从网络连接读取固定数量的字节，
   而不必关心被块边界分割的代码单元序列。

   .. versionadded:: 2.4

.. function:: json_t *json_load_callback(json_load_callback_t callback, void *data, size_t flags, json_error_t *error)

   .. refcounting:: new

   解码由重复调用 *callback* 产生的 JSON 文本，并返回它包含的数组或对象，
   如果出错则返回 *NULL*，此时 *error* 会填充错误信息。*data* 在每次调用时
   被传递给 *callback*。*flags* 如上所述。

   .. versionadded:: 2.4


.. _apiref-pack:

构建值
=======

本节介绍有助于创建或*打包*复杂 JSON 值的函数，特别是嵌套对象和数组。
值构建基于一个*格式字符串*，用于告诉函数有关预期参数的信息。

例如，格式字符串 ``"i"`` 指定单个整数值，而格式字符串 ``"[ssb]"`` 或等效的 ``"[s, s,
b]"`` specifies an array value with two strings and a boolean as its
items::

    /* Create the JSON integer 42 */
    json_pack("i", 42);

    /* 创建 JSON 数组 ["foo", "bar", true] */
    json_pack("[ssb]", "foo", "bar", 1);

以下是格式说明符的完整列表。括号中的类型表示生成的 JSON 类型，
方括号中的类型（如果有）表示对应的参数应有的 C 类型。

``s`` (string) [const char \*]
    将以空字符结尾的 UTF-8 字符串转换为 JSON 字符串。

``s?`` (string) [const char \*]
    与 ``s`` 类似，但如果参数为 *NULL*，则输出 JSON null 值。

    .. versionadded:: 2.8

``s*`` (string) [const char \*]
    与 ``s`` 类似，但如果参数为 *NULL*，则不输出任何值。
    此格式只能在对象或数组内部使用。如果在对象内部使用，当值被省略时，
    相应的键也会被抑制。见下文示例。

    .. versionadded:: 2.11

``s#`` (string) [const char \*, int]
    将给定长度的 UTF-8 缓冲区转换为 JSON 字符串。

    .. versionadded:: 2.5

``s%`` (string) [const char \*, size_t]
    与 ``s#`` 类似，但长度参数的类型为 :type:`size_t`。

    .. versionadded:: 2.6

``+`` [const char \*]
    与 ``s`` 类似，但会连接到前一个字符串。仅在 ``s``、``s#``、``+`` 或 ``+#`` 之后有效。

    .. versionadded:: 2.5

``+#`` [const char \*, int]
    与 ``s#`` 类似，但会连接到前一个字符串。仅在 ``s``、``s#``、``+`` 或 ``+#`` 之后有效。

    .. versionadded:: 2.5

``+%`` (string) [const char \*, size_t]
    与 ``+#`` 类似，但长度参数的类型为 :type:`size_t`。

    .. versionadded:: 2.6

``n`` (null)
    输出 JSON null 值。不消耗参数。

``b`` (boolean) [int]
    将 C ``int`` 转换为 JSON 布尔值。零转换为 ``false``，非零转换为 ``true``。

``i`` (integer) [int]
    将 C ``int`` 转换为 JSON 整数。

``I`` (integer) [json_int_t]
    将 C :type:`json_int_t` 转换为 JSON 整数。

``f`` (real) [double]
    将 C ``double`` 转换为 JSON 实数。

``o`` (any value) [json_t \*]
    按原样输出任何给定的 JSON 值。如果值被添加到数组或对象中，
    传递给 ``o`` 的值的引用将被容器窃取。

``O`` (any value) [json_t \*]
    与 ``o`` 类似，但参数的引用计数会增加。如果您打包到数组或对象中，
    并且希望保留对由 ``O`` 消耗的 JSON 值的引用，则这很有用。

``o?``, ``O?`` (any value) [json_t \*]
    分别与 ``o`` 和 ``O`` 类似，但如果参数为 *NULL*，则输出 JSON null 值。

    .. versionadded:: 2.8

``o*``, ``O*`` (any value) [json_t \*]
    分别与 ``o`` 和 ``O`` 类似，但如果参数为 *NULL*，则不输出任何值。
    此格式只能在对象或数组内部使用。如果在对象内部使用，相应的键也会被抑制。
    见下文示例。

    .. versionadded:: 2.11

``[fmt]`` (array)
    使用内部格式字符串构建数组。``fmt`` 可能包含对象和数组，
    即支持递归值构建。

``{fmt}`` (object)
    使用内部格式字符串 ``fmt`` 构建对象。第一个、第三个等格式说明符表示键，
    必须是字符串（见上文的 ``s``、``s#``、``+`` 和 ``+#``），因为对象键始终是字符串。
    第二个、第四个等格式说明符表示值。任何值都可以是对象或数组，即支持递归值构建。

空白字符、``:`` 和 ``,`` 被忽略。

.. function:: json_t *json_pack(const char *fmt, ...)

   .. refcounting:: new

   根据格式字符串 *fmt* 构建新的 JSON 值。对于每个格式说明符（除了 ``{}[]n``），
   会消耗一个或多个参数并用于构建相应的值。出错时返回 *NULL*。

.. function:: json_t *json_pack_ex(json_error_t *error, size_t flags, const char *fmt, ...)
              json_t *json_vpack_ex(json_error_t *error, size_t flags, const char *fmt, va_list ap)

   .. refcounting:: new

   与 :func:`json_pack()` 类似，但在出错的情况下，如果 *error* 不为 *NULL*，
   则会将错误消息写入 *error*。*flags* 参数当前未使用，应设置为 0。

   由于打包器只能捕获格式字符串中的错误（和内存不足错误），
   这两个函数最可能仅用于调试格式字符串。

更多示例::

  /* 构建空 JSON 对象 */
  json_pack("{}");

  /* 构建 JSON 对象 {"foo": 42, "bar": 7} */
  json_pack("{sisi}", "foo", 42, "bar", 7);

  /* 与上面类似，':'、',' 和空白字符被忽略 */
  json_pack("{s:i, s:i}", "foo", 42, "bar", 7);

  /* 构建 JSON 数组 [[1, 2], {"cool": true}] */
  json_pack("[[i,i],{s:b}]", 1, 2, "cool", 1);

  /* 从未以空字符结尾的缓冲区构建字符串 */
  char buffer[4] = {'t', 'e', 's', 't'};
  json_pack("s#", buffer, 4);

  /* 连接字符串以构建 JSON 字符串 "foobarbaz" */
  json_pack("s++", "foo", "bar", "baz");

  /* 当可选成员缺失时创建空对象或数组 */
  json_pack("{s:s*,s:o*,s:O*}", "foo", NULL, "bar", NULL, "baz", NULL);
  json_pack("[s*,o*,O*]", NULL, NULL, NULL);


.. _apiref-unpack:

解析和验证值
=============

本节介绍有助于验证复杂值
并从中提取（或*解包*）数据的函数。与 :ref:`构建值 <apiref-pack>` 类似，
这也是基于格式字符串的。

在解包 JSON 值时，会检查格式字符串中指定的类型是否与 JSON 值的类型匹配。
这是验证过程的一部分。此外，解包函数还可以检查数组和对象的所有项目是否都被解包。
此检查可以通过格式说明符 ``!`` 或使用标志 ``JSON_STRICT`` 启用。详见下文。

以下是完整的格式说明符列表。括号中的类型表示 JSON 类型，
方括号中的类型（如果有）表示应传递其地址的 C 类型。

``s`` (string) [const char *]
    将 JSON 字符串转换为指向以空字符结尾的 UTF-8 字符串的指针。
    生成的字符串是通过内部使用 :func:`json_string_value()` 提取的，
    因此只要对相应的 JSON 字符串还有引用，它就存在。

``s%`` (string) [const char *, size_t *]
    将 JSON 字符串转换为指向以空字符结尾的 UTF-8 字符串的指针及其长度。

    .. versionadded:: 2.6

``n`` (null)
    期望一个 JSON null 值。不提取任何内容。

``b`` (boolean) [int]
    将 JSON 布尔值转换为 C ``int``，其中 ``true`` 转换为 1，``false`` 转换为 0。

``i`` (integer) [int]
    将 JSON 整数转换为 C ``int``。

``I`` (integer) [json_int_t]
    Convert a JSON integer to C :type:`json_int_t`.

``f`` (real) [double]
    将 JSON 实数转换为 C ``double``。

``F`` (integer or real) [double]
    将 JSON 数字（整数或实数）转换为 C ``double``。

``o`` (any value) [json_t *]
    不进行任何转换，将 JSON 值存储到 :type:`json_t` 指针中。

``O`` (any value) [json_t *]
    与 ``o`` 类似，但会增加 JSON 值的引用计数。
    在使用解包之前，存储指针应初始化为 NULL。
    调用者负责释放解包增加的所有引用，即使在发生错误的情况下也是如此。

``[fmt]`` (array)
    根据内部格式字符串转换 JSON 数组中的每个项目。
    ``fmt`` 可以包含对象和数组，即支持递归值提取。

``{fmt}`` (object)
    根据内部格式字符串 ``fmt`` 转换 JSON 对象中的每个项目。
    第一个、第三个等格式说明符表示键，必须为 ``s``。
    解包函数的相应参数被读取为对象键。
    第二个、第四个等格式说明符表示值，并写入到作为相应参数给出的地址。
    **注意**，每隔一个参数是从中读取，每隔一个参数是写入到其中。

    ``fmt`` 可以包含对象和数组作为值，即支持递归值提取。

    .. versionadded:: 2.3
       任何表示键的 ``s`` 都可以后缀 ``?`` 以使该键变为可选。
       如果找不到该键，则不提取任何内容。详见下文示例。

``!``
    此特殊格式说明符用于启用检查，确保每个值的所有对象和数组项都被访问。它
    must appear inside an array or object as the last format specifier
    必须出现在数组或对象内部，作为右括号或花括号之前的最后一个格式说明符。
    要全局启用此检查，请使用 ``JSON_STRICT`` 解包标志。

``*``
    此特殊格式说明符与 ``!`` 相反。如果使用了 ``JSON_STRICT`` 标志，
    ``*`` 可以用于在每个值的基础上禁用严格检查。
    它必须出现在数组或对象内部，作为右括号或花括号之前的最后一个格式说明符。

空白字符、``:`` 和 ``,`` 被忽略。

.. function:: int json_unpack(json_t *root, const char *fmt, ...)

   根据格式字符串 *fmt* 验证并解包 JSON 值 *root*。成功时返回 0，失败时返回 -1。

.. function:: int json_unpack_ex(json_t *root, json_error_t *error, size_t flags, const char *fmt, ...)
              int json_vunpack_ex(json_t *root, json_error_t *error, size_t flags, const char *fmt, va_list ap)

   根据格式字符串 *fmt* 验证并解包 JSON 值 *root*。如果发生错误且 *error* 不为 *NULL*，
   则将错误信息写入 *error*。*flags* 可用于控制解包器的行为，详见下文标志说明。
   成功时返回 0，失败时返回 -1。

.. note::

   所有解包函数的第一个参数是 ``json_t *root`` 而不是 ``const json_t *root``，
   因为使用 ``O`` 格式说明符会导致 ``root`` 或从 ``root`` 可达的某个值的引用计数增加。
   此外，``o`` 格式说明符可用于按原样提取值，这允许修改从 ``root`` 可达的值的结构或内容。

   如果不使用 ``O`` 和 ``o`` 格式说明符，在这些函数中使用时，
   将 ``const json_t *`` 变量转换为普通的 ``json_t *`` 是完全安全的。

以下是可用的解包标志：

``JSON_STRICT``
    Enable the extra validation step checking that all object and
    array items are unpacked. This is equivalent to appending the
    格式说明符 ``!`` 添加到格式字符串中的每个数组和对象的末尾。

``JSON_VALIDATE_ONLY``
    不提取任何数据，仅根据给定的格式字符串验证 JSON 值。
    注意，对象键仍然必须在格式字符串后指定。

示例::

    /* root 是 JSON 整数 42 */
    int myint;
    json_unpack(root, "i", &myint);
    assert(myint == 42);

    /* root 是 JSON 对象 {"foo": "bar", "quux": true} */
    const char *str;
    int boolean;
    json_unpack(root, "{s:s, s:b}", "foo", &str, "quux", &boolean);
    assert(strcmp(str, "bar") == 0 && boolean == 1);

    /* root 是 JSON 数组 [[1, 2], {"baz": null} */
    json_error_t error;
    json_unpack_ex(root, &error, JSON_VALIDATE_ONLY, "[[i,i], {s:n}]", "baz");
    /* 验证成功返回 0，不提取任何内容 */

    /* root 是 JSON 数组 [1, 2, 3, 4, 5] */
    int myint1, myint2;
    json_unpack(root, "[ii!]", &myint1, &myint2);
    /* 验证失败返回 -1 */

    /* root 是一个空的 JSON 对象 */
    int myint = 0, myint2 = 0, myint3 = 0;
    json_unpack(root, "{s?i, s?[ii]}",
                "foo", &myint1,
                "bar", &myint2, &myint3);
    /* 由于 "foo" 和 "bar" 不存在，myint1、myint2 或 myint3 不会被修改 */


相等性
=======

通常情况下，不能使用 ``==`` 运算符来测试两个 JSON 值的相等性。
``==`` 运算符的相等性意味着两个 :type:`json_t` 指针指向完全相同的 JSON 值。
然而，两个 JSON 值不仅在它们是完全相同的值时可以相等，而且在它们具有相等的"内容"时也可以相等：

* 两个整数或实数值相等，如果它们包含的数值相等。但是，整数值永远不会等于实数值。

* 两个字符串相等，如果它们包含的 UTF-8 字符串字节相同。未实现 Unicode 比较算法。

* 两个数组相等，如果它们具有相同数量的元素，并且第一个数组中的每个元素都等于第二个数组中的相应元素。

* 两个对象相等，如果它们具有完全相同的键，并且第一个对象中每个键的值都等于第二个对象中相应键的值。

* 两个 true、false 或 null 值没有"内容"，因此如果它们的类型相等，则它们相等。
  （因为这些值是单例，所以它们的相等性实际上可以用 ``==`` 测试。）

.. function:: int json_equal(json_t *value1, json_t *value2)

   如果 *value1* 和 *value2* 如上所定义的相等，则返回 1。
   如果它们不相等或其中一个或两个指针为 *NULL*，则返回 0。


复制
======

Because of reference counting, passing JSON values around doesn't
需要复制它们。但有时需要 JSON 值的全新副本。例如，如果您需要修改数组，
但之后仍然想使用原始数组，则应该先对其进行复制。

Jansson 支持两种复制方式：浅拷贝和深拷贝。这些方法的区别仅适用于数组和对象。
浅拷贝只复制第一级值（数组或对象），并在复制的值中使用相同的子值。
深拷贝也会为子值创建一个全新的副本。此外，所有子值都以递归方式进行深拷贝。

复制对象会保留键的插入顺序。

.. function:: json_t *json_copy(json_t *value)

   .. refcounting:: new

   返回 *value* 的浅拷贝，如果出错则返回 *NULL*。

.. function:: json_t *json_deep_copy(const json_t *value)

   .. refcounting:: new

   返回 *value* 的深拷贝，如果出错则返回 *NULL*。


.. _apiref-custom-memory-allocation:

自定义内存分配
==============

默认情况下，Jansson 使用 :func:`malloc()` 和 :func:`free()` 进行内存分配。
如果需要自定义行为，可以覆盖这些函数。

.. type:: json_malloc_t

   一个具有 :func:`malloc()` 签名的函数指针类型定义::

       typedef void *(*json_malloc_t)(size_t);

.. type:: json_free_t

   一个具有 :func:`free()` 签名的函数指针类型定义::

       typedef void (*json_free_t)(void *);

.. function:: void json_set_alloc_funcs(json_malloc_t malloc_fn, json_free_t free_fn)

   使用 *malloc_fn* 代替 :func:`malloc()`，使用 *free_fn* 代替 :func:`free()`。
   此函数必须在任何其他 Jansson 的 API 函数之前调用，以确保所有内存操作都使用相同的函数。

.. function:: void json_get_alloc_funcs(json_malloc_t *malloc_fn, json_free_t *free_fn)

   获取当前使用的 malloc_fn 和 free_fn。任一参数都可以是 NULL。

   .. versionadded:: 2.8

**示例：**

通过使用应用程序的 :func:`malloc()` 和 :func:`free()` 来避免 Windows 上不同 CRT 堆的问题::

    json_set_alloc_funcs(malloc, free);

使用 `Boehm's 保守垃圾收集器`_ 进行内存操作::

    json_set_alloc_funcs(GC_malloc, GC_free);

.. _Boehm's 保守垃圾收集器: http://www.hboehm.info/gc/

通过在释放时清零所有内存来允许在 JSON 结构中存储敏感数据（例如密码或加密密钥）::

    static void *secure_malloc(size_t size)
    {
        /* Store the memory area size in the beginning of the block */
        void *ptr = malloc(size + 8);
        *((size_t *)ptr) = size;
        return ptr + 8;
    }

    static void secure_free(void *ptr)
    {
        size_t size;

        ptr -= 8;
        size = *((size_t *)ptr);

        guaranteed_memset(ptr, 0, size + 8);
        free(ptr);
    }

    int main()
    {
        json_set_alloc_funcs(secure_malloc, secure_free);
        /* ... */
    }

关于在内存中存储敏感数据的问题的更多信息，请参阅
http://www.dwheeler.com/secure-programs/Secure-Programs-HOWTO/protect-secrets.html。
该页面还解释了示例中使用的 :func:`guaranteed_memset()` 函数，并提供了其示例实现。

.. _fixed_length_keys:

固定长度键
==========

Jansson API 允许使用固定长度的键。这在以下情况下很有用：

* 键包含在缓冲区中且不以空字符结尾。在这种情况下，不需要创建新的临时缓冲区。
* 键内部包含 U+0000（空字符）。

固定长度键的 API 列表：

* :c:func:`json_object_getn`
* :c:func:`json_object_setn`
* :c:func:`json_object_setn_nocheck`
* :c:func:`json_object_setn_new`
* :c:func:`json_object_setn_new_nocheck`
* :c:func:`json_object_deln`
* :c:func:`json_object_iter_key_len`
* :c:func:`json_object_keylen_foreach`
* :c:func:`json_object_keylen_foreach_safe`

**示例：**

尝试编写一个新函数，通过用 ``.`` 分隔的路径获取 :c:struct:`json_t`

这需要：

* 字符串迭代器（无需修改输入以获得更好的性能）
* 用于处理固定大小键的 API

迭代器::

    struct string {
        const char *string;
        size_t length;
    };

    size_t string_try_next(struct string *str, const char *delimiter) {
        str->string += strspn(str->string, delimiter);
        str->length = strcspn(str->string, delimiter);
        return str->length;
    }

    #define string_foreach(_string, _delimiter) \
            for (; string_try_next(&(_string), _delimiter); (_string).string += (_string).length)


函数::

    json_t *json_object_get_by_path(json_t *object, const char *path) {
        struct string str;
        json_t *out = object;

        str.string = path;

        string_foreach(str, ".") {
            out = json_object_getn(out, str.string, str.length);
            if (out == NULL)
                return NULL;
        }

        return out;
    }

使用示例::

    int main(void) {
        json_t *obj = json_pack("{s:{s:{s:b}}}", "a", "b", "c", 1);

        json_t *c = json_object_get_by_path(obj, "a.b.c");
        assert(json_is_true(c));

        json_decref(obj);
    }
