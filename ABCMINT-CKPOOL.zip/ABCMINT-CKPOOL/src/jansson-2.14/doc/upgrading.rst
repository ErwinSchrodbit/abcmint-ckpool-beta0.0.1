.. highlight:: c

******************
从1.x版本升级
******************

本章列出了Jansson 2.0版本中引入的不向后兼容的变更，以及升级代码所需的步骤。

**这些不兼容性变更并不显著。** 最大的变化是所有解码函数现在都需要一个额外的参数。大多数程序只需要在所有调用:func:`json_loads()`、:func:`json_loadf()`和:func:`json_load_file()`的地方添加``0``作为第二个参数，就可以修改为与2.0版本兼容。


兼容性
=============

Jansson 2.0与Jansson 1.x版本不向后兼容。它在ABI层面不兼容，即所有动态链接到Jansson库的程序都需要重新编译。它在API层面也不兼容，即使用Jansson 1.x的程序源代码可能需要修改才能编译通过Jansson 2.0。

所有2.x系列版本保证在ABI和API层面都向后兼容，因此从2.x升级到2.y时不需要重新编译或修改源代码。


不兼容变更列表
============================

**解码标志**
    为了未来的需要，所有解码函数（即:func:`json_loads()`、:func:`json_loadf()`和:func:`json_load_file()`）都添加了一个``flags``参数作为第二个参数。需要修改所有对这些函数的调用，添加``0``作为第二个参数。例如::

        /* 旧代码 */
        json_loads(input, &error);

        /* 新代码 */
        json_loads(input, 0, &error);


**JSON整数的底层类型**
    JSON整数的底层C类型已从``int``更改为可用的最宽有符号整数类型，即根据系统是否支持``long long``，使用``long long``或``long``。这使大多数现代系统能够使用完整的64位整数范围。

    ``jansson.h``中定义了一个typedef :type:`json_int_t`来表示底层整数类型。在处理较小的JSON整数时，大多数情况下仍然应该使用``int``，因为编译器会处理隐式类型转换。只有在需要完整的64位范围时，才应该显式使用:type:`json_int_t`。


**最大编码器缩进深度**
    ``JSON_INDENT()``宏的最大参数值已从255更改为31，以释放:func:`json_dumps()`、:func:`json_dumpf()`和:func:`json_dump_file()`函数的``flags``参数中的位数。如果您的代码使用的缩进大于31，需要进行修改。


**API函数中的无符号整数**
    2.0版本统一了API中的无符号整数使用。所有使用``unsigned int``和``unsigned long``的地方都已替换为``size_t``。这包括标志、容器大小等。这应该不需要修改源代码，因为``unsigned int``和``unsigned long``通常与``size_t``兼容。
