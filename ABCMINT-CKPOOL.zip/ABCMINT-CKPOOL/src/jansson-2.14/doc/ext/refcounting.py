"""
    refcounting
    ~~~~~~~~~~~

    C API函数的引用计数注释。具有与sphinx.ext.refcounting扩展相同的结果,
    但适用于所有函数，无论其签名如何，并且引用计数信息与文档内联编写，
    而不是在单独的文件中。
    并且添加了一个新指令"refcounting"。该指令没有内容，需要一个必需的位置参数：
    "new"或"borrow"。

    示例：

    .. cfunction:: json_t *json_object(void)

       .. refcounting:: new

       <json_object函数的描述>

    :copyright: 版权所有 (c) 2009-2016 Petri Lehtinen <petri@digip.org>
    :license: MIT,详见LICENSE。
"""

from docutils import nodes
from docutils.parsers.rst import Directive

# 访问函数：处理非HTML格式的节点访问
def visit(self, node):
    self.visit_emphasis(node)

# 离开函数：处理非HTML格式的节点离开
def depart(self, node):
    self.depart_emphasis(node)

# HTML访问函数：为HTML输出添加引用计数标签
def html_visit(self, node):
    self.body.append(self.starttag(node, 'em', '', CLASS='refcount'))

# HTML离开函数：为HTML输出添加结束标签
def html_depart(self, node):
    self.body.append('</em>')

# 自定义引用计数节点类，继承自强调节点
class refcounting(nodes.emphasis):
    pass

# 引用计数指令类，处理refcounting指令的解析和执行
class refcounting_directive(Directive):
    has_content = False  # 指令不包含内容
    required_arguments = 1  # 需要一个必需参数
    optional_arguments = 0  # 没有可选参数
    final_argument_whitespace = False  # 参数中不允许空白

    def run(self):
        # 根据参数值生成相应的引用计数文本
        if self.arguments[0] == 'borrow':
            text = '返回值：借用的引用。'
        elif self.arguments[0] == 'new':
            text = '返回值：新引用。'
        else:
            raise Error('有效参数:new, borrow')

        # 返回新创建的引用计数节点
        return [refcounting(text, text)]

# Sphinx扩展设置函数
def setup(app):
    # 注册自定义节点及其访问器
    app.add_node(refcounting,
                 html=(html_visit, html_depart),
                 latex=(visit, depart),
                 text=(visit, depart),
                 man=(visit, depart))
    # 注册自定义指令
    app.add_directive('refcounting', refcounting_directive)
