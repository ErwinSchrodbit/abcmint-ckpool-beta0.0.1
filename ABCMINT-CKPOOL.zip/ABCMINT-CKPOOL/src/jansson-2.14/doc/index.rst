Jansson 文档
============

这是 Jansson_ |release| 的文档，最后更新于 |today|。

简介
----

Jansson_ 是一个用于编码、解码和操作 JSON 数据的 C 库。其主要特性和设计原则包括：

- 简单直观的 API 和数据模型

- 全面的文档

- 不依赖其他库

- 完整的 Unicode 支持（UTF-8）

- 广泛的测试套件

Jansson 采用 `MIT 许可证`_ 授权；详情请参见源代码分发包中的 LICENSE 文件。

Jansson 已在生产环境中使用，其 API 保持稳定。它适用于多种平台，包括各种类 Unix 系统和 Windows。它适合在任何系统上使用，包括桌面、服务器和小型嵌入式系统。


.. _`MIT 许可证`: http://www.opensource.org/licenses/mit-license.php
.. _Jansson: http://www.digip.org/jansson/

目录
----

.. toctree::
   :maxdepth: 2

   gettingstarted
   upgrading
   tutorial
   conformance
   threadsafety
   apiref
   changes


索引和表格
==========

* :ref:`genindex`
* :ref:`search`
