.. _tutorial:

********
教程
********

.. highlight:: c

在本教程中，我们将创建一个程序，通过网络获取GitHub_上某个仓库的最新提交记录。`GitHub API`_ 使用JSON格式返回数据，因此我们可以使用Jansson来解析这些数据。

为了保持教程的范围明确，我们将只介绍与处理JSON数据相关的程序部分。为了获得最佳的学习体验，完整的源代码可以在这里下载：:download:`github_commits.c`。要编译此程序（在Unix类系统上使用gcc），请使用以下命令::

    gcc -o github_commits github_commits.c -ljansson -lcurl

我们使用libcurl_进行网络通信，因此编译程序时需要安装它。

命令行语法如下::

    github_commits 用户 仓库

``用户`` 是GitHub用户ID，``仓库`` 是仓库名称。请注意，GitHub API有访问频率限制，如果在短时间内运行程序太多次，服务器会开始返回错误。

.. _GitHub: https://github.com/
.. _GitHub API: http://developer.github.com/
.. _libcurl: http://curl.haxx.se/


.. _tutorial-github-commits-api:

GitHub仓库提交API
===========================

`GitHub仓库提交API`_ 的使用方式是向类似 ``https://api.github.com/repos/用户/仓库/commits`` 的URL发送HTTP请求，其中 ``用户`` 和 ``仓库`` 分别是GitHub用户ID和要列出提交记录的仓库名称。

GitHub返回的JSON数组格式如下：

.. code-block:: none

    [
        {
            "sha": "<提交ID>",
            "commit": {
                "message": "<提交消息>",
                <更多字段，本教程不需要...>
            },
            <更多字段...>
        },
        {
            "sha": "<提交ID>",
            "commit": {
                "message": "<提交消息>",
                <更多字段...>
            },
            <更多字段...>
        },
        <更多提交...>
    ]

在我们的程序中，HTTP请求通过以下函数发送::

    static char *request(const char *url);

该函数接受URL作为参数，执行HTTP GET请求，并返回一个新分配的字符串，其中包含响应体。如果请求失败，将向stderr输出错误消息，并返回 *NULL*。有关完整详情，请参考:download:`源代码 <github_commits.c>`，因为实际实现在此处并不重要。

.. _GitHub Repo Commits API: http://developer.github.com/v3/repos/commits/

.. _tutorial-the-program:

程序实现
===========

首先是头文件包含::

    #include <string.h>
    #include <jansson.h>

像所有使用Jansson的程序一样，我们需要包含:file:`jansson.h`。

以下定义用于构建GitHub API请求URL::

   #define URL_FORMAT   "https://api.github.com/repos/%s/%s/commits"
   #define URL_SIZE     256

以下函数用于格式化结果时查找提交消息中的第一个换行符::

    /* 返回文本中第一个换行符的偏移量，如果没有换行符则返回文本长度 */
    static int newline_offset(const char *text)
    {
        const char *newline = strchr(text, '\n');
        if(!newline)
            return strlen(text);
        else
            return (int)(newline - text);
    }

接下来是main函数。开始时，我们首先声明一些变量并检查命令行参数::

    int main(int argc, char *argv[])
    {
        size_t i;
        char *text;
        char url[URL_SIZE];

        json_t *root;
        json_error_t error;

        if(argc != 3)
        {
            fprintf(stderr, "usage: %s USER REPOSITORY\n\n", argv[0]);
            fprintf(stderr, "List commits at USER's REPOSITORY.\n\n");
            return 2;
        }

然后，我们使用作为命令行参数提供的用户名和仓库名构建请求URL::

    snprintf(url, URL_SIZE, URL_FORMAT, argv[1], argv[2]);

这使用了上面定义的 ``URL_SIZE`` 和 ``URL_FORMAT`` 常量。现在我们准备通过网络实际请求JSON数据::

    text = request(url);
    if(!text)
        return 1;

如果发生错误，我们的函数 ``request`` 会打印错误并返回 *NULL*，因此我们只需要从main函数返回1即可。

接下来，我们将调用 :func:`json_loads()` 来解码我们作为响应获得的JSON文本::

    root = json_loads(text, 0, &error);
    free(text);

    if(!root)
    {
        fprintf(stderr, "error: on line %d: %s\n", error.line, error.text);
        return 1;
    }

我们不再需要JSON文本，因此可以在解码后立即释放 ``text`` 变量。如果 :func:`json_loads()` 失败，它会返回 *NULL* 并将错误信息设置到作为第三个参数给出的 :type:`json_error_t` 结构中。在这种情况下，我们的程序会打印错误信息并从main函数返回1。

现在我们准备从解码后的JSON响应中提取数据。响应JSON的结构已在 :ref:`tutorial-github-commits-api` 部分中解释过。

我们检查返回的值是否确实是一个数组::

    if(!json_is_array(root))
    {
        fprintf(stderr, "error: root is not an array\n");
        json_decref(root);
        return 1;
    }

然后我们继续遍历数组中的所有提交::

    for(i = 0; i < json_array_size(root); i++)
    {
        json_t *data, *sha, *commit, *message;
        const char *message_text;

        data = json_array_get(root, i);
        if(!json_is_object(data))
        {
            fprintf(stderr, "error: commit data %d is not an object\n", i + 1);
            json_decref(root);
            return 1;
        }
    ...

函数 :func:`json_array_size()` 返回JSON数组的大小。首先，我们再次声明一些变量，然后使用 :func:`json_array_get()` 提取 ``root`` 数组的第i个元素。我们还检查结果值是否是一个JSON对象。

接下来，我们将从该对象中提取提交ID（一个十六进制SHA-1值）、中间提交信息对象和提交消息。我们还进行了适当的类型检查::

        sha = json_object_get(data, "sha");
        if(!json_is_string(sha))
        {
            fprintf(stderr, "error: commit %d: sha is not a string\n", i + 1);
            json_decref(root);
            return 1;
        }

        commit = json_object_get(data, "commit");
        if(!json_is_object(commit))
        {
            fprintf(stderr, "error: commit %d: commit is not an object\n", i + 1);
            json_decref(root);
            return 1;
        }

        message = json_object_get(commit, "message");
        if(!json_is_string(message))
        {
            fprintf(stderr, "error: commit %d: message is not a string\n", i + 1);
            json_decref(root);
            return 1;
        }
    ...

最后，我们将打印提交ID的前8个字符和提交消息的第一行。使用 :func:`json_string_value()` 从JSON字符串中提取C风格字符串::

        message_text = json_string_value(message);
        printf("%.8s %.*s\n",
               json_string_value(sha),
               newline_offset(message_text),
               message_text);
    }

在发送HTTP请求后，我们使用 :func:`json_loads()` 解码了JSON文本，记得吗？它返回它解码的JSON值的*新引用*。当我们使用完该值后，我们需要使用 :func:`json_decref()` 减少引用计数。这样Jansson可以释放资源::

    json_decref(root);
    return 0;

有关Jansson中引用计数的详细说明，请参见:ref:`apiref`中的:ref:`apiref-reference-count`。

程序已经准备就绪，让我们测试一下并查看Jansson仓库中的最新提交：

.. code-block:: shell

    $ ./github_commits akheron jansson
    1581f26a Merge branch '2.3'
    aabfd493 load: Change buffer_pos to be a size_t
    bd72efbd load: Avoid unexpected behaviour in macro expansion
    e8fd3e30 Document and tweak json_load_callback()
    873eddaf Merge pull request #60 from rogerz/contrib
    bd2c0c73 Ignore the binary test_load_callback
    17a51a4b Merge branch '2.3'
    09c39adc Add json_load_callback to the list of exported symbols
    cbb80baf Merge pull request #57 from rogerz/contrib
    040bd7b0 Add json_load_callback()
    2637faa4 Make test stripping locale independent
    <...>


总结
===========

在本教程中，我们实现了一个程序，该程序使用GitHub仓库提交API获取GitHub仓库的最新提交记录。Jansson被用于解码JSON响应并提取提交数据。

本教程仅涵盖了Jansson的一小部分功能。例如，我们根本没有创建或操作JSON值。请继续阅读:ref:`apiref`以探索Jansson的所有功能。
