***************
入门指南
***************

.. highlight:: c

编译和安装 Jansson
================================

Jansson 源码可在以下地址获取：
http://www.digip.org/jansson/releases/。

类 Unix 系统（包括 MinGW）
-----------------------------------

解压源码包并进入源码目录：

.. parsed-literal::

    bunzip2 -c jansson-|release|.tar.bz2 | tar xf -
    cd jansson-|release|

源码使用了 GNU Autotools（autoconf_、automake_、libtool_），因此
编译和安装非常简单：::

    ./configure
    make
    make check
    make install

要更改目标目录（默认为 ``/usr/local``），请使用
``./configure`` 的 ``--prefix=DIR`` 参数。请参阅 ``./configure
--help`` 以获取所有可能的配置选项列表。

``make check`` 命令运行 Jansson 附带的测试套件。此步骤并非绝对必要，但它可能会发现 Jansson 在您的平台上可能存在的问题。如果发现任何问题，请报告它们。

如果您从 Git 仓库（或任何其他源代码控制系统）获取源码，则没有 ``./configure`` 脚本，因为它不会保存在版本控制中。要创建该脚本，需要引导构建系统。有多种方法可以做到这一点，但最简单的方法是使用 ``autoreconf``：::

    autoreconf -fi

此命令创建 ``./configure`` 脚本，然后可以按照上述说明使用它。

.. _autoconf: http://www.gnu.org/software/autoconf/
.. _automake: http://www.gnu.org/software/automake/
.. _libtool: http://www.gnu.org/software/libtool/


.. _build-cmake:

CMake（各种平台，包括 Windows）
--------------------------------------------

Jansson 可以使用 CMake_ 构建。为外部构建创建一个构建目录，切换到该目录，然后运行 ``cmake``（或 ``ccmake``、
``cmake-gui`` 或类似工具）来配置项目。

请参阅下面的示例以获取更详细的信息。

.. note:: 在下面的示例中，``..`` 用作 ``cmake`` 的参数。
          这只是 jansson 项目根目录的路径。
          在示例中，假设您已经创建了一个子目录 ``build``
          并使用它。您可以使用任何您想要的路径。

.. _build-cmake-unix:

Unix（Make 文件）
^^^^^^^^^^^^^^^^^
在 Unix 上生成 make 文件：

.. parsed-literal::

    bunzip2 -c jansson-|release|.tar.bz2 | tar xf -
    cd jansson-|release|

    mkdir build
    cd build
    cmake .. # 或使用 ccmake .. 以获得图形界面。

.. note::

   如果您不想构建文档或未安装 ``Sphinx``，则应在 ``cmake`` 命令中添加 ``"-DJANSSON_BUILD_DOCS=OFF"``。


然后构建：::

    make
    make check
    make install

Windows（Visual Studio）
^^^^^^^^^^^^^^^^^^^^^^^
从命令行创建 Visual Studio 项目文件：

.. parsed-literal::

    <解压>
    cd jansson-|release|

    md build
    cd build
    cmake -G "Visual Studio 15 2017" ..

.. note::

   您应该替换生成器的名称（``-G`` 标志）以匹配
   您系统上安装的 Visual Studio 版本。目前，支持以下版本：

   - ``Visual Studio 9 2008``
   - ``Visual Studio 10 2010``
   - ``Visual Studio 11 2012``
   - ``Visual Studio 12 2013``
   - ``Visual Studio 14 2015``
   - ``Visual Studio 15 2017``
   - ``Visual Studio 16 2019``

   任何更高版本也应该可以工作。

现在，您的构建目录中将有一个 *Visual Studio 解决方案*。
要运行单元测试，请构建 ``RUN_TESTS`` 项目。

如果您更喜欢图形界面，可以将上面示例中的 ``cmake`` 行
替换为：::

    cmake-gui ..

要获取 CMake_ 的命令行帮助（包括可用生成器列表），
只需运行：::

    cmake

要列出项目可用的 CMake_ 设置（以及它们当前的设置），请运行：::

    cmake -LH ..

Windows（MinGW）
^^^^^^^^^^^^^^^
如果您更喜欢在 Windows 上使用 MinGW，请确保已安装 MinGW 并将 ``{MinGW}/bin`` 添加到 ``PATH`` 中，然后执行以下命令：

.. parsed-literal::

    <解压>
    cd jansson-|release|

    md build
    cd build
    cmake -G "MinGW Makefiles" ..
    mingw32-make


Mac OSX（Xcode）
^^^^^^^^^^^^^^^
如果您在 OSX 上更喜欢使用 Xcode 而不是 make 文件，
请执行以下操作。（使用与
:ref:`Unix <build-cmake-unix>` 相同的步骤）::

    ...
    cmake -G "Xcode" ..

额外的 CMake 设置
^^^^^^^^^^^^^^^^^^^^^^^^^

共享库
""""""""""
默认情况下，CMake_ 项目将生成用于构建静态库的构建文件。要构建共享版本，请使用：::

    ...
    cmake -DJANSSON_BUILD_SHARED_LIBS=1 ..

更改安装目录（与 autoconf --prefix 相同）
""""""""""""""""""""""""""""""""""""""""""""""""""
与 autoconf_ 项目一样，您可以更改 ``make install`` 的目标目录。
CMake_ 中相当于 autoconf 的 ``./configure --prefix`` 的命令是：::

    ...
    cmake -DCMAKE_INSTALL_PREFIX:PATH=/some/other/path ..
    make install

.. _CMake: http://www.cmake.org


Android
-------

Jansson 可以为 Android 平台构建。Android.mk 位于
源码根目录中。配置头文件位于源码分发版的
``android`` 目录中。


其他系统
-------------

在非类 Unix 系统上，您可能无法运行 ``./configure``
脚本。在这种情况下，请按照以下步骤操作。所有提到的文件都可以
在 ``src/`` 目录中找到。

1. 创建 ``jansson_config.h``（它包含一些特定于平台的
   参数，这些参数通常由 ``./configure``
   脚本填充）。编辑 ``jansson_config.h.in``，替换所有 ``@variable@``
   占位符，并将文件重命名为 ``jansson_config.h``。

2. 使 ``jansson.h`` 和 ``jansson_config.h`` 对编译器可用，
   以便在编译使用 Jansson 的程序时可以找到它们。

3. 将所有 ``.c`` 文件（在 ``src/`` 目录中）编译成一个
   库文件。使库对编译器可用，如步骤 2 所述。


构建文档
--------------------------

（本小节描述如何构建您当前正在阅读的 HTML 文档，因此可以安全地跳过。）

文档位于 ``doc/`` 子目录中。它使用 reStructuredText_ 编写，带有 Sphinx_ 注释。要生成 HTML
文档，请执行：::

   make html

然后将浏览器指向 ``doc/_build/html/index.html``。生成文档需要 Sphinx_ 1.0
或更高版本。

.. _reStructuredText: http://docutils.sourceforge.net/rst.html
.. _Sphinx: http://sphinx.pocoo.org/


编译使用 Jansson 的程序
===================================

Jansson 涉及一个 C 头文件：:file:`jansson.h`，因此只需在
每个使用 Jansson 的源文件开头添加以下行即可：

::

    #include <jansson.h>

还有一个需要链接的库：``libjansson``。编译和链接程序的方法如下：::

    cc -o prog prog.c -ljansson

从版本 1.2 开始，还支持 pkg-config_：

.. code-block:: shell

    cc -o prog prog.c `pkg-config --cflags --libs jansson`

.. _pkg-config: http://pkg-config.freedesktop.org/
