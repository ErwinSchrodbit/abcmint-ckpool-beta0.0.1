// 此文件记录了 Jansson 的变更信息
******************
Changes in Jansson
******************

.. include:: ../CHANGES