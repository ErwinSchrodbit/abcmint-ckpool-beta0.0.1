Jansson 中文说明文档
==================

.. image:: https://github.com/akheron/jansson/workflows/tests/badge.svg
  :target: https://github.com/akheron/jansson/actions

.. image:: https://ci.appveyor.com/api/projects/status/lmhkkc4q8cwc65ko
  :target: https://ci.appveyor.com/project/akheron/jansson

.. image:: https://coveralls.io/repos/akheron/jansson/badge.png?branch=master
  :target: https://coveralls.io/r/akheron/jansson?branch=master

Jansson_ 是一个用于编码、解码和操作JSON数据的C语言库。它的主要特性和设计原则是：

- 简单直观的API和数据模型
- `全面的文档`_
- 不依赖于其他库
- 完全支持Unicode（UTF-8）
- 广泛的测试套件

Jansson 采用 `MIT许可证`_ 授权；详情请参阅源代码分发中的LICENSE文件。


编译和安装
------------

您可以使用 `vcpkg <https://github.com/Microsoft/vcpkg/>`_ 依赖管理器下载和安装Jansson：

.. code-block:: bash

    git clone https://github.com/Microsoft/vcpkg.git
    cd vcpkg
    ./bootstrap-vcpkg.sh
    ./vcpkg integrate install
    vcpkg install jansson

Jansson在vcpkg中的端口由微软团队成员和社区贡献者保持更新。如果版本过时，请在vcpkg仓库上 `创建问题或拉取请求 <https://github.com/Microsoft/vcpkg/>`_。

如果您从主网站的"Releases"部分获取了 `源代码压缩包`_，只需使用标准的autotools命令：

::

   $ ./configure
   $ make
   $ make install

要运行测试套件，请执行：

::

   $ make check

如果源代码是从Git仓库检出的，则必须先生成./configure脚本。最简单的方法是使用autoreconf：

::

   $ autoreconf -i


文档
-----

文档可在 http://jansson.readthedocs.io/en/latest/ 获取。

文档源代码位于``doc/``子目录中。要生成HTML文档，请执行：

::

   $ make html

然后，将浏览器指向``doc/_build/html/index.html``。生成文档需要Sphinx_ 1.0或更高版本。


.. _Jansson: http://www.digip.org/jansson/
.. _`全面的文档`: http://jansson.readthedocs.io/en/latest/
.. _`MIT许可证`: http://www.opensource.org/licenses/mit-license.php
.. _`源代码压缩包`: http://www.digip.org/jansson#releases
.. _Sphinx: http://sphinx.pocoo.org/
