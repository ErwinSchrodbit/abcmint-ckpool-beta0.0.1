/*
 * 使用jansson库解析和打印JSON的简单示例。
 *
 * 使用方法:
 * $ examples/simple_parse
 * 输入一些JSON > [true, false, null, 1, 0.0, -0.0, "", {"name": "barney"}]
 * JSON数组，包含8个元素:
 *   JSON 真值
 *   JSON 假值
 *   JSON 空值
 *   JSON 整数: "1"
 *   JSON 实数: 0.000000
 *   JSON 实数: -0.000000
 *   JSON 字符串: ""
 *   JSON 对象，包含1对键值:
 *     JSON 键: "name"
 *     JSON 字符串: "barney"
 *
 * Copyright (c) 2014 Robert Poor <rdpoor@gmail.com>
 *
 * Jansson是免费软件；您可以按照MIT许可证的条款重新分发和修改它。详见LICENSE文件。
 */

#include <jansson.h>
#include <stdio.h>
#include <stdlib.h>

/* 前向声明 */
void print_json(json_t *root);
void print_json_aux(json_t *element, int indent);
void print_json_indent(int indent);
const char *json_plural(size_t count);
void print_json_object(json_t *element, int indent);
void print_json_array(json_t *element, int indent);
void print_json_string(json_t *element, int indent);
void print_json_integer(json_t *element, int indent);
void print_json_real(json_t *element, int indent);
void print_json_true(json_t *element, int indent);
void print_json_false(json_t *element, int indent);
void print_json_null(json_t *element, int indent);

/* 打印JSON数据的入口函数 */
void print_json(json_t *root) { print_json_aux(root, 0); }

/* 根据JSON元素类型递归打印JSON数据 */
void print_json_aux(json_t *element, int indent) {
    switch (json_typeof(element)) {
        case JSON_OBJECT:
            print_json_object(element, indent);
            break;
        case JSON_ARRAY:
            print_json_array(element, indent);
            break;
        case JSON_STRING:
            print_json_string(element, indent);
            break;
        case JSON_INTEGER:
            print_json_integer(element, indent);
            break;
        case JSON_REAL:
            print_json_real(element, indent);
            break;
        case JSON_TRUE:
            print_json_true(element, indent);
            break;
        case JSON_FALSE:
            print_json_false(element, indent);
            break;
        case JSON_NULL:
            print_json_null(element, indent);
            break;
        default:
            fprintf(stderr, "未识别的JSON类型 %d\n", json_typeof(element));
    }
}

/* 打印缩进空格 */
void print_json_indent(int indent) {
    int i;
    for (i = 0; i < indent; i++) {
        putchar(' ');
    }
}

/* 根据数量返回适当的复数形式后缀 */
const char *json_plural(size_t count) { return count == 1 ? "" : "s"; }

/* 打印JSON对象 */
void print_json_object(json_t *element, int indent) {
    size_t size;
    const char *key;
    json_t *value;

    print_json_indent(indent);
    size = json_object_size(element);

    printf("JSON 对象，包含%lld对键值:\n", (long long)size, json_plural(size));
    json_object_foreach(element, key, value) {
        print_json_indent(indent + 2);
        printf("JSON 键: \"%s\"\n", key);
        print_json_aux(value, indent + 2);
    }
}

/* 打印JSON数组 */
void print_json_array(json_t *element, int indent) {
    size_t i;
    size_t size = json_array_size(element);
    print_json_indent(indent);

    printf("JSON 数组，包含%lld个元素:\n", (long long)size, json_plural(size));
    for (i = 0; i < size; i++) {
        print_json_aux(json_array_get(element, i), indent + 2);
    }
}

/* 打印JSON字符串 */
void print_json_string(json_t *element, int indent) {
    print_json_indent(indent);
    printf("JSON 字符串: \"%s\"\n", json_string_value(element));
}

/* 打印JSON整数 */
void print_json_integer(json_t *element, int indent) {
    print_json_indent(indent);
    printf("JSON 整数: \"%" JSON_INTEGER_FORMAT "\"\n", json_integer_value(element));
}

/* 打印JSON实数 */
void print_json_real(json_t *element, int indent) {
    print_json_indent(indent);
    printf("JSON 实数: %f\n", json_real_value(element));
}

/* 打印JSON真值 */
void print_json_true(json_t *element, int indent) {
    (void)element; /* 未使用的参数，避免编译器警告 */
    print_json_indent(indent);
    printf("JSON 真值\n");
}

/* 打印JSON假值 */
void print_json_false(json_t *element, int indent) {
    (void)element; /* 未使用的参数，避免编译器警告 */
    print_json_indent(indent);
    printf("JSON 假值\n");
}

/* 打印JSON空值 */
void print_json_null(json_t *element, int indent) {
    (void)element; /* 未使用的参数，避免编译器警告 */
    print_json_indent(indent);
    printf("JSON 空值\n");
}

/*
 * 将文本解析为JSON对象。如果文本是有效的JSON，返回json_t结构体，
 * 否则打印错误信息并返回null。
 */
json_t *load_json(const char *text) {
    json_t *root;
    json_error_t error;

    root = json_loads(text, 0, &error);

    if (root) {
        return root;
    } else {
        fprintf(stderr, "第%d行JSON错误: %s\n", error.line, error.text);
        return (json_t *)0;
    }
}

/*
 * 打印提示并返回（通过引用）一个以null结尾的文本行。
 * 在文件结束或出错时返回NULL。
 */
char *read_line(char *line, int max_chars) {
    printf("输入一些JSON > ");
    fflush(stdout);
    return fgets(line, max_chars, stdin);
}

/* ================================================================
 * 主函数
 */

#define MAX_CHARS 4096

int main(int argc, char *argv[]) {
    char line[MAX_CHARS];

    if (argc != 1) {
        fprintf(stderr, "用法: %s\n", argv[0]);
        exit(-1);
    }

    while (read_line(line, MAX_CHARS) != (char *)NULL) {

        /* 将文本解析为JSON结构 */
        json_t *root = load_json(line);

        if (root) {
            /* 打印并释放JSON结构 */
            print_json(root);
            json_decref(root);
        }
    }

    return 0;
}
