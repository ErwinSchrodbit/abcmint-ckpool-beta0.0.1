/*
 * config.h - ABCMINT-CKPOOL 配置文件
 * 自动生成或手动创建的配置头文件
 */

#ifndef CONFIG_H
#define CONFIG_H

/* 系统相关定义 */
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_SOCKET_H 1
#define HAVE_UNISTD_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_MATH_H 1
#define HAVE_PTHREAD_H 1
#define HAVE_SYS_TIME_H 1
#define HAVE_SYSLOG_H 1
#define HAVE_NETINET_IN_H 1
#define HAVE_ARPA_INET_H 1

/* 数学函数定义 */
#define HAVE_FLOOR 1
#define HAVE_SQRT 1
#define HAVE_LOG 1
#define HAVE_LOG2 1
#define HAVE_FABS 1

/* 系统特性检测 */
#define TIME_WITH_SYS_TIME 1

/* 线程支持 */
#define HAVE_PTHREAD 1

/* rainbow18支持 - 默认使用内置实现 */
#ifndef HAVE_RAINBOW
#define HAVE_RAINBOW 0
#endif

/* ZMQ支持 - 默认禁用 */
#ifndef HAVE_ZMQ_H
#define HAVE_ZMQ_H 0
#endif

/* 处理器特性检测 */
#ifndef USE_AVX2
#define USE_AVX2 0
#endif

#ifndef USE_AVX1
#define USE_AVX1 0
#endif

#ifndef USE_SSE4
#define USE_SSE4 0
#endif

#ifndef USE_ARM_SHA2
#define USE_ARM_SHA2 0
#endif

/* 版本信息 */
#define PACKAGE "ckpool"
#define VERSION "0.9.9"

/* 调试标志 */
#ifdef DEBUG
#define DEBUG_LOG 1
#else
#define DEBUG_LOG 0
#endif

/* 解决方案回调类型定义 - 修复编译错误 */
typedef int (*solution_callback_t)(void*, uint64_t, uint64_t*);

#endif /* CONFIG_H */