/*
 * rainbow18_compat.h - ABCMINT CKPool彩虹签名算法兼容性头文件
 * 提供统一的rainbow18算法接口，无论是否有外部库支持
 */

#ifndef RAINBOW18_COMPAT_H
#define RAINBOW18_COMPAT_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

/* 确保stdio.h可用 */
#include <stdio.h>

/* 如果abcmint_compat.h存在，包含它；否则定义自己的常量 */
#ifdef HAVE_ABCMINT_COMPAT
#include "abcmint_compat.h" // 包含ABCMINT相关常量定义
#else
/* 定义RAINBOW18常量 */
#define RAINBOW18_SIGNATURE_SIZE 24     // 彩虹签名大小
#define RAINBOW18_PUBLIC_KEY_SIZE 1664  // 彩虹公钥大小
#define RAINBOW18_HASH_SIZE 32          // 哈希大小(SHA-256)
#endif

// 错误码定义
#define RAINBOW_ERR_NONE       0
#define RAINBOW_ERR_PARAM      -1
#define RAINBOW_ERR_MEMORY     -2
#define RAINBOW_ERR_VERIFY     -3
#define RAINBOW_ERR_TIMEOUT    -4

// Rainbow安全级别定义
#define RAINBOW_LEVEL_1 1  // 基础安全级别
#define RAINBOW_LEVEL_2 2  // 中等安全级别
#define RAINBOW_LEVEL_3 3  // 高级安全级别

// Rainbow难度因子定义
#define RAINBOW_FACTOR_LEVEL_1 1.0  // 基础级别难度因子
#define RAINBOW_FACTOR_LEVEL_2 2.5  // 中等级别难度因子
#define RAINBOW_FACTOR_LEVEL_3 5.0  // 高级别难度因子

// 难度调整相关常量
#define RAINBOW_MIN_FACTOR 1.0           // 最小难度因子
#define RAINBOW_MAX_FACTOR 10.0          // 最大难度因子
#define RAINBOW_HEIGHT_ADJUSTMENT_RATE 0.1  // 高度调整率

/* 检查是否有外部rainbow18库支持 */
#ifdef HAVE_RAINBOW
/* 如果找到rainbow18库，包含其头文件 */
#include <rainbow18/RAINBOW_PRO_APIs.h>
#else
/* 自定义rainbow18兼容函数声明 */

/**
 * 验证彩虹签名
 * @param digest 消息摘要（32字节SHA-256哈希）
 * @param signature 彩虹签名
 * @param pk 公钥
 * @return 成功返回0，失败返回-1
 */
int rainbow_verify(const uint8_t *digest, const uint8_t *signature, const uint8_t *pk);

/**
 * 计算彩虹公钥映射
 * @param out 输出结果
 * @param pk 公钥
 * @param signature 签名
 */
void rainbow_pubmap(uint8_t *out, const uint8_t *pk, const uint8_t *signature);

#endif /* HAVE_RAINBOW */

// 配置函数声明
void rainbow18_set_config(int enabled, int security_level, int verify_timeout, int max_retries);

/**
 * 为ABCMINT设计的统一彩虹签名验证函数
 * @param message 原始消息
 * @param message_len 消息长度
 * @param signature 签名数据
 * @param signature_len 签名长度
 * @param public_key 公钥数据
 * @param public_key_len 公钥长度
 * @return 验证成功返回true，否则返回false
 */
bool abcmint_rainbow_verify(
    const uint8_t *message,
    size_t message_len,
    const uint8_t *signature,
    size_t signature_len,
    const uint8_t *public_key,
    size_t public_key_len
);

// 从abcmint_compat.h中引入这两个函数的声明，避免重复定义
// 为确保实现一致性，不在此文件中定义内联版本

#endif /* RAINBOW18_COMPAT_H */