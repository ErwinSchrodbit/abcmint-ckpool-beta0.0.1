/*
 * 版权所有 2014-2016 Con Kolivas
 *
 * 本程序是自由软件；您可以根据自由软件基金会发布的GNU通用公共许可证
 * 第3版（或任何更高版本）的条款重新分发和修改它。详情请参阅COPYING文件。
 */

#ifndef CONNECTOR_H
#define CONNECTOR_H

/**
 * 为新客户端生成一个唯一的客户端ID
 * @param ckp ckpool主结构体指针
 * @return 返回新生成的客户端ID
 */
int64_t connector_newclientid(ckpool_t *ckp);

/**
 * 向上游发送消息
 * @param ckp ckpool主结构体指针
 * @param msg 要发送的消息字符串
 */
void connector_upstream_msg(ckpool_t *ckp, char *msg);

/**
 * 向连接器添加JSON格式消息
 * @param ckp ckpool主结构体指针
 * @param val 要添加的JSON值
 */
void connector_add_message(ckpool_t *ckp, json_t *val);

/**
 * 生成连接器统计信息
 * @param data 数据指针
 * @param runtime 运行时间
 * @return 返回统计信息字符串
 */
char *connector_stats(void *data, const int runtime);

/**
 * 通过套接字发送文件描述符
 * @param ckp ckpool主结构体指针
 * @param fdno 文件描述符编号
 * @param sockd 套接字描述符
 */
void connector_send_fd(ckpool_t *ckp, const int fdno, const int sockd);

/**
 * 连接器主函数，管理连接和数据传输
 * @param arg 参数指针
 * @return 返回线程退出状态
 */
void *connector(void *arg);

#endif /* CONNECTOR_H */
