/*
 * 版权所有 2014-2017,2023 Con Kolivas
 *
 * 本程序是自由软件；您可以根据自由软件基金会发布的GNU通用公共许可证（第三版或更高版本）的条款重新分发和/或修改它。
 * 详情请参阅COPYING文件。
 */

#ifndef STRATIFIER_H
#define STRATIFIER_H

/* 通用结构体，同时用于stratifier中的workbase和generator中的gbtbase */
struct genwork {
	/* 哈希表数据 */
	UT_hash_handle hh;

	/* 以下两个字段需要连续，因为它们在remote_workbases中都用作哈希表条目的键 */
	int64_t id;
	/* 远程工作信息来源的客户端ID */
	int64_t client_id;

	char idstring[20];

	/* 当前对此工作基的读取者数量，在写workbase_lock下设置 */
	int readcount;

	/* 远程工作信息映射到本地的ID */
	int64_t mapped_id;

	ts_t gentime;
	tv_t retired;

	/* GBT/共享变量 */
	char target[68];
	double diff;
	double network_diff;
	uint32_t version;
	uint32_t curtime;
	char prevhash[68];
	char ntime[12];
	uint32_t ntime32;
	char bbversion[12];
	char nbit[12];
	uint64_t coinbasevalue;
	int height;
	char *flags;
	int txns;
	char *txn_data;
	char *txn_hashes;
	/* 移除隔离见证相关字段 */
	int merkles;
	char merklehash[16][68];
	char merklebin[16][32];
	json_t *merkle_array;

	/* 模板变量，长度均为二进制长度！ */
	char *coinb1; // coinbase1
	uchar *coinb1bin;
	int coinb1len; // 上述长度

	char enonce1const[32]; // 恒定的extranonce1部分
	uchar enonce1constbin[16];
	int enonce1constlen; // 上述长度 - 通常为零，除非在代理
	int enonce1varlen; // 每个矿工的唯一extranonce1字符串长度 - 通常为8

	int enonce2varlen; // 留给extranonce2的空间长度 - 通常为8，除非在代理

	char *coinb2; // coinbase2
	uchar *coinb2bin;
	int coinb2len; // 上述长度
	char *coinb3bin; // 用于可变coinb2len的coinbase3
	int coinb3len; // 上述长度

	/* 缓存的头部二进制数据 */
	char headerbin[112];

	char *logdir;

	ckpool_t *ckp;
	bool proxy; /* 此工作基是代理工作 */

	bool incomplete; /* 这是一个不包含所有交易数据的远程工作信息 */

	json_t *json; /* getblocktemplate JSON数据 */
};

void parse_remote_txns(ckpool_t *ckp, const json_t *val);
#define parse_upstream_txns(ckp, val) parse_remote_txns(ckp, val)
void parse_upstream_auth(ckpool_t *ckp, json_t *val);
void parse_upstream_workinfo(ckpool_t *ckp, json_t *val);
void parse_upstream_block(ckpool_t *ckp, json_t *val);
void parse_upstream_reqtxns(ckpool_t *ckp, json_t *val);
char *stratifier_stats(ckpool_t *ckp, void *data);
void _stratifier_add_recv(ckpool_t *ckp, json_t *val, const char *file, const char *func, const int line);
#define stratifier_add_recv(ckp, val) _stratifier_add_recv(ckp, val, __FILE__, __func__, __LINE__)
void *stratifier(void *arg);

#endif /* STRATIFIER_H */
