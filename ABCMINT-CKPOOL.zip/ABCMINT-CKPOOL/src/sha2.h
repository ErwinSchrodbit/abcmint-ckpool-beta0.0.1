/*
 * FIPS 180-2 SHA-224/256/384/512 实现
 * 最后更新: 2007年2月2日
 * 发布日期: 2005年4月30日
 *
 * 版权所有 (C) 2013-2014, Con Kolivas <kernel@kolivas.org>
 * 版权所有 (C) 2005, 2007 Olivier Gay <olivier.gay@a3.epfl.ch>
 * 保留所有权利。
 *
 * 源代码和二进制形式的重新分发和使用，无论是否修改，只要满足以下条件即可允许：
 * 1. 重新分发源代码必须保留上述版权声明、此条件列表和以下免责声明。
 * 2. 二进制形式的重新分发必须在分发提供的文档和/或其他材料中重现上述版权声明、此条件列表和以下免责声明。
 * 3. 未经特定事先书面许可，不得使用项目名称或其贡献者的名称来认可或推广源自本软件的产品。
 *
 * 本软件由项目及其贡献者按"原样"提供，不附带任何形式的明示或暗示的保证，包括但不限于对适销性和特定用途适用性的暗示保证。
 * 在任何情况下，项目或贡献者均不对任何直接、间接、偶然、特殊、惩戒性或后果性损害（包括但不限于替代商品或服务的采购；
 * 使用、数据或利润的损失；或业务中断）承担责任，无论损害是如何造成的，以及基于任何责任理论，无论是合同责任、严格责任还是侵权行为（包括疏忽或其他情况），
 * 即使已被告知此类损害的可能性。
 */

#include "config.h"

#ifndef SHA2_H
#define SHA2_H

/* SHA-256 摘要长度（字节） */
#define SHA256_DIGEST_SIZE ( 256 / 8)
/* SHA-256 块大小（字节） */
#define SHA256_BLOCK_SIZE  ( 512 / 8)

/* SHA-512 摘要长度（字节） */
#define SHA512_DIGEST_SIZE ( 512 / 8)
/* SHA-512 块大小（字节） */
#define SHA512_BLOCK_SIZE  ( 1024 / 8)

/* SHA-256 内部操作宏 */
/* 右移操作 */
#define SHFR(x, n)    (x >> n)
/* 循环右移操作 */
#define ROTR(x, n)   ((x >> n) | (x << ((sizeof(x) << 3) - n)))
/* 选择函数：如果x为1，则选择y，否则选择z */
#define CH(x, y, z)  ((x & y) ^ (~x & z))
/* 多数函数：返回x、y、z中多数位的值 */
#define MAJ(x, y, z) ((x & y) ^ (x & z) ^ (y & z))

/* SHA-256 消息调度函数 */
#define SHA256_F1(x) (ROTR(x,  2) ^ ROTR(x, 13) ^ ROTR(x, 22))
#define SHA256_F2(x) (ROTR(x,  6) ^ ROTR(x, 11) ^ ROTR(x, 25))
#define SHA256_F3(x) (ROTR(x,  7) ^ ROTR(x, 18) ^ SHFR(x,  3))
#define SHA256_F4(x) (ROTR(x, 17) ^ ROTR(x, 19) ^ SHFR(x, 10))

/* SHA-256 上下文结构体 */
typedef struct {
    unsigned int tot_len;     /* 已处理的总字节数 */
    unsigned int len;         /* 当前块中的字节数 */
    unsigned char block[2 * SHA256_BLOCK_SIZE];  /* 消息块缓冲区 */
    uint32_t h[8];            /* 哈希值 */
} sha256_ctx;

/* SHA-512 上下文结构体 */
typedef struct {
    unsigned long long tot_len;   /* 已处理的总字节数 */
    unsigned long long len;       /* 当前块中的字节数 */
    unsigned char block[2 * SHA512_BLOCK_SIZE];  /* 消息块缓冲区 */
    uint64_t h[8];              /* 哈希值 */
} sha512_ctx;

/* SHA-256 常量K数组（外部声明） */
extern uint32_t sha256_k[64];

/* SHA-256 函数声明 */
/* 初始化SHA-256上下文 */
void sha256_init(sha256_ctx * ctx);
/* 更新SHA-256上下文，处理更多数据 */
void sha256_update(sha256_ctx *ctx, const unsigned char *message,
                   unsigned int len);
/* 完成SHA-256哈希计算，生成最终摘要 */
void sha256_final(sha256_ctx *ctx, unsigned char *digest);
/* 一次性计算整个消息的SHA-256哈希值 */
void sha256(const unsigned char *message, unsigned int len,
            unsigned char *digest);

/* SHA-512 函数声明 */
/* 初始化SHA-512上下文 */
void sha512_init(sha512_ctx * ctx);
/* 更新SHA-512上下文，处理更多数据 */
void sha512_update(sha512_ctx *ctx, const unsigned char *message,
                   unsigned int len);
/* 完成SHA-512哈希计算，生成最终摘要 */
void sha512_final(sha512_ctx *ctx, unsigned char *digest);
/* 一次性计算整个消息的SHA-512哈希值 */
void sha512(const unsigned char *message, unsigned int len,
            unsigned char *digest);

#endif /* !SHA2_H */
