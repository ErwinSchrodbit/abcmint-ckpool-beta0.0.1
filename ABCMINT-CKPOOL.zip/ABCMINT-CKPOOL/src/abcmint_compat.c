/*
 * abcmint_compat.c - ABCMINT-CKPOOL与ABCMINT-MASTER兼容性适配层实现
 * 提供统一的接口实现，确保两个项目之间的兼容性
 */

/* 确保config.h可用，如果不可用则定义必要的宏 */
#if defined(HAVE_CONFIG_H) && defined(CONFIG_H_INCLUDED)
#include "config.h"
#else
// 基本配置宏定义
#endif

/* 基础头文件包含 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h> /* 为了NULL定义 */
#include <math.h> /* 为了fabs函数 */

/* 平台兼容的线程库包含 */
#ifdef _WIN32
// Windows环境下不包含windows.h，使用互斥锁模拟
#else
#include <pthread.h>
#endif

#include "abcmint_compat.h"

/* 彩虹算法级别定义 */
#define RAINBOW_LEVEL_1 1
#define RAINBOW_LEVEL_2 2
#define RAINBOW_LEVEL_3 3

/* 内存管理宏 */
#ifndef ckfree
#define ckfree free
#endif

/* 由于在编译环境中可能缺少某些头文件，我们定义必要的函数原型 */
#ifdef __cplusplus
extern "C" {
#endif

// 提供SetTestNetEnvironment函数实现
void SetTestNetEnvironment(bool is_testnet);

#ifdef __cplusplus
}
#endif

/* 全局变量 */
static CBlockIndex* g_last_block_index = NULL;

// 全局最佳区块索引指针（与abcmint-master一致）
CBlockIndex* pindexBest = NULL;

// 网络环境检测标志
static bool g_is_testnet = false;

// uint256辅助函数实现
void uint256_set_zero(uint256* a) {
    for (int i = 0; i < 8; i++) {
        a->pn[i] = 0;
    }
}

bool uint256_is_zero(const uint256* a) {
    for (int i = 0; i < 8; i++) {
        if (a->pn[i] != 0) return false;
    }
    return true;
}

void uint256_set_uint64(uint256* a, uint64_t b) {
    uint256_set_zero(a);
    a->pn[0] = (uint32_t)b;
    a->pn[1] = (uint32_t)(b >> 32);
}

void uint256_assign(uint256* a, const uint256* b) {
    for (int i = 0; i < 8; i++) {
        a->pn[i] = b->pn[i];
    }
}

bool uint256_equal(const uint256* a, const uint256* b) {
    for (int i = 0; i < 8; i++) {
        if (a->pn[i] != b->pn[i]) return false;
    }
    return true;
}

bool uint256_less(const uint256* a, const uint256* b) {
    for (int i = 7; i >= 0; i--) {
        if (a->pn[i] < b->pn[i]) return true;
        if (a->pn[i] > b->pn[i]) return false;
    }
    return false; // 相等
}

void uint256_xor(uint256* a, const uint256* b) {
    for (int i = 0; i < 8; i++) {
        a->pn[i] ^= b->pn[i];
    }
}

void uint256_and(uint256* a, const uint256* b) {
    for (int i = 0; i < 8; i++) {
        a->pn[i] &= b->pn[i];
    }
}

void uint256_or(uint256* a, const uint256* b) {
    for (int i = 0; i < 8; i++) {
        a->pn[i] |= b->pn[i];
    }
}

void uint256_shl(uint256* a, unsigned int shift) {
    // 简化实现，适用于基本操作
    uint64_t carry = 0;
    uint64_t temp;
    unsigned int bits_per_word = 32;
    
    for (int i = 0; i < 8; i++) {
        temp = (uint64_t)a->pn[i] << (shift % bits_per_word);
        temp |= carry;
        a->pn[i] = (uint32_t)temp;
        carry = temp >> bits_per_word;
    }
}

void uint256_shr(uint256* a, unsigned int shift) {
    // 简化实现，适用于基本操作
    uint64_t carry = 0;
    uint64_t temp;
    unsigned int bits_per_word = 32;
    
    for (int i = 7; i >= 0; i--) {
        temp = (uint64_t)a->pn[i] >> (shift % bits_per_word);
        temp |= carry;
        a->pn[i] = (uint32_t)temp;
        carry = ((uint64_t)a->pn[i] << (bits_per_word - (shift % bits_per_word))) & 0xFFFFFFFF;
    }
}

void uint256_add(uint256* a, const uint256* b) {
    uint64_t carry = 0;
    for (int i = 0; i < 8; i++) {
        carry += (uint64_t)a->pn[i] + (uint64_t)b->pn[i];
        a->pn[i] = (uint32_t)carry;
        carry >>= 32;
    }
}

void uint256_sub(uint256* a, const uint256* b) {
    uint64_t borrow = 0;
    for (int i = 0; i < 8; i++) {
        uint64_t ai = a->pn[i];
        uint64_t bi = b->pn[i];
        if (borrow) {
            if (ai == 0) {
                ai = 0xFFFFFFFF;
                borrow = 1;
            } else {
                ai--;
                borrow = 0;
            }
        }
        if (ai < bi) {
            ai += 0x100000000ULL;
            borrow = 1;
        }
        a->pn[i] = (uint32_t)(ai - bi);
    }
}

void uint256_inc(uint256* a) {
    uint64_t carry = 1;
    for (int i = 0; i < 8 && carry; i++) {
        carry += a->pn[i];
        a->pn[i] = (uint32_t)carry;
        carry >>= 32;
    }
}

double uint256_getdouble(const uint256* a) {
    // 返回uint256的浮点表示
    double d = 0.0;
    for (int i = 7; i >= 0; i--) {
        d = d * 0x100000000ULL + a->pn[i];
    }
    return d;
}

void uint256_from_bytes(uint256* a, const uint8_t* bytes) {
    // 从字节数组创建uint256（假设小端序）
    for (int i = 0; i < 8; i++) {
        a->pn[i] = ((uint32_t)bytes[4*i+3] << 24) |
                  ((uint32_t)bytes[4*i+2] << 16) |
                  ((uint32_t)bytes[4*i+1] << 8) |
                  (uint32_t)bytes[4*i+0];
    }
}

void uint256_to_bytes(const uint256* a, uint8_t* bytes) {
    // 将uint256转换为字节数组（小端序）
    for (int i = 0; i < 8; i++) {
        bytes[4*i+0] = (uint8_t)(a->pn[i] & 0xFF);
        bytes[4*i+1] = (uint8_t)((a->pn[i] >> 8) & 0xFF);
        bytes[4*i+2] = (uint8_t)((a->pn[i] >> 16) & 0xFF);
        bytes[4*i+3] = (uint8_t)((a->pn[i] >> 24) & 0xFF);
    }
}

// 网络环境检测函数实现
bool IsTestNetEnvironment() {
    // 这里可以根据配置文件或环境变量检测网络环境
    // 简化实现：默认为主网环境
    return g_is_testnet;
}

void SetTestNetEnvironment(bool is_testnet) {
    g_is_testnet = is_testnet;
    printf("SetTestNetEnvironment: 网络环境已设置为%s\n", is_testnet ? "测试网络" : "主网络");
}

unsigned int GetP2PPort() {
    return IsTestNetEnvironment() ? DEFAULT_TESTNET_PORT : DEFAULT_PORT;
}

unsigned int GetRPCPort() {
    return IsTestNetEnvironment() ? DEFAULT_TESTNET_RPC_PORT : DEFAULT_RPC_PORT;
}

/**
 * 获取区块索引
 * @param hash 区块哈希
 * @return 区块索引指针，失败返回NULL
 */
/**
 * 初始化区块索引缓存
 */
void InitBlockIndexCache(void) {
    pthread_mutex_init(&block_index_cache.mutex, NULL);
    block_index_cache.count = 0;
    // 初始化所有指针为NULL
    for (int i = 0; i < MAX_BLOCK_CACHE_SIZE; i++) {
        block_index_cache.index_array[i] = NULL;
    }
    printf("InitBlockIndexCache: 区块索引缓存已初始化\n");
}

/**
 * 清理区块索引缓存
 */
void ClearBlockIndexCache(void) {
    pthread_mutex_lock(&block_index_cache.mutex);
    
    // 释放所有缓存的区块索引
    for (int i = 0; i < block_index_cache.count; i++) {
        if (block_index_cache.index_array[i]) {
            free(block_index_cache.index_array[i]);
            block_index_cache.index_array[i] = NULL;
        }
        // 清空哈希值
        uint256_set_zero(&block_index_cache.hash_array[i]);
    }
    
    block_index_cache.count = 0;
    
    pthread_mutex_unlock(&block_index_cache.mutex);
    printf("ClearBlockIndexCache: 区块索引缓存已清空\n");
}

// 添加区块索引到缓存的函数实现
void AddBlockIndexToCache(CBlockIndex* index) {
    if (!index) {
        LOGERROR("AddBlockIndexToCache: 无效的区块索引");
        return;
    }
    
    pthread_mutex_lock(&block_index_cache.mutex);
    
    // 检查是否已存在相同哈希的区块索引
    for (int i = 0; i < block_index_cache.count; i++) {
        if (block_index_cache.index_array[i] && index->phashBlock && uint256_equal(&block_index_cache.hash_array[i], index->phashBlock)) {
            // 已存在，更新
            ckfree(block_index_cache.index_array[i]);
            block_index_cache.index_array[i] = (CBlockIndex*)ckmalloc(sizeof(CBlockIndex));
            memcpy(block_index_cache.index_array[i], index, sizeof(CBlockIndex));
            
            // 避免引用外部内存
            block_index_cache.index_array[i]->phashBlock = &block_index_cache.hash_array[i];
            block_index_cache.index_array[i]->pprev = NULL;
            block_index_cache.index_array[i]->pnext = NULL;
            
            pthread_mutex_unlock(&block_index_cache.mutex);
            return;
        }
    }
    
    // 如果缓存已满，删除最旧的条目
    if (block_index_cache.count >= MAX_BLOCK_CACHE_SIZE) {
        ckfree(block_index_cache.index_array[0]);
        // 移动剩余条目
        for (int i = 0; i < MAX_BLOCK_CACHE_SIZE - 1; i++) {
            block_index_cache.index_array[i] = block_index_cache.index_array[i + 1];
            block_index_cache.hash_array[i] = block_index_cache.hash_array[i + 1];
        }
        block_index_cache.count--;
    }
    
    // 添加新条目
    block_index_cache.index_array[block_index_cache.count] = (CBlockIndex*)ckmalloc(sizeof(CBlockIndex));
    memcpy(block_index_cache.index_array[block_index_cache.count], index, sizeof(CBlockIndex));
    if (index->phashBlock) {
        uint256_assign(&block_index_cache.hash_array[block_index_cache.count], index->phashBlock);
    } else {
        uint256_set_zero(&block_index_cache.hash_array[block_index_cache.count]);
    }
    
    // 避免引用外部内存
    block_index_cache.index_array[block_index_cache.count]->phashBlock = &block_index_cache.hash_array[block_index_cache.count];
    block_index_cache.index_array[block_index_cache.count]->pprev = NULL;
    block_index_cache.index_array[block_index_cache.count]->pnext = NULL;
    
    block_index_cache.count++;
    
    pthread_mutex_unlock(&block_index_cache.mutex);
}

/**
 * 从区块索引缓存中查找特定哈希值的区块索引
 */
CBlockIndex* FindBlockIndexByHash(const uint256* hash) {
    if (!hash) return NULL;
    
    pthread_mutex_lock(&block_index_cache.mutex);
    
    // 线性搜索缓存中的哈希值
    for (int i = 0; i < block_index_cache.count; i++) {
        // 安全检查：确保index_array[i]不为NULL
        if (block_index_cache.index_array[i]) {
            if (block_index_cache.index_array[i] && uint256_equal(&block_index_cache.hash_array[i], hash)) {
                pthread_mutex_unlock(&block_index_cache.mutex);
                return block_index_cache.index_array[i];
            }
        }
    }
    
    pthread_mutex_unlock(&block_index_cache.mutex);
    return NULL;
}

/**
 * 获取区块索引
 * @param hash 区块哈希
 * @return 区块索引指针，失败返回NULL
 */
CBlockIndex* GetBlockIndexFromHash(uint256 hash) {
    // 首先检查最佳区块
    if (pindexBest && pindexBest->phashBlock && uint256_equal(&hash, pindexBest->phashBlock)) {
        return pindexBest;
    }
    
    // 首先检查缓存
    pthread_mutex_lock(&block_index_cache.mutex);
    for (int i = 0; i < block_index_cache.count; i++) {
        if (block_index_cache.index_array[i] && uint256_equal(&block_index_cache.hash_array[i], &hash)) {
            // 找到匹配的哈希，返回缓存的索引
            pthread_mutex_unlock(&block_index_cache.mutex);
            return block_index_cache.index_array[i];
        }
    }
    pthread_mutex_unlock(&block_index_cache.mutex);
    
    // 如果没有在缓存中找到，检查最近的区块索引
    if (g_last_block_index) {
        if (uint256_equal(&g_last_block_index->hashPrevBlock, &hash)) {
            return g_last_block_index;
        }
    }
    
    // 在实际应用中，这里应该通过RPC调用获取区块信息
    // 这里暂时返回NULL，表示未找到
    LOGDEBUG("GetBlockIndexFromHash: 区块索引未找到");
    return NULL;
}

/**
 * 计算区块高度
 * @param hash 区块哈希
 * @param nVersion 区块版本
 * @return 区块高度
 */
int GetBlockHeight(uint256 hash, int nVersion) {
    int height = 0;
    uint256 initHash;
    uint256_set_zero(&initHash);
    
    // 检查是否为创世区块
    if (uint256_equal(&hash, &initHash)) {
        return 0;
    }
    
    // 尝试获取区块索引
    CBlockIndex* pindexPrev = GetBlockIndexFromHash(hash);
    if (pindexPrev) {
        return pindexPrev->nHeight + 1;
    }
    
    // 如果无法获取区块索引，根据区块版本和全局信息估算
    // 这是与abcmint-master一致的备用逻辑
    if (nVersion < BLOCK_VERSION2_BEFORE_FORK) {
        height = 0;
    } else if (nVersion < BLOCK_VERSION3_BEFORE_FORK) {
        height = 25217;
    } else if (nVersion < BLOCK_CURRENT_VERSION) {
        height = RAINBOWFORKHEIGHT;
    } else {
        // 对于当前版本，使用RAINBOWFORKHEIGHT作为基础，并添加一定的偏移量
        height = RAINBOWFORKHEIGHT + 100000;
    }
    
    LOGWARN("GetBlockHeight: 无法从区块哈希获取区块高度，使用备用估算: %d", height);
    return height;
}

/**
 * 将Uint256转换为解决方案位
 * @param x 输出数组
 * @param n 未知数数量
 * @param nonce nonce值
 */
void Uint256ToSolutionBits(uint8_t* x, unsigned int n, uint256 nonce) {
    if (!x || n == 0) {
        LOGERROR("Uint256ToSolutionBits: 无效的参数");
        return;
    }
    
    // 初始化输出数组
    memset(x, 0, n * sizeof(uint8_t));
    
    // 将uint256转换为字节数组（使用标准函数）
    uint8_t nonce_bytes[32];
    uint256_to_bytes(&nonce, nonce_bytes);
    
    // 从nonce提取位到解决方案数组
    // 注意：这里的转换逻辑必须与abcmint-master完全一致
    for (unsigned int i = 0; i < n && i < 256; i++) {
        // 计算在nonce中的字节位置和位偏移
        unsigned int byte_pos = i / 8;
        unsigned int bit_pos = i % 8;
        
        if (byte_pos < 32) {
            // 提取对应的位
            x[i] = (nonce_bytes[byte_pos] >> bit_pos) & 0x01;
        }
    }
    
    LOGDEBUG("Uint256ToSolutionBits: 成功将nonce转换为%d个解决方案位", n);
}

/**
 * 验证ABCMINT地址格式
 * @param addr 地址字符串
 * @return 有效返回true，否则返回false
 */
bool ValidateAbcmintAddress(const char* addr) {
    if (!addr) {
        LOGERROR("ValidateAbcmintAddress: 空地址");
        return false;
    }
    
    // 检查地址长度
    size_t len = strlen(addr);
    if (len != ABCMINT_ADDRESS_LENGTH) {
        LOGWARN("ValidateAbcmintAddress: 地址长度不正确，应为%d，实际为%zu", 
                ABCMINT_ADDRESS_LENGTH, len);
        return false;
    }
    
    // 检查地址前缀
    if (addr[0] != ABCMINT_ADDRESS_PREFIX) {
        LOGWARN("ValidateAbcmintAddress: 地址前缀不正确，应为'%c'，实际为'%c'", 
                ABCMINT_ADDRESS_PREFIX, addr[0]);
        return false;
    }
    
    // 检查地址字符是否为有效的Base58字符
    for (size_t i = 0; i < len; i++) {
        char c = addr[i];
        if (!((c >= '1' && c <= '9') || (c >= 'A' && c <= 'H') || 
              (c >= 'J' && c <= 'N') || (c >= 'P' && c <= 'Z') || 
              (c >= 'a' && c <= 'k') || (c >= 'm' && c <= 'z'))) {
            LOGWARN("ValidateAbcmintAddress: 无效的地址字符: %c", c);
            return false;
        }
    }
    
    // 注：在实际应用中，这里应该进行完整的Base58校验和验证
    LOGDEBUG("ValidateAbcmintAddress: 地址格式验证通过");
    return true;
}

/**
 * 计算基于Rainbow18算法的难度
 * @param block_version 区块版本
 * @param block_height 区块高度
 * @param target 目标值
 * @return 难度值
 */
/**
 * 检查是否为Rainbow18区块
 * @param block_version 区块版本
 * @return 是Rainbow18区块返回true，否则返回false
 */
bool abcmint_is_rainbow18_block(uint32_t block_version) {
    return block_version >= ABCMINT_BLOCK_VERSION;
}

/**
 * 根据区块高度确定rainbow算法级别
 * @param height 区块高度
 * @return 算法级别
 */
int abcmint_get_rainbow_level(size_t height) {
    if (height < RAINBOWFORKHEIGHT) {
        return RAINBOW_LEVEL_1;
    } else if (height < RAINBOWFORKHEIGHT + 100000) {
        return RAINBOW_LEVEL_2;
    } else {
        return RAINBOW_LEVEL_3;
    }
}

/**
 * 计算基于Rainbow18算法的难度
 * @param block_version 区块版本
 * @param block_height 区块高度
 * @param target 目标值
 * @return 难度值
 */
double CalculateRainbowDifficulty(uint32_t block_version, size_t block_height, const uint8_t* target) {
    if (!target) {
        LOGERROR("CalculateRainbowDifficulty: 空的target参数");
        return 0.0;
    }
    
    // 从目标哈希中提取nBits值
    // 根据abcmint-master的实现，nBits直接表示方程数量
    uint32_t nBits = (target[0] << 16) | (target[1] << 8) | target[2];
    
    // 与abcmint-master保持一致：直接返回nBits值作为难度
    // 在abcmint-master中，GetDifficulty函数直接返回blockindex->nBits
    double difficulty = (double)nBits;
    
    LOGDEBUG("CalculateRainbowDifficulty: 区块版本=%u, 区块高度=%zu, nBits=%u, 难度=%.4f",
             block_version, block_height, nBits, difficulty);
    
    return difficulty;
}

/**
 * 更新全局区块索引
 * @param pindex 区块索引指针
 */
void UpdateBlockIndex(CBlockIndex* pindex) {
    if (pindex) {
        // 在实际应用中，这里应该进行适当的内存管理
        g_last_block_index = pindex;
        
        // 更新全局最佳区块索引指针
        if (!pindexBest || pindex->nHeight > pindexBest->nHeight) {
            pindexBest = pindex;
        }
        
        LOGDEBUG("UpdateBlockIndex: 区块索引已更新，高度=%d", pindex->nHeight);
    }
}

/**
 * 测试难度计算一致性
 * 验证CalculateRainbowDifficulty函数与abcmint-master的GetDifficulty函数行为一致
 * @param block_version 区块版本
 * @param block_height 区块高度
 * @param nBits 难度位
 * @return 测试结果
 */
bool TestRainbowDifficultyConsistency(uint32_t block_version, size_t block_height, uint32_t nBits) {
    // 创建目标数组，包含nBits值
    uint8_t target[32] = {0};
    target[0] = (nBits >> 16) & 0xFF;
    target[1] = (nBits >> 8) & 0xFF;
    target[2] = nBits & 0xFF;
    
    // 使用更新后的难度计算函数
    double calculated_difficulty = CalculateRainbowDifficulty(block_version, block_height, target);
    
    // 根据abcmint-master的实现，预期难度应该等于nBits
    double expected_difficulty = (double)nBits;
    
    // 检查计算结果是否与预期一致（容差范围内）
    bool is_consistent = fabs(calculated_difficulty - expected_difficulty) < 0.0001;
    
    LOGINFO("测试难度计算一致性 - 区块版本=%u, 区块高度=%zu, nBits=%u, 计算难度=%.4f, 预期难度=%.4f, 一致性=%s",
            block_version, block_height, nBits, calculated_difficulty, expected_difficulty, 
            is_consistent ? "通过" : "失败");
    
    return is_consistent;
}

/**
 * 创建新的区块索引
 * @param nHeight 区块高度
 * @param hashPrevBlock 前一个区块哈希
 * @param nVersion 区块版本
 * @param nTime 时间戳
 * @param nBits 难度目标
 * @return 区块索引指针
 */
CBlockIndex* CreateBlockIndex(int nHeight, uint256 hashPrevBlock, uint32_t nVersion, uint32_t nTime, uint32_t nBits) {
    CBlockIndex* pindex = (CBlockIndex*)ckalloc(sizeof(CBlockIndex));
    if (!pindex) {
        LOGERROR("CreateBlockIndex: 内存分配失败");
        return NULL;
    }
    
    // 初始化区块索引
    pindex->nHeight = nHeight;
    uint256_assign(&pindex->hashPrevBlock, &hashPrevBlock);
    pindex->nVersion = nVersion;
    pindex->nTime = nTime;
    pindex->nBits = nBits;
    
    LOGDEBUG("CreateBlockIndex: 创建新区块索引，高度=%d", nHeight);
    return pindex;
}

/**
 * 释放区块索引
 * @param pindex 区块索引指针
 */
void FreeBlockIndex(CBlockIndex* pindex) {
    if (pindex) {
        ckfree(pindex);
        LOGDEBUG("FreeBlockIndex: 区块索引已释放");
    }
}

/**
 * 将二进制数据转换为uint256
 * @param hash uint256指针
 * @param data 二进制数据
 * @param len 数据长度
 */
void bin_to_uint256(uint256* hash, const unsigned char* data, size_t len) {
    if (!hash || !data) {
        LOGERROR("bin_to_uint256: 无效的参数");
        return;
    }
    
    uint256_set_zero(hash);
    if (len > 32) {
        len = 32;
    }
    uint256_from_bytes(hash, data);
    
    LOGDEBUG("bin_to_uint256: 成功转换%d字节数据到uint256", len);
}