/*
 * 版权所有 2014-2018,2023 Con Kolivas
 *
 * 本程序是自由软件；您可以根据自由软件基金会发布的GNU通用公共许可证
 * 条款重新发布和/或修改它，许可证版本可以是第3版，也可以（根据您的选择）
 * 是任何更高版本。详情请参阅COPYING文件。
 */

#ifndef GENERATOR_H
#define GENERATOR_H

#include "config.h"

/* 获取最佳区块失败的返回值 */
#define GETBEST_FAILED -1
/* 获取最佳区块需要通知的返回值 */
#define GETBEST_NOTIFY 0
/* 获取最佳区块成功的返回值 */
#define GETBEST_SUCCESS 1

/* 向生成器添加发送事务 */
void generator_add_send(ckpool_t *ckp, json_t *val);
/* 获取基础工作数据 */
struct genwork *generator_getbase(ckpool_t *ckp);
/* 获取最佳区块哈希 */
int generator_getbest(ckpool_t *ckp, char *hash);
/* 检查地址是否有效 */
bool generator_checkaddr(ckpool_t *ckp, const char *addr, bool *script);
/* 检查交易是否有效 */
bool generator_checktxn(const ckpool_t *ckp, const char *txn, json_t **val);
/* 根据哈希获取交易 */
char *generator_get_txn(ckpool_t *ckp, const char *hash);
/* 提交区块 */
bool generator_submitblock(ckpool_t *ckp, const char *buf);
/* 将指定区块标记为宝贵区块 */
void generator_preciousblock(ckpool_t *ckp, const char *hash);
/* 根据高度获取区块哈希 */
bool generator_get_blockhash(ckpool_t *ckp, int height, char *hash);
/* 生成器主函数 */
void *generator(void *arg);

#endif /* GENERATOR_H */
