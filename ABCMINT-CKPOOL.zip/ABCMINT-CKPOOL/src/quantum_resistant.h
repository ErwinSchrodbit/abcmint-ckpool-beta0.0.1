/*
 * Copyright 2025 Erwin Schrodbit
 * 本程序为自由软件；您可以根据自由软件基金会发布的GNU通用公共许可证
 * 重新分发或修改它；许可证版本可以是第3版，或者（根据您的选择）任何更新的版本。
 * 更多详情请参阅COPYING文件。
 */

#ifndef QUANTUM_RESISTANT_H
#define QUANTUM_RESISTANT_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h> /* 为了NULL定义 */

/* 定义解决方案回调函数类型 */
typedef int (*solution_callback_t)(void*, uint64_t, uint64_t*);

/* Windows环境下的time_t定义 */
#ifdef _WIN32
#include <time.h>
#else
// Unix/Linux环境已经定义了time_t
#include <time.h>
#endif

#include "abcmint_compat.h"   // 包含标准常量和结构体定义
#include "rainbow18_compat.h" // 引入彩虹算法兼容性接口

// 使用abcmint_compat.h中定义的标准uint256类型
// typedef struct {
//     uint8_t data[32];
// } uint256;

/* 打包向量类型定义 */
typedef uint32_t pck_vector_t;

/* 索引查找表类型定义 */
typedef struct {
    uint64_t * table;
    uint64_t size;
} idx_lut_t;

/* 二次型结构体定义 - 与abcmint-master兼容 */
typedef struct {
    int* quad;
    int* lin;
    int con;
} quadratic_form;

/* 方程组类型定义 */
typedef quadratic_form* system_t;

/* 包装器设置结构体 - 与abcmint-master兼容 */
typedef struct {
    int algorithm;
    int word_size;
    int algo_enum_self_tune;
    int algo_auto_degree_bound;
    int algo_enum_use_sse;
    int verbose;
} wrapper_settings_t;

/* 包装器状态结构体 - 与abcmint-master兼容 */
typedef struct {
    int n;
    int degree;
    int n_batches;
    pck_vector_t **G;
    idx_lut_t * testing_LUT;

    solution_callback_t callback;
    void *callback_state;
} wrapper_state_t;

// 使用abcmint_compat.h中定义的标准CBlockIndex类型
// /* CBlockIndex兼容接口 - 增强实现以支持节点API连接 */
// typedef struct {
//     struct CBlockIndex* pprev;
//     uint256 hashPrevBlock;
//     uint256 hashBlock;
//     int nHeight;
//     int nVersion;
//     uint32_t nBits;
//     uint256 nNonce;
//     uint32_t nTime;
//     time_t last_updated;  // 缓存更新时间
//     bool is_from_api;     // 是否来自API的真实数据
// } CBlockIndex;

/* 节点API配置结构 */
typedef struct {
    char* url;
    char* username;
    char* password;
    int timeout;
} NodeAPIConfig;

/* 节点API函数声明 */
bool InitNodeAPI(NodeAPIConfig* config);
void CloseNodeAPI(void);
CBlockIndex* GetBlockByHashFromNode(uint256 hash);

/* 区块索引缓存函数声明 - 使用abcmint_compat.h中定义的全局block_index_cache结构 */
// 注意：InitBlockIndexCache现在在abcmint_compat.c中实现，这里提供兼容版本
bool InitBlockIndexCache2(size_t capacity);
void CloseBlockIndexCache(void);
// 注意：AddBlockIndexToCache现在在abcmint_compat.c中实现
CBlockIndex* GetBlockIndexFromCache(uint256 hash);
void ClearExpiredCacheEntries(time_t expiry_time);

/* 增强的区块索引获取函数 */
CBlockIndex* EnhancedGetBlockIndexFromHash(uint256 hash);

/* 动态负载均衡的线程分区 */
void DynamicThreadPartitioning(uint64_t search_space, int thread_count, uint64_t* start_ranges, uint64_t* end_ranges);

// 解决方案回调函数类型已在文件开头定义

/* 打包向量类型定义 */
typedef uint32_t pck_vector_t;

/* 声明全局最佳区块索引指针 */
extern CBlockIndex* pindexBest;

/* 检查解决方案是否满足方程 */
bool CheckSolution(uint256 hash, unsigned int nBits, uint256 prevblockhash, int nblockversion, uint256 nNonce);

/* 将二进制数据转换为uint256 */
void bin_to_uint256(uint256* hash, const unsigned char* data, size_t len);

/* 计算量子抗性挖矿的难度 */
double quantum_resistant_diff_from_solution(unsigned int nBits, uint256 nonce);

// 辅助函数：计算基于rainbow18算法的难度调整
double quantum_resistant_calculate_difficulty(uint32_t block_version, size_t block_height, const uint8_t *target);

/* 搜索解决方案 - 与abcmint-master兼容的版本 */
uint256 SerchSolution(uint256 hash, unsigned int nBits, uint256 randomNonce, CBlockIndex* pindexPrev, int deviceID, int deviceCount);

/* 搜索解决方案 - 支持CPU和GPU模式 */
uint256 SearchSolution(uint256 hash, unsigned int nBits, uint256 randomNonce, uint256 prevblockhash, 
                      int nblockversion, int threadID, int threadCount);

/* 从哈希获取区块索引 - 注意：此函数在abcmint_compat.c中实现 */
// CBlockIndex* GetBlockIndexFromHash(uint256 hash);

/* 高级搜索相关函数声明 */
void TransformDataStructure(unsigned int nUnknowns, unsigned int mEquations, uint8_t* coeffMatrix, int*** Eqs);
void exfes(int nSearchVariables, unsigned int nUnknowns, unsigned int mEquations, 
           uint64_t startPoint[], uint64_t maxsol, int*** Eqs, uint64_t** SolArray, 
           CBlockIndex* pindexPrev, int threadID, int threadCount);
void ReportSolution(uint64_t maxsol, uint64_t** SolArray, uint256* nonce);
int*** CreateEquations(unsigned int nUnknowns, unsigned int mEquations);
void FreeEquations(unsigned int mEquations, int*** Eqs);
uint64_t** CreateArray(uint64_t maxsol);
void FreeArray(uint64_t maxsol, uint64_t** SolArray);

/* 优化和性能相关函数 */
uint64_t to_gray(uint64_t i);
uint64_t rdtsc();
void moebius_transform(int n, pck_vector_t F[], solution_callback_t callback, void* callback_state, CBlockIndex* pindexPrev);

/* 初始化内存管理系统 */
void quantum_resistant_init_memory();

/* 清理内存管理系统 */
void quantum_resistant_cleanup_memory();

#endif /* QUANTUM_RESISTANT_H */