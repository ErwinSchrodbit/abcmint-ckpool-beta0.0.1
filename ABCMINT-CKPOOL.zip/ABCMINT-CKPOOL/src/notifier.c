/*
 * 版权所有 2014-2016 Con Kolivas
 *
 * 本程序是自由软件；您可以根据自由软件基金会发布的GNU通用公共许可证
 * 条款重新发布和/或修改它，许可证版本可以是第3版，也可以（根据您的选择）
 * 是任何更高版本。详情请参阅COPYING文件。
 */

#include "config.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "libckpool.h"

int main(int argc, char **argv)
{
	/* 进程名称和套接字目录 */
	char *name = NULL, *socket_dir = NULL;
	/* 是否为代理模式 */
	bool proxy = false;
	int c, sockd;

	/* 解析命令行参数 */
	while ((c = getopt(argc, argv, "n:s:p")) != -1) {
		switch(c) {
			/* 设置进程名称 */
			case 'n':
				name = strdup(optarg);
				break;
			/* 设置套接字目录 */
			case 's':
				socket_dir = strdup(optarg);
				break;
			/* 设置为代理模式 */
			case 'p':
				proxy = true;
				break;
		}
	}
	
	/* 如果未指定套接字目录，默认为/tmp */
	if (!socket_dir)
		socket_dir = strdup("/tmp");
	/* 确保目录路径以斜杠结尾 */
	trail_slash(&socket_dir);
	
	/* 如果未指定进程名称，根据模式选择默认名称 */
	if (!name) {
		if (proxy)
			name = strdup("ckproxy");
		else
			name = strdup("ckpool");
	}
	/* 构建完整的套接字路径 */
	realloc_strcat(&socket_dir, name);
	dealloc(name);
	trail_slash(&socket_dir);
	realloc_strcat(&socket_dir, "stratifier");
	
	/* 打开Unix套接字连接 */
	sockd = open_unix_client(socket_dir);
	if (sockd < 0) {
		LOGERR("无法打开套接字: %s", socket_dir);
		exit(1);
	}
	
	/* 发送更新消息 */
	if (!send_unix_msg(sockd, "update")) {
		LOGERR("发送分层器更新消息失败");
		exit(1);
	}
	
	/* 记录成功通知 */
	LOGNOTICE("已通知分层器区块更新");
	exit(0);
}


