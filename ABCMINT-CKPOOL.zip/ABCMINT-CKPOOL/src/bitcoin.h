/*
 * 版权所有 2014-2018,2023 Con Kolivas
 * 本程序为自由软件；您可以根据自由软件基金会发布的GNU通用公共许可证
 * 重新分发或修改它；许可证版本可以是第3版，或者（根据您的选择）任何更新的版本。
 * 更多详情请参阅COPYING文件。
 */

#ifndef BITCOIN_H
#define BITCOIN_H

typedef struct genwork gbtbase_t;

bool validate_address(connsock_t *cs, const char *address, bool *script);
json_t *validate_txn(connsock_t *cs, const char *txn);
bool gen_gbtbase(connsock_t *cs, gbtbase_t *gbt);
void clear_gbtbase(gbtbase_t *gbt);
int get_blockcount(connsock_t *cs);
bool get_blockhash(connsock_t *cs, int height, char *hash);
bool get_bestblockhash(connsock_t *cs, char *hash);
bool submit_block(connsock_t *cs, const char *params);
void precious_block(connsock_t *cs, const char *params);
void submit_txn(connsock_t *cs, const char *params);
char *get_txn(connsock_t *cs, const char *hash);

#endif /* BITCOIN_H */
