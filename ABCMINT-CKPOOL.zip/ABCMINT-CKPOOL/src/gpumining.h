/*
 * gpumining.h - GPU挖矿功能支持头文件
 * 提供GPU设备管理和挖矿加速接口
 */

#ifndef ABCMINT_CKPOOL_GPU_MINING_H
#define ABCMINT_CKPOOL_GPU_MINING_H

#include <stdint.h>
#include "quantum_resistant.h"  // 包含uint256定义

#ifdef USE_GPU
/* GPU挖矿功能接口 */

/**
 * GPU设备搜索解决方案
 * @param coefficients 方程系数数组
 * @param number_of_variables 变量数量
 * @param number_of_equations 方程数量
 * @return 找到的解决方案
 */
uint64_t GPUSearchSolution(uint32_t* coefficients, unsigned int number_of_variables,
                           unsigned int number_of_equations);

/**
 * 获取可用的GPU设备数量
 * @return 设备数量
 */
int GetDeviceCount();

/**
 * 设置使用的GPU设备
 * @param device 设备索引
 */
void SetDevice(int device);

/**
 * GPU挖矿搜索解决方案
 * @param hash 区块哈希
 * @param nBits 难度目标
 * @param randomNonce 随机起始nonce
 * @param pindexPrev 前一个区块的索引
 * @param threadID 线程ID
 * @param threadCount 总线程数
 * @return 找到的nonce值
 */
uint256 GPUMinerSearchSolution(uint256 hash, unsigned int nBits, uint256 randomNonce, 
                              uint256 prevblockhash, int nblockversion, int threadID, int threadCount);

#else
/* 没有GPU支持时的空实现 */
#define GetDeviceCount() 0
#define SetDevice(device) ((void)0)

#endif /* USE_GPU */

#endif /* ABCMINT_CKPOOL_GPU_MINING_H */