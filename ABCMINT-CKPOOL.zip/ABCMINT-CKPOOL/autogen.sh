#!/bin/sh
# 强制重新生成所有构建配置并安装缺失的宏
autoreconf --force --install -I m4
